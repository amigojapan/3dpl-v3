import * as THREE from 'three';

const sharedGameId = /^[a-f0-9]{32}$/.test(window.THREEDPL_SHARED_GAME || '')
    ? window.THREEDPL_SHARED_GAME : '';
const programAssets = new Map();
let sharedPlayerReady = false;
let sharedPlayerError = '';
let sharedPlayerAlertOpen = false;

function programAssetUrl(library, reference) {
    if (!sharedGameId) return `${library}/${reference}`;
    return 'server_side/shared_asset.php?' + new URLSearchParams({
        share: sharedGameId, library, name: reference
    });
}

function recordProgramAsset(library, reference) {
    if (sharedGameId || !reference || /^(?:https?:|data:|blob:)/i.test(reference)) return;
    programAssets.set(`${library}/${reference}`, { library, reference });
}

// --- State Variables ---
let cubes = [];
let vars = {}; // Global variables object for the user
let sounds = {}; // Dictionary to store loaded audio objects
let isExecuting = false;
let clock = new THREE.Clock();
let loggedInNick = sharedGameId ? '' : sessionStorage.getItem('3dplLoggedInNick') || '';

// Object Cache
const loadedObjectCache = {};
const pendingObjectDataPromises = {};
const objectCollisionDataCache = new Map();
const mapRenderBatchStates = new WeakMap();
const objectVoxelCollisionData = new WeakMap();
const objectCollisionLocalBoxes = new WeakMap();

// Editor States
let objectEditorMode = false;
let mapEditorMode = false;
let editorPointer = null;
let actionCooldown = 0;
let selectedObjectTexture = "";
let selectedObjectColliderName = "";

// Mouse Look States
let mouseLookEnabled = false;
let camPitch = 0;
let camYaw = 0;
let objectMouseSensitivity = 0.0002;
const objectPitchLimit = 85 * Math.PI / 180;
let pendingMouseYaw = 0;
let pendingMousePitch = 0;
let skipNextMouseMove = false;

function clearObjectMouseMovement() {
    pendingMouseYaw = 0;
    pendingMousePitch = 0;
}

function updateObjectMouseLook(dt) {
    // Limit bursts per frame and discard excess input instead of queuing it.
    // A long frame or pointer-lock jump must not snap the view to a pole.
    const maxTurn = 1.2 * Math.min(dt, 0.05);
    if (mouseLookEnabled && (pendingMouseYaw || pendingMousePitch)) {
        rotateObjectEditorCamera(
            Math.max(-maxTurn, Math.min(maxTurn, pendingMouseYaw)),
            Math.max(-maxTurn, Math.min(maxTurn, pendingMousePitch))
        );
    }
    clearObjectMouseMovement();
}

function levelObjectEditorView() {
    clearObjectMouseMovement();
    window.Input._keys.ArrowUp = false;
    window.Input._keys.ArrowDown = false;
    rotateObjectEditorCamera(0, -camPitch);
}

function rotateObjectEditorCamera(yawDelta, pitchDelta) {
    camYaw += yawDelta;
    // Clamp the stored pitch too, so reversing direction responds immediately.
    camPitch = Math.max(-objectPitchLimit, Math.min(objectPitchLimit, camPitch + pitchDelta));
    camera.rotation.set(camPitch, camYaw, 0, 'YXZ');
}

// --- Three.js Setup ---
const scene = new THREE.Scene();
const mapBuilderBackground = new THREE.Color(0xdddddd);
scene.background = mapBuilderBackground;

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const resetCamera = () => {
    camera.position.set(0, 1, 10);
    camera.rotation.set(0, 0, 0, 'YXZ');
    camera.far = 1000;
    camera.updateProjectionMatrix();
    camPitch = 0;
    camYaw = 0;
    clearObjectMouseMovement();
};
resetCamera();

// Audio Setup
const listener = new THREE.AudioListener();
camera.add(listener);

function clearLoadedSounds() {
    const previousSounds = sounds;
    sounds = {};
    Object.values(previousSounds).forEach(disposeLoadedSound);
}

const renderer = new THREE.WebGLRenderer({
    antialias: true,
    powerPreference: 'high-performance'
});
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.domElement.tabIndex = 0;
document.body.appendChild(renderer.domElement);

const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
scene.add(ambientLight);
const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
dirLight.position.set(10, 20, 10);
scene.add(dirLight);

const baseGeometry = new THREE.BoxGeometry(1, 1, 1);
const textureLoader = new THREE.TextureLoader();
const sharedTextureCache = new Map();
let wrappedBaseGeometry = null;
let skyBackgroundTexture = null;
let legacySkyMode = 'default';
const starryNightBackground = new THREE.Color(0x020611);

function imageHasTransparentPixels(image) {
    const width = image.naturalWidth || image.videoWidth || image.width;
    const height = image.naturalHeight || image.videoHeight || image.height;
    if (!width || !height) return true;

    try {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const context = canvas.getContext('2d', { willReadFrequently: true });
        context.drawImage(image, 0, 0, width, height);
        const pixels = context.getImageData(0, 0, width, height).data;
        for (let offset = 3; offset < pixels.length; offset += 4) {
            if (pixels[offset] < 255) return true;
        }
        return false;
    } catch (error) {
        // A tainted or unsupported image stays on the conservative transparent
        // path, preserving its appearance rather than guessing.
        return true;
    }
}

function updateTextureMaterialTransparency(texture, material) {
    const hasTransparentPixels =
        texture.userData.threeDPLHasTransparentPixels;
    if (hasTransparentPixels === undefined) return;
    const needsTransparency = material.opacity < 1 || hasTransparentPixels;
    if (material.transparent !== needsTransparency) {
        material.transparent = needsTransparency;
        material.needsUpdate = true;
    }
}

function materialNeedsTransparency(material, opacity) {
    if (opacity < 1) return true;
    if (!material.map) return false;
    const hasTransparentPixels =
        material.map.userData.threeDPLHasTransparentPixels;
    return hasTransparentPixels === undefined ? true : hasTransparentPixels;
}

function assignSharedTexture(material, textureName) {
    const previousTexture = material.map;
    if (previousTexture && previousTexture.userData.threeDPLMaterials) {
        previousTexture.userData.threeDPLMaterials.delete(material);
    }

    const filename = usableTextureFilename(textureName);
    if (!filename) {
        // Some legacy objects contain placeholders such as "w" in their
        // TextureName field. Render those voxels with their saved color.
        material.map = null;
        material.transparent = material.opacity < 1;
        material.needsUpdate = true;
        return null;
    }

    const texture = loadSharedTexture(filename);
    material.map = texture;
    if (texture.userData.threeDPLHasTransparentPixels === undefined) {
        if (!texture.userData.threeDPLMaterials) {
            texture.userData.threeDPLMaterials = new Set();
        }
        texture.userData.threeDPLMaterials.add(material);
        if (!material.transparent) {
            material.transparent = true;
            material.needsUpdate = true;
        }
    }
    updateTextureMaterialTransparency(texture, material);
    return texture;
}

function flatTextureFilename(reference) {
    const value = String(reference || '').trim();
    if (!value || /[/?#\\]/.test(value) || value.length > 128) return '';
    return /^[A-Za-z0-9][A-Za-z0-9 ._-]*\.(?:png|jpe?g|webp|gif)$/i.test(value)
        ? value
        : '';
}

function usableTextureFilename(reference) {
    const value = String(reference || '').trim();
    const directFilename = flatTextureFilename(value);
    if (directFilename) return directFilename;

    // Converted Unity objects may retain a Textures/ or Windows-style path.
    // Resolve its safe final component inside this app's flat texture library.
    const pathParts = value.replace(/\\/g, '/').split('/');
    return flatTextureFilename(pathParts[pathParts.length - 1]);
}

function personalTextureResourceUrl(textureName, nick = loggedInNick) {
    const filename = flatTextureFilename(textureName);
    if (!nick || !filename) return '';
    // The server resolves the account from the authenticated session. The
    // scope value is only a browser-cache discriminator when accounts change.
    return `server_side/load_texture.php?name=${encodeURIComponent(filename)}` +
        `&scope=${encodeURIComponent(nick)}`;
}

function staticTextureResourceUrl(textureName) {
    const filename = flatTextureFilename(textureName);
    return filename
        ? programAssetUrl('Textures', sharedGameId ? filename : encodeURIComponent(filename))
        : 'Textures/__invalid_texture_name__';
}

function registerTextureMaterial(texture, material) {
    if (texture.userData.threeDPLHasTransparentPixels === undefined) {
        if (!texture.userData.threeDPLMaterials) {
            texture.userData.threeDPLMaterials = new Set();
        }
        texture.userData.threeDPLMaterials.add(material);
        if (!material.transparent) {
            material.transparent = true;
            material.needsUpdate = true;
        }
    } else {
        updateTextureMaterialTransparency(texture, material);
    }
}

function loadSharedTexture(textureName, allowPersonal = true) {
    recordProgramAsset('Textures', textureName);
    const personalUrl = allowPersonal
        ? personalTextureResourceUrl(textureName)
        : '';
    const textureUrl = personalUrl || staticTextureResourceUrl(textureName);
    if (sharedTextureCache.has(textureUrl)) {
        return sharedTextureCache.get(textureUrl);
    }

    let resolveTextureReady;
    const textureReady = new Promise(resolve => {
        resolveTextureReady = resolve;
    });
    const texture = textureLoader.load(
        textureUrl,
        loadedTexture => {
            loadedTexture.userData.threeDPLHasTransparentPixels =
                imageHasTransparentPixels(loadedTexture.image);
            const materials = loadedTexture.userData.threeDPLMaterials;
            if (materials) {
                materials.forEach(material =>
                    updateTextureMaterialTransparency(loadedTexture, material));
                materials.clear();
            }
            resolveTextureReady(loadedTexture);
        },
        undefined,
        () => {
            if (personalUrl) {
                const fallbackTexture = loadSharedTexture(textureName, false);
                const materials = texture.userData.threeDPLMaterials;
                if (materials) {
                    materials.forEach(material => {
                        if (material.map !== texture) return;
                        material.map = fallbackTexture;
                        registerTextureMaterial(fallbackTexture, material);
                        material.needsUpdate = true;
                    });
                    materials.clear();
                }
                sharedTextureCache.delete(textureUrl);
                Promise.resolve(fallbackTexture.userData.threeDPLReady)
                    .then(() => resolveTextureReady(fallbackTexture));
                texture.dispose();
                return;
            }
            texture.userData.threeDPLHasTransparentPixels = true;
            if (texture.userData.threeDPLMaterials) {
                texture.userData.threeDPLMaterials.clear();
            }
            sharedTextureCache.delete(textureUrl);
            resolveTextureReady(texture);
            setDebugError(`Texture load error: Could not load ${textureUrl}`);
        }
    );
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.userData.threeDPLTextureName = textureName;
    texture.userData.threeDPLPersonal = Boolean(personalUrl);
    texture.userData.threeDPLReady = textureReady;
    sharedTextureCache.set(textureUrl, texture);
    return texture;
}

function clearPersonalTextureCache() {
    [...sharedTextureCache.keys()].forEach(url => {
        if (!url.startsWith('server_side/load_texture.php?')) return;
        // Existing scene materials may still reference the texture, so leave
        // its GPU resource alive. Removing the account-scoped cache entry
        // guarantees new assignments cannot reuse another account's image.
        sharedTextureCache.delete(url);
    });
}

function setSkyboxVisible(visible) {
    if (!visible) {
        scene.background = mapBuilderBackground;
    } else if (legacySkyMode === 'starry-night') {
        scene.background = starryNightBackground;
    } else if (legacySkyMode === 'none') {
        scene.background = mapBuilderBackground;
    } else {
        scene.background = skyBackgroundTexture || mapBuilderBackground;
    }
}

// Compatibility for older Unity-era programs such as finalx3. The original
// commands selected a named skybox or removed it before creating the scene.
window.SetSkyStarryNight = function() {
    legacySkyMode = 'starry-night';
    setSkyboxVisible(!mapEditorMode);
};

window.SetSkyNone = function() {
    legacySkyMode = 'none';
    setSkyboxVisible(!mapEditorMode);
};

textureLoader.load(
    programAssetUrl('Skyboxes', 'sunflowers_puresky_2k.jpg'),
    texture => {
        texture.colorSpace = THREE.SRGBColorSpace;
        texture.mapping = THREE.EquirectangularReflectionMapping;
        skyBackgroundTexture = texture;
        setSkyboxVisible(!mapEditorMode);
    },
    undefined,
    error => {
        console.error('Skybox load error:', error);
        setDebugError('Skybox load error: Skyboxes/sunflowers_puresky_2k.jpg');
    }
);

function get_object_position(target) {
    if (!target) return null;
    
    // If target is a string ID, look it up in vars
    if (typeof target === 'string') {
        if (vars[target] && vars[target].transform) {
            return vars[target].transform.position;
        }
        return null;
    }
    
    // If target is an object reference
    if (target.transform && target.transform.position) {
        return target.transform.position;
    }
    if (target.position) {
        return target.position;
    }
    
    return null;
}

/**
 * Resolves the string name identifier required for built-in collision checks like cd().
 */
function get_object_name(target, fallbackName) {
    if (typeof target === 'string') return target;
    if (target && target.name) return target.name;
    
    // Search the global vars map for a matching object reference
    for (var key in vars) {
        if (vars[key] === target) return key;
    }
    
    return fallbackName || "";
}

/**
 * Checks if an entity is colliding with solid voxel ground/map geometry.
 * Combines bounding box checks with height evaluation to prevent false collisions when airborne.
 * 
 * @param {Object|string} landObj - The map object or string identifier (e.g., vars["land"] or "land")
 * @param {Object|string} carObj - The moving entity or string identifier (e.g., vars["car"] or "car0")
 * @param {number} [heightThreshold=1.0] - Maximum Y-axis height offset to consider as ground contact
 * @returns {boolean} True if the entity is within ground altitude AND intersecting the map bounds
 */
function is_touching_voxel(landObj, colliderObj, colliderName) {
    var land = typeof landObj === "string" ? vars[landObj] : landObj;
    var colliders = typeof colliderObj === "string" ? vars[colliderObj] : colliderObj;

    if (!land || !colliders) {
        return false;
    }

    var collider = null;

    // Find ONLY the requested collider.
    colliders.traverse(function(obj) {
        if (obj.isMesh && obj.name === colliderName) {
            collider = obj;
        }
    });

    if (!collider) {
        return false;
    }

    collider.updateWorldMatrix(true, false);
    const colliderBox = new THREE.Box3().setFromObject(collider);
    return colliderMeshTouchesLand(land, colliderBox);
}

// --- 3DPL Texture UV Unwrapping ---
window.apply3DPLWrap1 = function(geometry) {
    const uvAttribute = geometry.attributes.uv;

    const setFace = (faceIdx, col, row) => {
        const w = 1/3, h = 1/2;
        const u = col * w, v = row * h;
        const idx = faceIdx * 4;

        uvAttribute.setXY(idx + 0, u, v + h);     
        uvAttribute.setXY(idx + 1, u + w, v + h); 
        uvAttribute.setXY(idx + 2, u, v);         
        uvAttribute.setXY(idx + 3, u + w, v);     
    };

    setFace(4, 0, 1); // Front  
    setFace(5, 1, 1); // Back   
    setFace(2, 2, 1); // Top    
    setFace(3, 0, 0); // Bottom 
    setFace(1, 1, 0); // Left   
    setFace(0, 2, 0); // Right  

    uvAttribute.needsUpdate = true;
};

function getWrappedBaseGeometry() {
    if (!wrappedBaseGeometry) {
        wrappedBaseGeometry = baseGeometry.clone();
        window.apply3DPLWrap1(wrappedBaseGeometry);
    }
    return wrappedBaseGeometry;
}

// Pointer Mesh
const pointerGeo = new THREE.BoxGeometry(1.1, 1.1, 1.1);
const pointerMat = new THREE.MeshBasicMaterial({ color: 0xff0000, wireframe: true });
editorPointer = new THREE.Mesh(pointerGeo, pointerMat);
scene.add(editorPointer);
editorPointer.visible = false;
const editorForwardPosition = new THREE.Vector3();

// --- CodeMirror Editor Setup ---
const editorOptions = { mode: "javascript", theme: "dracula", lineNumbers: true, tabSize: 4 };
const editorDeclarations = CodeMirror.fromTextArea(document.getElementById('code-declarations'), editorOptions);
const editorUpdate = CodeMirror.fromTextArea(document.getElementById('code-update'), editorOptions);

// Sets the name saved on newly placed Object Editor blocks. Using the same
// name for several blocks lets them act as one logical collider probe.
const objectColliderNameInput = document.getElementById('obj-collider-name');
const clearColliderNameButton = document.getElementById('btn-clear-collider-name');

window.SetColliderName = function(name) {
    selectedObjectColliderName = String(name || '').trim();
    objectColliderNameInput.value = selectedObjectColliderName;
    return selectedObjectColliderName;
};

objectColliderNameInput.oninput = () => {
    selectedObjectColliderName = objectColliderNameInput.value.trim();
};
clearColliderNameButton.onclick = () => window.SetColliderName('');

// --- Object Editor Texture Picker ---
const texturePicker = document.getElementById('texture-picker');
const textureGrid = document.getElementById('texture-grid');
const textureSearch = document.getElementById('texture-search');
const selectedTextureName = document.getElementById('selected-texture-name');
const selectTextureButton = document.getElementById('btn-select-texture');
const clearTextureButton = document.getElementById('btn-clear-texture');
const availableTextureNames = [
    "1flowercube.png",
    "16x16_1.png",
    "16x16_2.png",
    "16x16_3.png",
    "16x16_4.png",
    "16x16_5.png",
    "16x16_6.png",
    "16x16_7.png",
    "16x16_8.png",
    "16x16_9.png",
    "16x16_10.png",
    "16x16_11.png",
    "16x16_12.png",
    "16x16_13.png",
    "16x16_14.png",
    "16x16_15.png",
    "16x16_16.png",
    "16x16_17.png",
    "16x16_18.png",
    "16x16_newbrick.png",
    "16x16_newbrick1.png",
    "16x16_newbrick2.png",
    "16x16_newbrick3.png",
    "16x16_tree_leaves.png",
    "16x16_tree_leaves2.png",
    "16x16_tree_leaves3.png",
    "16x16_window.png",
    "16x16_wood.png",
    "32x32_grass1.png",
    "32x32_grass2.png",
    "32x32_grass3.png",
    "32x32_grass4.png",
    "32x32_grass5.png",
    "32x32_grass6.png",
    "32x32_grass7.png",
    "64x64_grass1.png",
    "64x64_grass2.png",
    "64x64_grassandcoconut.png",
    "64x64brick1.png",
    "64x64wood1.png",
    "64x64wood2.png",
    "64x64wood3.png",
    "64x64wood4.png",
    "beach_sand_with_bluestarfish.png",
    "beach_sand_with_butterfly.png",
    "beach_sand_with_butterfly1.png",
    "beach_sand_with_butterfly2.png",
    "beach_sand_with_crustacea1.png",
    "beach_sand_with_pinkstarfish.png",
    "beach_sand_with_shell.png",
    "beach_sand_with_shell1.png",
    "beach_sand_with_silverstarfish.png",
    "beach_sand.png",
    "beach_sand2.png",
    "coconut_wood.png",
    "coconut_wood2.png",
    "doorbtn.png",
    "doorbtn1.png",
    "doorsbuton1.png",
    "doorswitch1.png",
    "dotted_box.png",
    "dotted_box1.png",
    "dotted_box3.png",
    "dotted_box4.png",
    "dotted_box5.png",
    "dotted_box6.png",
    "dotted_box7.png",
    "dotted_box8.png",
    "dungeonkeyss.png",
    "fence2.png",
    "fenceA.png",
    "fenceback.png",
    "flower_right.png",
    "flower2.png",
    "grass.png",
    "grass1.png",
    "grass2.png",
    "grass3.png",
    "grass4.png",
    "grass5.png",
    "ground1.png",
    "ground2.png",
    "leafs1.png",
    "leafs2.png",
    "leafs3.png",
    "leafs4.png",
    "leafs5.png",
    "material1.png",
    "material2.png",
    "material3.png",
    "Medieval_cube.png",
    "new_flower.png",
    "newfence.png",
    "OneSIdeBark.png",
    "OneSideGreenery.png",
    "picasso.png",
    "red_vines.png",
    "room_lamp.png",
    "SixSideCube_Grass.png",
    "SixSideCube_Grass2.png",
    "SixSideCube_grass7.png",
    "SixSideCube_grass8.png",
    "SixSideCubeTemplate.jpg",
    "SixSideCubeTemplate1.png",
    "SixSideGround.png",
    "stone1.png",
    "stone2.png",
    "stone3.png",
    "stone4.png",
    "stonetype1.png",
    "stonetype2.png",
    "stonetype3.png",
    "stonetype4.png",
    "stonetype5.png",
    "stonetype6.png",
    "stonetype7.png",
    "stonetype8.png",
    "stonetype9.png",
    "stonetype10.png",
    "stonetype11.png",
    "stonetype12.png",
    "stonetype13.png",
    "stonetype14.png",
    "stonetype15.png",
    "stonetype16.png",
    "stonetype17.png",
    "stonetype18.png",
    "stonetype19.png",
    "stonetype20.png",
    "stonetype21a.png",
    "stonetype22.png",
    "stonetype23.png",
    "stonetype24.png",
    "stonetype25.png",
    "stonetype26.png",
    "stonetype27.png",
    "stonetype28.png",
    "stonetype29.png",
    "stonetype30.png",
    "stonetype31.png",
    "texture_wall3.png",
    "texture_wall4.png",
    "texture_wall6.png",
    "texture_wall7.png",
    "texture_wall8.png",
    "tree_leaves.png",
    "tree_leaves2.png",
    "tree_leaves3.png",
    "tree_wood.png",
    "Untitled-1.png",
    "water.png",
    "water2.png",
    "water3.png",
    "water4.png",
    "water5.png",
    "water6.png",
    "window1.png",
    "wood1.png",
    "wood2.png",
    "wood3.png",
    "wood4.png",
    "wood5.png",
    "wood7.png",
    "woodtype1.png",
    "woodtype2.png",
    "woodtype3.png",
    "woodtype4.png",
    "woodtype5.png",
    "woodtype6.png",
    "woodtype7.png",
    "woodtype8.png",
    "woodtype9.png",
    "woodtype10.png",
    "woodtype11.png",
    "working_fence.png"
];
let personalTextureNames = [];

function mergedTextureEntries() {
    const entries = [];
    const seen = new Set();
    personalTextureNames.forEach(name => {
        const key = name.toLowerCase();
        if (seen.has(key)) return;
        seen.add(key);
        entries.push({ name, personal: true });
    });
    availableTextureNames.forEach(name => {
        const key = name.toLowerCase();
        if (seen.has(key)) return;
        seen.add(key);
        entries.push({ name, personal: false });
    });
    return entries;
}

async function refreshPersonalTextureLibrary() {
    const requestedNick = loggedInNick;
    if (!requestedNick) {
        personalTextureNames = [];
        if (texturePicker.style.display === 'block') {
            renderTextureChoices(textureSearch.value);
        }
        return [];
    }

    const response = await fetch(
        `server_side/load_texture.php?scope=${encodeURIComponent(requestedNick)}`,
        {
        credentials: 'same-origin',
        cache: 'no-store'
        }
    );
    const result = await readApiResponse(response);
    if (requestedNick !== loggedInNick) return [];
    personalTextureNames = (Array.isArray(result.textures) ? result.textures : [])
        .map(entry => typeof entry === 'string' ? entry : entry?.name)
        .filter(name => flatTextureFilename(name));
    if (texturePicker.style.display === 'block') {
        renderTextureChoices(textureSearch.value);
    }
    return personalTextureNames;
}

function selectObjectEditorTexture(textureName) {
    selectedObjectTexture = textureName;
    selectedTextureName.textContent = textureName
        ? `Selected: ${textureName}`
        : 'Selected: None (color only)';
    selectTextureButton.textContent = textureName ? 'Change Texture' : 'Select Texture';
    textureGrid.querySelectorAll('.texture-option').forEach(option => {
        option.classList.toggle('selected', option.dataset.texture === textureName);
    });
    texturePicker.style.display = 'none';
}

function renderTextureChoices(filterText = '') {
    const filter = filterText.trim().toLowerCase();
    const fragment = document.createDocumentFragment();
    textureGrid.innerHTML = '';

    mergedTextureEntries()
        .filter(entry => entry.name.toLowerCase().includes(filter))
        .forEach(entry => {
            const textureName = entry.name;
            const option = document.createElement('button');
            option.type = 'button';
            option.className = 'texture-option';
            option.dataset.texture = textureName;
            option.title = entry.personal
                ? `${textureName} (My texture)`
                : textureName;
            option.classList.toggle('selected', textureName === selectedObjectTexture);

            const preview = document.createElement('img');
            preview.src = entry.personal
                ? personalTextureResourceUrl(textureName)
                : staticTextureResourceUrl(textureName);
            preview.alt = textureName;
            preview.loading = 'lazy';
            if (entry.personal) {
                preview.onerror = () => {
                    if (preview.dataset.staticFallback === '1') return;
                    preview.dataset.staticFallback = '1';
                    preview.src = staticTextureResourceUrl(textureName);
                };
            }

            const label = document.createElement('span');
            label.textContent = entry.personal
                ? `${textureName} • Mine`
                : textureName;
            option.append(preview, label);
            option.onclick = () => selectObjectEditorTexture(textureName);
            fragment.appendChild(option);
        });

    textureGrid.appendChild(fragment);
}

selectTextureButton.onclick = () => {
    const opening = texturePicker.style.display !== 'block';
    texturePicker.style.display = opening ? 'block' : 'none';
    if (opening) {
        renderTextureChoices(textureSearch.value);
        textureSearch.focus();
    }
};

clearTextureButton.onclick = () => selectObjectEditorTexture('');
textureSearch.oninput = () => renderTextureChoices(textureSearch.value);

if (!sharedGameId) renderTextureChoices();

// --- Bird's-eye Map Editor ---
const fallbackMapObjectNames = [
    "1tree.json",
    "3DLP_MAP_ISLAND_extended.json",
    "airplane_jet.json",
    "Airpor.json",
    "Airport.json",
    "airport_terrain_for_cloning.json",
    "big_building1.json",
    "Bridge_left_side.json",
    "Bridge_middle_for_clone.json",
    "buildings_area.json",
    "buildings_starting_terrain.json",
    "Camera_Coliders.json",
    "car_colliders.json",
    "cemetary.json",
    "circle.json",
    "cross.json",
    "Cute_character_creating_broken_heart.json",
    "door1.json",
    "door2.json",
    "door3.json",
    "doorsbuton1.json",
    "Dungeon.json",
    "Dungeon2.json",
    "dungeonkeys.json",
    "first_house.json",
    "Fountain_place.json",
    "Futuristic_Helycopter.json",
    "Futuristic_Helycopter_propeller.json",
    "Futuristic_Helycopter_without_wings.json",
    "Futuristic_Helycopter_without_wings_with_colliders.json",
    "heli_no_proeller.json",
    "helicpter_colliders.json",
    "house2.json",
    "house3.json",
    "house4.json",
    "houses_and_terrain.json",
    "houses_and_terrain1.json",
    "key_stone.json",
    "ladder_to_helly.json",
    "main_road.json",
    "main_road1.json",
    "new_road_a.json",
    "new_road_part_a_vertical.json",
    "PerspectiveTemplate.json",
    "picasso.json",
    "pillars.json",
    "propeller.json",
    "road_1.json",
    "road_a.json",
    "road_b.json",
    "road_part_a.json",
    "road_part_b.json",
    "roadj.json",
    "skyscraper1.json",
    "spider.json",
    "sport_car.json",
    "sport_car_tires.json",
    "sports-car-tires.json",
    "sports-car.json",
    "Station.json",
    "test_delete_this.json",
    "test_delete_this1.json",
    "TransparentTexturedCross.json",
    "trap1.json",
    "trap2.json",
    "Trees.json",
    "tutorial32_ground.json",
    "tutorial32_wall.json"
];
const previewPathForMapObject = filename =>
    `Preview/${filename.substring(filename.lastIndexOf('/') + 1)
        .replace(/\.json$/i, '')}.png`;
let sharedMapObjects = fallbackMapObjectNames.map(filename => ({
    file: filename,
    label: filename,
    preview: previewPathForMapObject(filename),
    personal: false
}));
let personalMapObjects = [];
let availableMapObjects = [...sharedMapObjects];
let mapObjectLibraryRevision = 'fallback-20260820';
let mapObjectLibraryMessage =
    `${availableMapObjects.length} built-in JSON objects available`;
let mapObjectLibraryMessageColor = '#aaaaaa';
let mapObjectPickerRenderId = 0;
let selectedMapObject = '';
let mapObjectPreview = null;
let mapEditorLoadToken = 0;
let pendingMapEditorObjects = [];
let currentMapName = 'my_map.json';

const mapObjectPicker = document.getElementById('map-object-picker');
const mapObjectGrid = document.getElementById('map-object-grid');
const mapObjectSearch = document.getElementById('map-object-search');
const mapObjectLibraryStatus = document.getElementById('map-object-library-status');
const closeMapObjectPickerButton = document.getElementById('btn-close-map-object-picker');
const selectedMapObjectLabel = document.getElementById('selected-map-object');
const selectMapObjectButton = document.getElementById('btn-select-map-object');
const mapObjectYInput = document.getElementById('map-object-y');
const mapObjectRotationInput = document.getElementById('map-object-rotation');
const mapObjectScaleInput = document.getElementById('map-object-scale');
const rotateMapObjectButton = document.getElementById('btn-rotate-map-object');
const centerMapPointerButton = document.getElementById('btn-center-map-pointer');
const mapObjectCount = document.getElementById('map-object-count');

function updateMapObjectCount() {
    const count = cubes.filter(object => object.userData.mapEditorObject).length;
    mapObjectCount.textContent = `Placed objects: ${count}`;
}

function rebuildMapObjectLibrary() {
    const seen = new Set();
    availableMapObjects = [...personalMapObjects, ...sharedMapObjects]
        .filter(entry => {
            const key = entry.file.toLowerCase();
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        })
        .sort((left, right) => left.label.localeCompare(right.label));
    mapObjectLibraryMessage = personalMapObjects.length > 0
        ? `${sharedMapObjects.length} shared • ${personalMapObjects.length} of my objects`
        : `${sharedMapObjects.length} shared JSON objects available`;
    mapObjectLibraryMessageColor = '#aaaaaa';
}

async function refreshPersonalObjectLibrary() {
    const requestedNick = loggedInNick;
    if (!requestedNick) {
        personalMapObjects = [];
        rebuildMapObjectLibrary();
        if (mapObjectPicker.style.display === 'flex') {
            renderMapObjectChoices(mapObjectSearch.value);
        }
        return [];
    }

    const response = await fetch(
        `server_side/download_object.php?scope=${encodeURIComponent(requestedNick)}`,
        {
        credentials: 'same-origin',
        cache: 'no-store'
        }
    );
    const result = await readApiResponse(response);
    if (requestedNick !== loggedInNick) return [];

    const seen = new Set();
    personalMapObjects = (Array.isArray(result.objects) ? result.objects : [])
        .map(entry => typeof entry === 'string' ? entry : entry?.name)
        .filter(name => {
            if (!flatPersonalJSONName(name)) return false;
            const key = name.toLowerCase();
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        })
        .map(name => ({
            file: name,
            label: `${name} • Mine`,
            preview: '',
            personal: true
        }));
    rebuildMapObjectLibrary();
    if (mapObjectPicker.style.display === 'flex') {
        renderMapObjectChoices(mapObjectSearch.value);
    }
    return personalMapObjects;
}

function removeMapObjectPreview() {
    if (!mapObjectPreview) return;
    cancelObjectLoads(mapObjectPreview);
    mapObjectPreview.removeFromParent();
    mapObjectPreview.traverse(child => {
        if (child.isInstancedMesh) child.dispose();
    });
    disposeObjectMaterials(mapObjectPreview);
    mapObjectPreview = null;
}

function discardPendingMapEditorObjects(objects = pendingMapEditorObjects) {
    objects.forEach(object => {
        cancelObjectLoads(object);
        object.removeFromParent();
        const cubeIndex = cubes.indexOf(object);
        if (cubeIndex !== -1) cubes.splice(cubeIndex, 1);
        disposeObjectMaterials(object);
    });
    if (objects === pendingMapEditorObjects) pendingMapEditorObjects = [];
}

function createMapObjectPreview() {
    removeMapObjectPreview();
    if (!mapEditorMode || !selectedMapObject) return;

    const previewName = `map_preview_${generateId()}`;
    mapObjectPreview = window.Obj(selectedMapObject, previewName, 0, 0, 0);

    // Loaders normally register objects as scene content. The preview is temporary.
    const cubeIndex = cubes.indexOf(mapObjectPreview);
    if (cubeIndex !== -1) cubes.splice(cubeIndex, 1);
    mapObjectPreview.userData.mapEditorPreview = true;
    syncMapObjectPreview();
}

function buildMapObjectPreviewBatch(previewObject) {
    if (previewObject.userData.mapPreviewBatch) return;

    const voxelMeshes = [];
    previewObject.traverse(child => {
        if (child.isMesh && !child.userData.mapPreviewBatch) {
            voxelMeshes.push(child);
        }
    });
    if (voxelMeshes.length === 0) return;

    previewObject.updateWorldMatrix(true, true);
    const inversePreviewMatrix = new THREE.Matrix4()
        .copy(previewObject.matrixWorld)
        .invert();
    const instanceMatrix = new THREE.Matrix4();
    const material = new THREE.MeshStandardMaterial({
        color: 0x00ffff,
        wireframe: true,
        transparent: true,
        opacity: 0.45,
        depthTest: false,
        depthWrite: false
    });
    const batch = new THREE.InstancedMesh(
        baseGeometry,
        material,
        voxelMeshes.length
    );

    voxelMeshes.forEach((mesh, index) => {
        instanceMatrix.multiplyMatrices(
            inversePreviewMatrix,
            mesh.matrixWorld
        );
        batch.setMatrixAt(index, instanceMatrix);
    });
    batch.instanceMatrix.needsUpdate = true;
    batch.computeBoundingBox();
    batch.computeBoundingSphere();
    batch.renderOrder = 999;
    batch.userData.mapPreviewBatch = true;

    voxelMeshes.forEach(mesh => {
        unindexCollisionObject(mesh);
        mesh.removeFromParent();
        const materials = Array.isArray(mesh.material)
            ? mesh.material
            : [mesh.material];
        materials.forEach(voxelMaterial => {
            if (voxelMaterial.map &&
                voxelMaterial.map.userData.threeDPLMaterials) {
                voxelMaterial.map.userData.threeDPLMaterials.delete(
                    voxelMaterial
                );
            }
            voxelMaterial.dispose();
        });
    });

    previewObject.add(batch);
    previewObject.userData.mapPreviewBatch = batch;
}

function syncMapObjectPreview() {
    if (!mapObjectPreview) return;

    const scale = Math.max(0.01, Number(mapObjectScaleInput.value) || 1);
    const rotationY = Number(mapObjectRotationInput.value) || 0;
    mapObjectPreview.visible = mapEditorMode;
    mapObjectPreview.position.copy(editorPointer.position);
    mapObjectPreview.scale.set(scale, scale, scale);
    mapObjectPreview.rotation.set(0, THREE.MathUtils.degToRad(-rotationY), 0, 'YXZ');

    if (mapObjectPreview.userData.loaded) {
        buildMapObjectPreviewBatch(mapObjectPreview);
    }

    // Style children as they arrive, then stop traversing a preview on every
    // animation frame once its asynchronous JSON load is complete.
    if (!mapObjectPreview.userData.mapPreviewStyleComplete) {
        mapObjectPreview.traverse(child => {
            if (!child.isMesh || child.userData.mapPreviewStyled) return;
            const materials = Array.isArray(child.material)
                ? child.material
                : [child.material];
            materials.forEach(material => {
                material.color.setHex(0x00ffff);
                if (material.map && material.map.userData.threeDPLMaterials) {
                    material.map.userData.threeDPLMaterials.delete(material);
                }
                material.map = null;
                material.wireframe = true;
                material.transparent = true;
                material.opacity = 0.45;
                material.depthTest = false;
                material.depthWrite = false;
                material.needsUpdate = true;
            });
            child.renderOrder = 999;
            child.userData.mapPreviewStyled = true;
        });
        if (mapObjectPreview.userData.loaded &&
            mapObjectPreview.userData.mapPreviewBatch) {
            mapObjectPreview.userData.mapPreviewStyleComplete = true;
        }
    }
}

function selectMapEditorObject(filename) {
    selectedMapObject = filename;
    selectedMapObjectLabel.textContent = `Selected: ${filename}`;
    selectedMapObjectLabel.style.color = '#cccccc';
    selectMapObjectButton.textContent = 'Change JSON Object';
    mapObjectGrid.querySelectorAll('.map-object-option').forEach(option => {
        option.classList.toggle('selected', option.dataset.filename === filename);
    });
    closeMapObjectPicker();
    createMapObjectPreview();
}

function objectLibraryAssetUrl(relativePath) {
    const path = 'Objects/' + relativePath
        .split('/')
        .map(segment => encodeURIComponent(segment))
        .join('/');
    return `${path}?v=${encodeURIComponent(mapObjectLibraryRevision)}`;
}

function normalizeObjectPreviewReference(value, fallback) {
    let reference = String(value || fallback).trim().replace(/\\/g, '/');
    while (reference.startsWith('./')) reference = reference.substring(2);
    if (/^\/?Objects\//i.test(reference)) {
        reference = reference.replace(/^\/?Objects\//i, '');
    }

    const pathOnly = reference.split(/[?#]/, 1)[0];
    if (!pathOnly || pathOnly.startsWith('/') ||
        pathOnly.split('/').includes('..') ||
        !/\.(?:png|jpe?g|webp|gif)$/i.test(pathOnly)) {
        return fallback;
    }
    return reference;
}

function normalizeMapObjectLibraryEntry(record) {
    const rawFile = typeof record === 'string' ? record : record?.file;
    const filename = normalizeObjectJSONReference(rawFile || '');
    if (isDirectAssetUrl(filename) || !isJSONObjectReference(filename) ||
        filename.toLowerCase() === 'objects-manifest.json') {
        return null;
    }

    const fallbackPreview = previewPathForMapObject(filename);
    return {
        file: filename,
        label: String(record?.label || filename),
        preview: normalizeObjectPreviewReference(
            record?.preview,
            fallbackPreview
        ),
        personal: false
    };
}

async function loadMapObjectLibrary() {
    try {
        // The changing query also bypasses cached 404 responses after the
        // manifest is uploaded to a static host for the first time.
        const manifestUrl =
            `Objects/objects-manifest.json?refresh=${Date.now()}`;
        const response = await fetch(manifestUrl, {
            cache: 'no-store'
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();
        const records = Array.isArray(data) ? data : data.objects;
        if (!Array.isArray(records)) {
            throw new Error('Manifest has no objects array.');
        }

        const seen = new Set();
        const manifestObjects = records
            .map(normalizeMapObjectLibraryEntry)
            .filter(entry => {
                if (!entry || seen.has(entry.file)) return false;
                seen.add(entry.file);
                return true;
            })
            .sort((a, b) => a.label.localeCompare(b.label));

        if (manifestObjects.length === 0) {
            throw new Error('Manifest contains no JSON objects.');
        }

        sharedMapObjects = manifestObjects;
        rebuildMapObjectLibrary();
        mapObjectLibraryRevision = String(data.revision || Date.now());
        return true;
    } catch (error) {
        mapObjectLibraryMessage =
            `Could not refresh shared object list; showing ${availableMapObjects.length} available objects.`;
        mapObjectLibraryMessageColor = '#ffcc66';
        console.warn('Object manifest load error:', error);
        return false;
    }
}

function renderMapObjectChoices(filterText = '') {
    const renderId = ++mapObjectPickerRenderId;
    const filter = filterText.trim().toLowerCase();
    const fragment = document.createDocumentFragment();
    mapObjectGrid.innerHTML = '';

    const matchingObjects = availableMapObjects.filter(entry =>
        entry.file.toLowerCase().includes(filter) ||
        entry.label.toLowerCase().includes(filter)
    );

    let loadedPreviews = 0;
    let failedPreviews = 0;
    const previewCount = matchingObjects.filter(entry => !entry.personal).length;
    const updateLibraryStatus = () => {
        if (renderId !== mapObjectPickerRenderId) return;
        const matchMessage = filter
            ? ` • ${matchingObjects.length} search matches`
            : '';
        const previewMessage = previewCount > 0
            ? ` • previews ${loadedPreviews}/${previewCount}`
            : '';
        const failureMessage = failedPreviews > 0
            ? ` • ${failedPreviews} preview files missing`
            : '';
        mapObjectLibraryStatus.textContent =
            mapObjectLibraryMessage + matchMessage + previewMessage + failureMessage;
        mapObjectLibraryStatus.style.color = failedPreviews > 0
            ? '#ff7777'
            : mapObjectLibraryMessageColor;
    };
    updateLibraryStatus();

    matchingObjects.forEach(entry => {
        const option = document.createElement('button');
        option.type = 'button';
        option.className = 'map-object-option';
        option.dataset.filename = entry.file;
        option.title = entry.file;
        option.classList.toggle('selected', entry.file === selectedMapObject);

        const previewFrame = document.createElement('span');
        previewFrame.className = 'map-object-preview';
        const placeholder = document.createElement('span');
        placeholder.className = 'map-object-preview-placeholder';
        if (entry.personal) {
            placeholder.textContent = 'My object\nNo preview';
            placeholder.title = 'Personal object (no preview image uploaded)';
            placeholder.style.display = 'flex';
            previewFrame.appendChild(placeholder);
        } else {
            const preview = document.createElement('img');
            preview.alt = `${entry.label} preview`;
            preview.loading = 'lazy';
            preview.decoding = 'async';
            placeholder.textContent = 'Preview file missing';
            placeholder.title = `Missing Objects/${entry.preview}`;
            placeholder.style.display = 'none';
            preview.onload = () => {
                if (renderId !== mapObjectPickerRenderId) return;
                loadedPreviews++;
                updateLibraryStatus();
            };
            preview.onerror = () => {
                if (renderId !== mapObjectPickerRenderId) return;
                failedPreviews++;
                preview.style.display = 'none';
                placeholder.style.display = 'flex';
                updateLibraryStatus();
            };
            preview.src = objectLibraryAssetUrl(entry.preview);
            previewFrame.append(preview, placeholder);
        }

        const label = document.createElement('span');
        label.className = 'map-object-option-label';
        label.textContent = entry.label;
        option.append(previewFrame, label);
        option.onclick = () => selectMapEditorObject(entry.file);
        fragment.appendChild(option);
    });

    if (matchingObjects.length === 0) {
        const noMatches = document.createElement('div');
        noMatches.className = 'map-object-no-results';
        noMatches.textContent = 'No matching JSON objects.';
        fragment.appendChild(noMatches);
    }

    mapObjectGrid.appendChild(fragment);
}

function closeMapObjectPicker() {
    mapObjectPicker.style.display = 'none';
}

function isDirectAssetUrl(value) {
    return /^(?:https?:|data:|blob:)/i.test(value);
}

function normalizeObjectJSONReference(value) {
    let reference = String(value || '').trim().replace(/\\/g, '/');
    if (isDirectAssetUrl(reference)) return reference;

    while (reference.startsWith('./')) {
        reference = reference.substring(2);
    }
    if (reference.startsWith('/Objects/')) {
        reference = reference.substring('/Objects/'.length);
    } else if (/^Objects\//i.test(reference)) {
        reference = reference.substring('Objects/'.length);
    }

    const pathOnly = reference.split(/[?#]/, 1)[0];
    if (!pathOnly ||
        pathOnly.startsWith('/') ||
        /^[a-z]:\//i.test(pathOnly) ||
        pathOnly.split('/').includes('..')) {
        throw new Error(
            'Map object files must be JSON files inside the Objects/ directory.'
        );
    }
    return reference;
}

function objectJSONUrl(value) {
    const reference = normalizeObjectJSONReference(value);
    return isDirectAssetUrl(reference) ? reference : programAssetUrl('Objects', reference);
}

function isJSONObjectReference(value) {
    if (!value) return false;
    const withoutQuery = String(value).split(/[?#]/, 1)[0];
    return /\.json$/i.test(withoutQuery);
}

function finiteMapNumber(value, fallback) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
}

function normalizeMapEntry(entry, index) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
        throw new Error(`Map entry ${index + 1} is not an object.`);
    }

    const primitive = String(entry.primitive || '').toLowerCase();
    const isInlineCube = primitive === 'cube';
    const file = isInlineCube
        ? ''
        : normalizeObjectJSONReference(
            entry.file || entry.filename || entry.objectFile || ''
        );

    if (!isInlineCube && !isJSONObjectReference(file)) {
        throw new Error(
            `Map entry ${index + 1} must contain a JSON object file or cube primitive.`
        );
    }

    const scale = Math.max(0.01, finiteMapNumber(entry.scale, 1));
    const normalized = {
        name: String(entry.name || '').trim(),
        x: finiteMapNumber(entry.x, 0),
        y: finiteMapNumber(entry.y, 0),
        z: finiteMapNumber(entry.z, 0),
        rotationY: finiteMapNumber(entry.rotationY, 0),
        scale
    };

    if (isInlineCube) {
        normalized.primitive = 'cube';
        normalized.color = Array.isArray(entry.color)
            ? entry.color.slice(0, 3).map(component =>
                Math.max(0, Math.min(255, finiteMapNumber(component, 136))))
            : (entry.color !== undefined ? entry.color : [136, 136, 136]);
        normalized.alpha = Math.max(
            0,
            Math.min(1, finiteMapNumber(entry.alpha, 1))
        );
        normalized.voxelName = String(entry.voxelName || '').trim();
    } else {
        normalized.file = file;
    }

    return normalized;
}

function normalizeMapDocument(data) {
    const entries = Array.isArray(data)
        ? data
        : (data && Array.isArray(data.objects) ? data.objects : null);

    if (!entries) throw new Error('Map JSON has no objects array.');
    return entries.map((entry, index) => normalizeMapEntry(entry, index));
}

function instantiateMapEntry(entry, fallbackName) {
    const instanceName = entry.name || fallbackName;
    const object = entry.primitive === 'cube'
        ? createInlineMapCube(entry, instanceName)
        : window.Obj(entry.file, instanceName, 0, 0, 0);

    object.position.set(entry.x, entry.y, entry.z);
    object.rotation.set(
        0,
        THREE.MathUtils.degToRad(-entry.rotationY),
        0,
        'YXZ'
    );
    object.scale.set(entry.scale, entry.scale, entry.scale);
    object.userData.mapEntryDefinition = entry;
    object.userData.sourceFile = entry.file || '';
    object.userData.mapPrimitive = entry.primitive || '';
    return object;
}

function requiredMapObjectFilename(object) {
    const sourceFile = object.userData.mapEntryDefinition?.file ||
        object.userData.sourceFile || object.name;
    return isDirectAssetUrl(sourceFile)
        ? sourceFile
        : `Objects/${sourceFile}`;
}

function requiredMapObjectError(object) {
    const filename = requiredMapObjectFilename(object);
    const reason = object.userData.loadError || 'Unknown loading error';
    return `Required map object "${filename}" could not be loaded: ${reason}`;
}

function placeMapEditorObject(entry) {
    const normalizedEntry = normalizeMapEntry(entry, 0);
    const object = instantiateMapEntry(
        normalizedEntry,
        `map_object_${generateId()}`
    );
    object.userData.mapEditorObject = true;
    object.userData.ready.then(() =>
        scheduleMapEditorObjectOptimization(object));
    updateMapObjectCount();
    return object;
}

function serializeMapEditor() {
    const objects = cubes
        .filter(object => object.userData.mapEditorObject)
        .map(object => {
            const entry = {
                name: object.name,
                x: object.position.x,
                y: object.position.y,
                z: object.position.z,
                rotationY: -THREE.MathUtils.radToDeg(object.rotation.y),
                scale: object.scale.x
            };

            const definition = object.userData.mapEntryDefinition || {};
            if (definition.primitive === 'cube') {
                entry.primitive = 'cube';
                entry.color = definition.color;
                if (definition.alpha !== 1) {
                    entry.alpha = definition.alpha;
                }
                if (definition.voxelName) {
                    entry.voxelName = definition.voxelName;
                }
            } else {
                entry.file = definition.file || object.userData.sourceFile;
            }

            return entry;
        });
    return { format: '3dpl-map-v1', objects };
}

function exportMapEditorJSON() {
    const mapData = serializeMapEditor();
    const blob = new Blob([JSON.stringify(mapData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const download = document.createElement('a');
    download.href = url;
    download.download = currentMapName || 'my_map.json';
    download.click();
    URL.revokeObjectURL(url);
}

selectMapObjectButton.onclick = async () => {
    const opening = mapObjectPicker.style.display !== 'flex';
    if (!opening) {
        closeMapObjectPicker();
        return;
    }

    mapObjectPicker.style.display = 'flex';
    mapObjectSearch.value = '';
    mapObjectLibraryMessage =
        `Refreshing server list; showing ${availableMapObjects.length} objects...`;
    mapObjectLibraryMessageColor = '#aaaaaa';
    renderMapObjectChoices('');
    const personalLibraryNick = loggedInNick;
    await Promise.all([
        loadMapObjectLibrary(),
        personalLibraryNick ? refreshPersonalObjectLibrary().catch(error => {
            if (loggedInNick === personalLibraryNick &&
                (error.status === 401 || error.status === 403)) {
                setLoggedInNick('');
            }
            console.warn('Personal object list error:', error);
        }) : Promise.resolve()
    ]);

    if (mapObjectPicker.style.display === 'flex') {
        renderMapObjectChoices('');
        mapObjectSearch.focus();
    }
};
closeMapObjectPickerButton.onclick = closeMapObjectPicker;
mapObjectSearch.oninput = () => renderMapObjectChoices(mapObjectSearch.value);
rotateMapObjectButton.onclick = () => {
    const currentRotation = Number(mapObjectRotationInput.value) || 0;
    mapObjectRotationInput.value = ((currentRotation + 90) % 360 + 360) % 360;
    syncMapObjectPreview();
};

function centerMapPointerOnView() {
    editorPointer.position.set(
        Math.round(camera.position.x),
        Number(mapObjectYInput.value) || 0,
        Math.round(camera.position.z)
    );
    syncMapObjectPreview();
}

centerMapPointerButton.onclick = centerMapPointerOnView;

function frameMapEditorObjects() {
    const objects = cubes.filter(object => object.userData.mapEditorObject);
    if (objects.length === 0) return;

    scene.updateMatrixWorld(true);
    const bounds = new THREE.Box3();
    objects.forEach(object => bounds.expandByObject(object));
    if (bounds.isEmpty()) return;

    const center = bounds.getCenter(new THREE.Vector3());
    const size = bounds.getSize(new THREE.Vector3());
    const verticalFov = THREE.MathUtils.degToRad(camera.fov);
    const requiredHeightForZ = size.z / (2 * Math.tan(verticalFov / 2));
    const horizontalFov = 2 * Math.atan(
        Math.tan(verticalFov / 2) * camera.aspect
    );
    const requiredHeightForX = size.x / (2 * Math.tan(horizontalFov / 2));
    const height = Math.max(10, requiredHeightForX, requiredHeightForZ) * 1.25;

    camera.position.set(center.x, bounds.max.y + height, center.z);
    camera.rotation.set(-Math.PI / 2, 0, 0, 'YXZ');
    const mapDepth = camera.position.y - bounds.min.y;
    camera.far = Math.max(1000, mapDepth * 2, size.length() * 2);
    camera.updateProjectionMatrix();
    editorPointer.position.x = Math.round(center.x);
    editorPointer.position.z = Math.round(center.z);
}

document.getElementById('btn-export-map').onclick = exportMapEditorJSON;
document.getElementById('btn-load-map').onclick = () => document.getElementById('file-input-map').click();

function reportMapEditorLoadError(error) {
    setDebugError(`Map load error: ${error.message}`);
    selectedMapObjectLabel.textContent = `Map load failed: ${error.message}`;
    selectedMapObjectLabel.style.color = '#ff7777';
    console.error('Map load error:', error);
}

async function loadMapEditorData(mapData, displayName = 'map.json') {
    const loadToken = ++mapEditorLoadToken;
    let stagedObjects = [];

    try {
        // Validate every entry before replacing the map currently in the editor.
        const entries = normalizeMapDocument(mapData);
        discardPendingMapEditorObjects();
        entries.forEach((entry, index) => {
            const object = instantiateMapEntry(
                entry,
                `map_object_${index + 1}`
            );
            stagedObjects.push(object);
            object.removeFromParent();
            const cubeIndex = cubes.indexOf(object);
            if (cubeIndex !== -1) cubes.splice(cubeIndex, 1);
        });
        pendingMapEditorObjects = stagedObjects;
        selectedMapObjectLabel.textContent = `Loading map: ${displayName}`;
        selectedMapObjectLabel.style.color = '#cccccc';

        await Promise.all(stagedObjects.map(object => object.userData.ready));
        if (!mapEditorMode || loadToken !== mapEditorLoadToken) {
            discardPendingMapEditorObjects(stagedObjects);
            return false;
        }

        const failedObject = stagedObjects.find(object => object.userData.loadError);
        if (failedObject) throw new Error(requiredMapObjectError(failedObject));

        pendingMapEditorObjects = [];
        removeMapObjectPreview();
        window.cs();
        stagedObjects.forEach(object => {
            scene.add(object);
            cubes.push(object);
            object.userData.mapEditorObject = true;
            scheduleMapEditorObjectOptimization(object);
        });
        createMapObjectPreview();
        updateMapObjectCount();
        frameMapEditorObjects();
        currentMapName = String(displayName || 'my_map.json').replace(/\.json$/i, '') + '.json';
        selectedMapObjectLabel.textContent = `Loaded map: ${currentMapName}`;
        selectedMapObjectLabel.style.color = '#cccccc';
        return true;
    } catch (error) {
        discardPendingMapEditorObjects(stagedObjects);
        if (loadToken === mapEditorLoadToken) reportMapEditorLoadError(error);
        throw error;
    }
}

document.getElementById('file-input-map').onchange = event => {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async loadEvent => {
        try {
            const mapData = JSON.parse(loadEvent.target.result);
            await loadMapEditorData(mapData, file.name);
        } catch (error) {
            // loadMapEditorData reports its own failures. JSON parsing happens
            // before it is called, so report that error here.
            if (error instanceof SyntaxError) reportMapEditorLoadError(error);
        }
        event.target.value = '';
    };
    reader.onerror = () => {
        const message = reader.error ? reader.error.message : 'Could not read the file.';
        reportMapEditorLoadError(new Error(message));
        event.target.value = '';
    };
    reader.readAsText(file);
};

// --- Debug UI Helpers ---
const setDebugError = (msg) => {
    if (sharedGameId) {
        sharedPlayerError = String(msg).replace(/<[^>]*>/g, '');
        showSharedPlayerStatus(sharedPlayerError, true);
    }
    const consoleEl = document.getElementById('debug-console');
    if(consoleEl) consoleEl.innerHTML = `<span style="color: #ff5555;">${msg}</span>`;
};

const clearDebug = () => {
    const consoleEl = document.getElementById('debug-console');
    if(consoleEl) consoleEl.innerHTML = `<span style="color: #55ff55;">Running OK...</span>`;
};

// --- Account UI and session state ---
const authModal = document.getElementById('auth-modal');
const signupForm = document.getElementById('signup-form');
const loginForm = document.getElementById('login-form');
const authDialogTitle = document.getElementById('auth-dialog-title');
const authMessage = document.getElementById('auth-message');
const accountStatus = document.getElementById('account-status');

function setLoggedInNick(nick) {
    if (sharedGameId) return;
    const normalizedNick = nick || '';
    const accountChanged = normalizedNick !== loggedInNick;
    if (accountChanged) {
        clearLoadedSounds();
        closeCloudFileModal();
        clearPersonalObjectCaches();
        clearPersonalTextureCache();
        personalMapObjects = [];
        personalTextureNames = [];
        rebuildMapObjectLibrary();
        if (mapObjectPicker.style.display === 'flex') {
            renderMapObjectChoices(mapObjectSearch.value);
        }
        if (texturePicker.style.display === 'block') {
            renderTextureChoices(textureSearch.value);
        }
    }
    loggedInNick = normalizedNick;
    if (loggedInNick) {
        sessionStorage.setItem('3dplLoggedInNick', loggedInNick);
        accountStatus.textContent = loggedInNick;
        accountStatus.title = `Logged in as ${loggedInNick}`;
    } else {
        sessionStorage.removeItem('3dplLoggedInNick');
        accountStatus.textContent = 'Not logged in';
        accountStatus.title = 'Not logged in';
    }

    if (loggedInNick && (accountChanged || personalMapObjects.length === 0)) {
        const expectedNick = loggedInNick;
        Promise.all([
            refreshPersonalObjectLibrary(),
            refreshPersonalTextureLibrary()
        ]).catch(error => {
            if (expectedNick !== loggedInNick) return;
            if (error.status === 401 || error.status === 403) {
                setLoggedInNick('');
            } else {
                console.warn('Personal library refresh failed:', error);
            }
        });
    }
}

setLoggedInNick(loggedInNick);

function openAuthModal(mode) {
    if (document.pointerLockElement) document.exitPointerLock();
    const isSignup = mode === 'signup';
    signupForm.style.display = isSignup ? 'flex' : 'none';
    loginForm.style.display = isSignup ? 'none' : 'flex';
    authDialogTitle.textContent = isSignup ? 'Create account' : 'Log in';
    authMessage.textContent = '';
    authModal.classList.add('open');
    authModal.setAttribute('aria-hidden', 'false');
    const firstInput = (isSignup ? signupForm : loginForm).querySelector('input');
    setTimeout(() => firstInput.focus(), 0);
}

function closeAuthModal() {
    authModal.classList.remove('open');
    authModal.setAttribute('aria-hidden', 'true');
    if (document.activeElement) document.activeElement.blur();
}

document.getElementById('btn-open-signup').onclick = () => openAuthModal('signup');
document.getElementById('btn-open-login').onclick = () => openAuthModal('login');
document.getElementById('btn-close-auth').onclick = closeAuthModal;
authModal.addEventListener('pointerdown', event => {
    if (event.target === authModal) closeAuthModal();
});

async function readApiResponse(response) {
    let body;
    try {
        body = await response.json();
    } catch (error) {
        throw new Error('The server returned an invalid response.');
    }
    if (!response.ok || body.ok !== true || body.error) {
        const requestError = new Error(body.message || body.error || `Request failed (${response.status})`);
        requestError.status = response.status;
        requestError.code = typeof body.error === 'string' ? body.error : '';
        requestError.payload = body;
        throw requestError;
    }
    return body;
}

function activeAccountChangedError() {
    const error = new Error(
        'The active account changed while this request was running. Please try again.'
    );
    error.status = 409;
    error.code = 'session_scope_mismatch';
    return error;
}

function assertActiveAccount(expectedNick) {
    if (!expectedNick || loggedInNick !== expectedNick) {
        throw activeAccountChangedError();
    }
}

async function postAccountForm(url, fields) {
    const response = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
        body: new URLSearchParams(fields)
    });
    return readApiResponse(response);
}

signupForm.addEventListener('submit', async event => {
    event.preventDefault();
    const data = new FormData(signupForm);
    const password = String(data.get('password') || '');
    if (password !== String(data.get('confirm_password') || '')) {
        authMessage.textContent = 'The passwords do not match.';
        return;
    }

    const submitButton = signupForm.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    authMessage.textContent = 'Creating account...';
    try {
        const result = await postAccountForm('server_side/register.php', {
            nick: String(data.get('nick') || '').trim(),
            email: String(data.get('email') || '').trim(),
            password
        });
        window.alert('Signup successful. You can now log in.');
        signupForm.reset();
        openAuthModal('login');
        loginForm.elements.nick.value = result.nick || '';
    } catch (error) {
        authMessage.textContent = error.message;
    } finally {
        submitButton.disabled = false;
    }
});

loginForm.addEventListener('submit', async event => {
    event.preventDefault();
    const data = new FormData(loginForm);
    const submitButton = loginForm.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    authMessage.textContent = 'Logging in...';
    try {
        const result = await postAccountForm('server_side/login.php', {
            nick: String(data.get('nick') || '').trim(),
            password: String(data.get('password') || '')
        });
        setLoggedInNick(result.nick || String(data.get('nick') || '').trim());
        loginForm.reset();
        closeAuthModal();
        window.alert('Login successful');
    } catch (error) {
        setLoggedInNick('');
        authMessage.textContent = error.message;
        window.alert('Login failed');
    } finally {
        submitButton.disabled = false;
    }
});

// --- Bulletproof Input System ---
window.Input = { 
    _keys: {}, 
    GetKey: function(k) { return !!this._keys[k]; } 
};
window.KeyCode = { 
    RightArrow: 'ArrowRight', LeftArrow: 'ArrowLeft', UpArrow: 'ArrowUp', DownArrow: 'ArrowDown',
    Space: 'Space', LeftControl: 'ControlLeft', RightControl: 'ControlRight', C: 'KeyC', E: 'KeyE', Q: 'KeyQ', A: 'KeyA', Z: 'KeyZ', X: 'KeyX', W: 'KeyW', S: 'KeyS', D: 'KeyD', R: 'KeyR', F: 'KeyF'
};

const gameplayKeyCodes = new Set(Object.values(window.KeyCode));

window.addEventListener('keydown', e => {
    const activeTag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
    const isTyping = activeTag === 'input' || activeTag === 'textarea' || activeTag === 'select' || document.activeElement?.isContentEditable;

    if (sharedGameId) {
        if (sharedPlayerAlertOpen) return;
        if (gameplayKeyCodes.has(e.code)) e.preventDefault();
        if (sharedPlayerReady) window.Input._keys[e.code] = true;
        unlockSharedPlayerAudio();
        return;
    }

    if (e.code === 'Escape' && authModal.classList.contains('open')) {
        e.preventDefault();
        closeAuthModal();
        return;
    }

    if (e.code === 'Escape' && document.getElementById('cloud-object-modal').classList.contains('open')) {
        e.preventDefault();
        closeCloudObjectModal();
        return;
    }

    if (e.code === 'Escape' && document.getElementById('cloud-file-modal').classList.contains('open')) {
        e.preventDefault();
        closeCloudFileModal();
        return;
    }

    if (document.querySelector('.app-modal.open')) return;

    if (e.code === 'Escape' && mapObjectPicker.style.display === 'flex') {
        e.preventDefault();
        closeMapObjectPicker();
        return;
    }

    if ((e.code === 'Space' && !isTyping) || (isExecuting && gameplayKeyCodes.has(e.code))) {
        e.preventDefault();
    }
    if (e.code === 'KeyQ' && document.pointerLockElement) document.exitPointerLock();
    if (isTyping) return;
    if (objectEditorMode && e.code === 'KeyC') {
        levelObjectEditorView();
        return;
    }
    
    window.Input._keys[e.code] = true;
}, true);

window.addEventListener('keyup', e => {
    window.Input._keys[e.code] = false;
}, true);

// Touch controls write to the same key-state table as physical keyboards, so
// Input.GetKey works unchanged in programs, tutorials, and editor modes.
const mobileControllerToggle = document.getElementById('mobile-controller-toggle');
const mobileController = document.getElementById('mobile-controller');
const mobileControlButtons = [...mobileController.querySelectorAll('[data-code]')];

function releaseMobileControls() {
    mobileControlButtons.forEach(button => {
        window.Input._keys[button.dataset.code] = false;
        if (button.dataset.alias) window.Input._keys[button.dataset.alias] = false;
        button.classList.remove('pressed');
    });
}

mobileControllerToggle.addEventListener('click', () => {
    const isOpen = mobileController.classList.toggle('open');
    mobileControllerToggle.setAttribute('aria-expanded', String(isOpen));
    mobileControllerToggle.setAttribute('aria-label', `${isOpen ? 'Close' : 'Open'} onscreen controller`);
    mobileController.setAttribute('aria-hidden', String(!isOpen));
    if (!isOpen) releaseMobileControls();
});

document.getElementById('mobile-controller-start').addEventListener('click', event => {
    event.preventDefault();
    if (sharedGameId) {
        if (!sharedPlayerReady || sharedPlayerAlertOpen) return;
        isExecuting = !isExecuting;
        event.currentTarget.textContent = isExecuting ? 'PAUSE' : 'RESUME';
        unlockSharedPlayerAudio();
        return;
    }
    document.getElementById('btn-run').click();
});

mobileControlButtons.forEach(button => {
    const setPressed = pressed => {
        window.Input._keys[button.dataset.code] = pressed;
        // Compatibility aliases keep older tutorials (Z and left Ctrl) usable
        // while the visible controller presents the requested S and right Ctrl.
        if (button.dataset.alias) window.Input._keys[button.dataset.alias] = pressed;
        button.classList.toggle('pressed', pressed);
    };
    button.addEventListener('pointerdown', event => {
        event.preventDefault();
        button.setPointerCapture(event.pointerId);
        setPressed(true);
    });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(type => {
        button.addEventListener(type, () => setPressed(false));
    });
    button.addEventListener('contextmenu', event => event.preventDefault());
});

function releaseEditorInput() {
    releaseMobileControls();
    if (objectEditorMode || sharedGameId) window.Input._keys = {};
    clearObjectMouseMovement();
}

window.addEventListener('blur', releaseEditorInput);
document.addEventListener('visibilitychange', () => {
    if (document.hidden) releaseEditorInput();
});

document.getElementById('obj-mouse-sensitivity').addEventListener('input', event => {
    objectMouseSensitivity = Number(event.target.value) * 0.00005;
    clearObjectMouseMovement();
});
document.getElementById('btn-level-obj-view').addEventListener('click', levelObjectEditorView);

renderer.domElement.addEventListener('mousedown', (event) => {
    if (document.activeElement) document.activeElement.blur();
    if (objectEditorMode && event.button === 0 && !mouseLookEnabled) document.body.requestPointerLock();
});

document.addEventListener('pointerlockchange', () => {
    mouseLookEnabled = document.pointerLockElement === document.body;
    clearObjectMouseMovement();
    skipNextMouseMove = mouseLookEnabled;
    if (!mouseLookEnabled && objectEditorMode) releaseEditorInput();
    document.getElementById('crosshair').style.display = (mouseLookEnabled && objectEditorMode) ? 'block' : 'none';
});

document.addEventListener('mousemove', (e) => {
    if (mouseLookEnabled && objectEditorMode) {
        // Some browsers report the cursor recentering as the first movement.
        if (skipNextMouseMove) {
            skipNextMouseMove = false;
            return;
        }
        if (!Number.isFinite(e.movementX) || !Number.isFinite(e.movementY)) return;
        pendingMouseYaw -= e.movementX * objectMouseSensitivity;
        pendingMousePitch -= e.movementY * objectMouseSensitivity;
    }
});

// --- Ported 3DPL Functions ---
window.Color = { white: 0xffffff, black: 0x000000, blue: 0x0000ff, green: 0x00ff00, red: 0xff0000, yellow: 0xffff00 };
window.Time = { deltaTime: 0 };
window.Mathf = Math;

// Injects Unity-like properties into Three.js objects to support legacy math
function injectUnityCompatibility(mesh) {
    mesh.transform = mesh; // Fixes the vars.car.transform is undefined error
    Object.defineProperty(mesh, 'eulerAngles', {
        get: function() {
            return {
                x: -this.rotation.x * (180 / Math.PI),
                y: -this.rotation.y * (180 / Math.PI),
                z: -this.rotation.z * (180 / Math.PI)
            };
        }
    });
}

// Obj() collider meshes are nested below groups, but looking them up by name
// must not require traversing a 60,000-voxel map every update substep.
const collisionObjectNameIndex = new Map();

function indexCollisionObject(object) {
    if (!object || !object.name) return;
    let matches = collisionObjectNameIndex.get(object.name);
    if (!matches) {
        matches = new Set();
        collisionObjectNameIndex.set(object.name, matches);
    }
    matches.add(object);
}

function unindexCollisionObject(object) {
    if (!object || !object.name) return;
    const matches = collisionObjectNameIndex.get(object.name);
    if (!matches) return;
    matches.delete(object);
    if (matches.size === 0) collisionObjectNameIndex.delete(object.name);
}

function belongsToActiveCube(object) {
    let root = object;
    while (root.parent && root.parent !== scene) root = root.parent;
    return root.parent === scene && cubes.includes(root);
}

function traverseObjectTreeRaw(root, callback) {
    callback(root);
    for (const child of root.children) {
        // Render batches are an internal mirror of original map voxels. They
        // never participate in public name lookup or collision discovery.
        if (child.userData.mapRenderBatch) continue;
        traverseObjectTreeRaw(child, callback);
    }
}

function forEachObjectMaterial(object, callback) {
    object.traverse(child => {
        if (!child.isMesh || !child.material) return;
        const materials = Array.isArray(child.material) ? child.material : [child.material];
        materials.forEach(material => callback(material, child));
    });
}

function disposeObjectMaterials(object) {
    forEachObjectMaterial(object, material => {
        if (material.map && material.map.userData.threeDPLMaterials) {
            material.map.userData.threeDPLMaterials.delete(material);
        }
        material.dispose();
    });
}

function cancelObjectLoads(object) {
    object.traverse(child => {
        child.userData.cancelled = true;
        unindexCollisionObject(child);
    });
}

window.qb = function(name, x, y, z) {
    const material = new THREE.MeshStandardMaterial({ color: 0x888888, transparent: true, opacity: 1.0 });
    const mesh = new THREE.Mesh(baseGeometry, material);
    mesh.position.set(x, y, z);
    mesh.name = name;
    injectUnityCompatibility(mesh);
    scene.add(mesh);
    cubes.push(mesh);
    return mesh;
};

window.cl = function(name, colorHex) {
    cubes.forEach(c => { 
        if (c.name === name) {
            forEachObjectMaterial(c, material => material.color.setHex(colorHex));
        }
    });
};

window.alpha = function(name, alphaVal) {
    cubes.forEach(c => { 
        if (c.name === name) {
            forEachObjectMaterial(c, material => {
                const needsTransparency = materialNeedsTransparency(
                    material,
                    alphaVal
                );
                if (material.transparent !== needsTransparency) {
                    material.transparent = needsTransparency;
                    material.needsUpdate = true;
                }
                material.opacity = alphaVal;
            });
        }
    });
};

window.tx = function(name, textureName, source, wrap) {
    wrap = wrap || 6;
    const filename = usableTextureFilename(textureName);
    if (!filename) return;
    loadSharedTexture(filename);
    
    cubes.forEach(c => { 
        if (c.name === name) {
            forEachObjectMaterial(c, (material, mesh) => {
                assignSharedTexture(material, filename);
                material.needsUpdate = true;
                mesh.userData.textureName = filename;
                mesh.userData.wrap = wrap;

                if (wrap === 1 || wrap === "1") {
                    mesh.geometry = getWrappedBaseGeometry();
                } else {
                    if (mesh.geometry !== baseGeometry) mesh.geometry = baseGeometry;
                }
            });
        }
    });
};

// Transforms 
window.mv = function(name, x, y, z) {
    if (name === "camera") {
        camera.translateX(x); 
        camera.translateY(y); 
        camera.translateZ(-z); 
        return;
    }
    cubes.forEach(c => { 
        if (c.name === name) {
            c.translateX(x); 
            c.translateY(y); 
            c.translateZ(-z);
        }
    });
};

window.sp = function(name, x, y, z) {
    if (name === "camera") { camera.position.set(x, y, z); return; }
    cubes.forEach(c => { if (c.name === name) c.position.set(x, y, z); });
};
window.cp = window.sp;

window.rt = function(name, x, y, z) {
    const radX = -x * (Math.PI / 180);
    const radY = -y * (Math.PI / 180);
    const radZ = -z * (Math.PI / 180);
    if (name === "camera") {
        camera.rotateX(radX); 
        camera.rotateY(radY); 
        camera.rotateZ(radZ);
        return;
    }
    cubes.forEach(c => {
        if (c.name === name) {
            c.rotateX(radX); 
            c.rotateY(radY); 
            c.rotateZ(radZ);
        }
    });
};

window.an = function(name, x, y, z) {
    const radX = -x * (Math.PI / 180);
    const radY = -y * (Math.PI / 180);
    const radZ = -z * (Math.PI / 180);
    if (name === "camera") { camera.rotation.set(radX, radY, radZ, 'YXZ'); return; }
    cubes.forEach(c => {
        if (c.name === name) c.rotation.set(radX, radY, radZ, 'YXZ');
    });
};

window.sr = window.an;

window.sc = function(name, x, y, z) {
    cubes.forEach(c => { if (c.name === name) c.scale.set(x, y, z); });
};

// State & Group Collision 
window.ex = function(name) {
    return cubes.some(c => c.name === name);
};

window.eq = function(nameA, nameB) {
    const objA = cubes.find(c => c.name === nameA);
    if (!objA) return;
    
    if (nameB === "camera") {
        objA.position.copy(camera.position);
        objA.rotation.copy(camera.rotation);
    } else {
        const objB = cubes.find(c => c.name === nameB);
        if (objB) {
            objA.position.copy(objB.position);
            objA.rotation.copy(objB.rotation);
        }
    }
};

function findCollisionObjects(target) {
    if (target === "camera") return [camera];
    if (target && target.isObject3D) return [target];
    if (typeof target !== 'string') return [];

    if (vars[target] && vars[target].isObject3D) return [vars[target]];

    const topLevelMatches = [...new Set(
        cubes.filter(object => object.name === target)
    )];
    if (topLevelMatches.length > 0) return topLevelMatches;

    const indexedMatches = collisionObjectNameIndex.get(target);
    if (indexedMatches) {
        const activeMatches = [];
        indexedMatches.forEach(object => {
            // A user may directly rename an Object3D. Drop that stale key and
            // let the traversal fallback discover its new name when requested.
            if (object.name !== target) {
                indexedMatches.delete(object);
            } else if (belongsToActiveCube(object)) {
                activeMatches.push(object);
            } else {
                indexedMatches.delete(object);
            }
        });
        if (indexedMatches.size === 0) collisionObjectNameIndex.delete(target);
        if (activeMatches.length > 0) return [...new Set(activeMatches)];
    }

    // Collider blocks loaded inside an Obj() group are not top-level cubes.
    // Keep a fallback for objects renamed or added directly by user code.
    const nestedMatches = new Set();
    cubes.forEach(root => {
        traverseObjectTreeRaw(root, child => {
            if (child !== root && child.name === target) {
                nestedMatches.add(child);
                indexCollisionObject(child);
            }
        });
    });
    return [...nestedMatches];
}

function collisionVoxelDataFromObjectData(data) {
    if (Array.isArray(data)) return data;
    if (data && Array.isArray(data.voxels)) return data.voxels;
    if (data && Array.isArray(data.objects)) return data.objects;
    return null;
}

function buildVoxelCollisionNode(entries) {
    const bounds = new THREE.Box3().makeEmpty();
    entries.forEach(entry => bounds.union(entry.box));

    if (entries.length <= 12) {
        return { bounds, boxes: entries.map(entry => entry.box) };
    }

    const size = bounds.getSize(new THREE.Vector3());
    const axis = size.x >= size.y && size.x >= size.z
        ? 0
        : (size.y >= size.z ? 1 : 2);
    entries.sort((left, right) => left.center[axis] - right.center[axis]);
    const middle = Math.floor(entries.length / 2);
    return {
        bounds,
        left: buildVoxelCollisionNode(entries.slice(0, middle)),
        right: buildVoxelCollisionNode(entries.slice(middle))
    };
}

function buildObjectCollisionData(voxelData) {
    const entries = [];
    voxelData.forEach(voxel => {
        const voxelName = voxel.cubename || voxel.name || 'cube';
        if (voxelName === 'AxisPoint') return;

        const x = finiteMapNumber(voxel.x, 0);
        const y = finiteMapNumber(voxel.y, 0);
        const z = finiteMapNumber(voxel.z, 0);
        entries.push({
            center: [x, y, z],
            box: new THREE.Box3(
                new THREE.Vector3(x - 0.5, y - 0.5, z - 0.5),
                new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5)
            )
        });
    });

    if (entries.length === 0) return null;
    const tree = buildVoxelCollisionNode(entries);
    return { localBounds: tree.bounds, tree };
}

function ensureMapItemCollisionData(object) {
    if (object.userData.collisionCacheDisabled) return null;
    if (!object.userData.mapEntry || !object.userData.loaded) return null;
    const existingCollisionData = objectVoxelCollisionData.get(object);
    if (existingCollisionData) {
        return existingCollisionData;
    }

    const sourceFile = object.userData.sourceFile;
    if (!sourceFile) return null;
    const cacheKey = object.userData.resolvedObjectUrl || objectJSONUrl(sourceFile);
    let collisionData = objectCollisionDataCache.get(cacheKey);

    if (!collisionData) {
        const voxelData = collisionVoxelDataFromObjectData(
            loadedObjectCache[cacheKey]
        );
        if (!voxelData) return null;
        collisionData = buildObjectCollisionData(voxelData);
        if (!collisionData) return null;
        objectCollisionDataCache.set(cacheKey, collisionData);
    }

    objectVoxelCollisionData.set(object, collisionData);
    objectCollisionLocalBoxes.set(object, collisionData.localBounds);
    return collisionData;
}

function collisionTreeTouchesWorldBox(node, matrixWorld, colliderBox, scratchBox) {
    scratchBox.copy(node.bounds).applyMatrix4(matrixWorld);
    if (!scratchBox.intersectsBox(colliderBox)) return false;

    if (node.boxes) {
        for (const localBox of node.boxes) {
            scratchBox.copy(localBox).applyMatrix4(matrixWorld);
            if (scratchBox.intersectsBox(colliderBox)) return true;
        }
        return false;
    }

    return collisionTreeTouchesWorldBox(
        node.left, matrixWorld, colliderBox, scratchBox
    ) || collisionTreeTouchesWorldBox(
        node.right, matrixWorld, colliderBox, scratchBox
    );
}

function collisionBoxFor(object) {
    if (object === camera) {
        return new THREE.Box3().setFromCenterAndSize(
            camera.position,
            new THREE.Vector3(1, 1, 1)
        );
    }

    // A map item can contain thousands of voxel meshes. Build its bounds once
    // in local space, then transform that small cached box when the map moves.
    // The final voxel check remains exact, so a broad-phase false positive is
    // harmless while repeated full-tree Box3 scans are avoided.
    if (object.userData.mapEntry && object.userData.loaded) {
        if (object.userData.collisionCacheDisabled) {
            return new THREE.Box3().setFromObject(object);
        }
        ensureMapItemCollisionData(object);
        let collisionLocalBox = objectCollisionLocalBoxes.get(object);
        if (!collisionLocalBox) {
            object.updateWorldMatrix(true, true);
            const inverseRootMatrix = new THREE.Matrix4()
                .copy(object.matrixWorld)
                .invert();
            const localBounds = new THREE.Box3().makeEmpty();

            object.traverse(child => {
                if (!child.isMesh || !child.geometry) return;
                if (!child.geometry.boundingBox) {
                    child.geometry.computeBoundingBox();
                }
                if (!child.geometry.boundingBox) return;

                const childToRoot = new THREE.Matrix4().multiplyMatrices(
                    inverseRootMatrix,
                    child.matrixWorld
                );
                localBounds.union(
                    child.geometry.boundingBox.clone().applyMatrix4(childToRoot)
                );
            });

            if (!localBounds.isEmpty()) {
                objectCollisionLocalBoxes.set(object, localBounds);
                collisionLocalBox = localBounds;
            }
        }

        if (collisionLocalBox) {
            object.updateWorldMatrix(true, false);
            return collisionLocalBox.clone()
                .applyMatrix4(object.matrixWorld);
        }
    }

    return new THREE.Box3().setFromObject(object);
}

window.cd = function(nameA, nameB) {
    const objsA = findCollisionObjects(nameA);
    const objsB = findCollisionObjects(nameB);
    
    if (objsA.length === 0 || objsB.length === 0) return false;

    for (let a of objsA) {
        const boxA = collisionBoxFor(a);
        for (let b of objsB) {
            const boxB = collisionBoxFor(b);
            if (boxA.intersectsBox(boxB)) return true;
        }
    }
    return false;
};

function collectColliderMeshes(colliderObject, colliderName) {
    const roots = findCollisionObjects(colliderObject);
    const meshes = new Set();

    roots.forEach(root => {
        if (root.isMesh) {
            if (!colliderName || root.name === colliderName) meshes.add(root);
            return;
        }
        root.traverse(child => {
            if (child.isMesh && (!colliderName || child.name === colliderName)) {
                meshes.add(child);
            }
        });
    });

    return [...meshes];
}

function collectNamedMeshesWithin(roots, meshName) {
    const meshes = new Set();
    roots.forEach(root => {
        if (root.isMesh && root.name === meshName) meshes.add(root);
        root.traverse(child => {
            if (child.isMesh && child.name === meshName) meshes.add(child);
        });
    });
    return [...meshes];
}

function colliderMeshTouchesLand(land, colliderBox) {
    const collisionData = objectVoxelCollisionData.get(land) ||
        ensureMapItemCollisionData(land);
    if (collisionData) {
        land.updateWorldMatrix(true, false);
        return collisionTreeTouchesWorldBox(
            collisionData.tree,
            land.matrixWorld,
            colliderBox,
            new THREE.Box3()
        );
    }

    // This fallback keeps the exact Box3 behavior used by legacy XML maps and
    // arbitrary user-created land objects, while avoiding one Box3 allocation
    // per voxel.
    land.updateWorldMatrix(true, true);
    const voxelBox = new THREE.Box3();
    let touching = false;

    land.traverse(voxel => {
        if (touching || !voxel.isMesh || !voxel.geometry) return;
        if (!voxel.geometry.boundingBox) voxel.geometry.computeBoundingBox();
        if (!voxel.geometry.boundingBox) return;
        voxelBox.copy(voxel.geometry.boundingBox).applyMatrix4(voxel.matrixWorld);
        if (colliderBox.intersectsBox(voxelBox)) touching = true;
    });

    return touching;
}

function prepareMapCollisionItems(maps) {
    const preparedItems = [];
    maps.forEach(map => {
        const mapItems = map.userData.is3DPLMap ? map.children : [map];
        mapItems.forEach(mapItem => {
            preparedItems.push({
                mapItem,
                box: collisionBoxFor(mapItem)
            });
        });
    });
    return preparedItems;
}

function resolvedCollidersTouchMaps(
    maps,
    colliderMeshes,
    preparedMapItems
) {
    const colliderBoxes = colliderMeshes.map(colliderMesh => {
        colliderMesh.updateWorldMatrix(true, false);
        return new THREE.Box3().setFromObject(colliderMesh);
    });
    const mapItems = preparedMapItems || prepareMapCollisionItems(maps);

    for (const preparedItem of mapItems) {
        for (let index = 0; index < colliderMeshes.length; index++) {
            const colliderBox = colliderBoxes[index];
            if (!preparedItem.box.intersectsBox(colliderBox)) continue;
            if (colliderMeshTouchesLand(
                preparedItem.mapItem,
                colliderBox
            )) return true;
        }
    }

    return false;
}

/**
 * Efficiently checks a named collider/object against a LoadMap() map.
 * First it uses cd() against each placed map item. Only overlapping items
 * receive the more expensive voxel-by-voxel is_touching_voxel() check.
 *
 * @param {Object|string} mapObject - LoadMap() result, variable key, or name.
 * @param {Object|string} colliderObject - Collider group, object, or name.
 * @param {string} [colliderName] - Optional named mesh inside colliderObject.
 * @returns {boolean} True when one of the collider meshes touches a map voxel.
 */
window.is_object_colliding_with_map = function(
    mapObject,
    colliderObject,
    colliderName
) {
    const maps = findCollisionObjects(mapObject);
    const colliderMeshes = collectColliderMeshes(colliderObject, colliderName);
    if (colliderMeshes.length === 0) return false;
    return maps.length > 0 && resolvedCollidersTouchMaps(maps, colliderMeshes);
};

/**
 * Moves an object in small steps and rolls back the first step that collides.
 * This prevents fast objects from jumping completely through a thin map voxel.
 * Coordinates follow mv(): positive z moves in the object's forward direction.
 *
 * @returns {boolean} True if the entire requested movement was completed.
 */
window.move_object_with_map_collision = function(
    mapObject,
    movingObject,
    colliderObject,
    x,
    y,
    z,
    maxStep
) {
    const maps = findCollisionObjects(mapObject);
    const movingObjects = findCollisionObjects(movingObject);
    // A collider name belongs to the object being moved whenever possible.
    // This prevents another active vehicle with the same probe name from
    // incorrectly blocking movement. Global lookup remains as a fallback for
    // legacy programs that keep collider objects separate.
    let colliderMeshes = typeof colliderObject === 'string'
        ? collectNamedMeshesWithin(movingObjects, colliderObject)
        : collectColliderMeshes(colliderObject);
    if (colliderMeshes.length === 0) {
        colliderMeshes = collectColliderMeshes(colliderObject);
    }

    if (maps.length === 0 ||
        movingObjects.length === 0 ||
        colliderMeshes.length === 0) {
        return false;
    }

    // Do not allow movement through an empty placeholder while LoadMap() or
    // the collider JSON is still downloading.
    if (maps.some(map => map.userData.is3DPLMap && !map.userData.loaded)) {
        return false;
    }
    const dx = Number(x) || 0;
    const dy = Number(y) || 0;
    const dz = Number(z) || 0;
    const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (distance === 0) return true;

    const safeStep = Math.max(0.01, Number(maxStep) || 0.2);
    const steps = Math.max(1, Math.ceil(distance / safeStep));
    const stepX = dx / steps;
    const stepY = dy / steps;
    const stepZ = dz / steps;
    const preparedMapItems = prepareMapCollisionItems(maps);

    for (let step = 0; step < steps; step++) {
        movingObjects.forEach(object => {
            object.translateX(stepX);
            object.translateY(stepY);
            object.translateZ(-stepZ);
        });

        if (resolvedCollidersTouchMaps(
            maps,
            colliderMeshes,
            preparedMapItems
        )) {
            movingObjects.forEach(object => {
                object.translateX(-stepX);
                object.translateY(-stepY);
                object.translateZ(stepZ);
            });
            colliderMeshes.forEach(mesh => mesh.updateWorldMatrix(true, false));
            return false;
        }
    }

    return true;
};

window.cdcm = function(obj, colliderName) {
    const o = typeof obj === 'string' ? cubes.find(c => c.name === obj) : obj;
    return o ? window.cd(o.name, colliderName) : false;
};

// Deletion
window.dl = function(name) {
    for (let i = cubes.length - 1; i >= 0; i--) {
        if (cubes[i].name === name) {
            removeSoundsAttachedTo(cubes[i]);
            cancelObjectLoads(cubes[i]);
            cubes[i].removeFromParent();
            disposeObjectMaterials(cubes[i]);
            cubes.splice(i, 1);
        }
    }
};

window.cs = function() {
    cubes.forEach(c => { 
        cancelObjectLoads(c);
        c.removeFromParent(); 
        disposeObjectMaterials(c);
    });
    cubes = [];
    vars = {}; 
    
    clearLoadedSounds();
};

// Audio Engine
function flatAudioFilename(reference) {
    const value = String(reference || '').trim();
    if (!value || /[/?#\\]/.test(value) || value.length > 128) return '';
    return /^[A-Za-z0-9][A-Za-z0-9 ._-]*\.(?:mp3|wav|ogg|oga|opus|m4a|aac|flac|webm)$/i.test(value)
        ? value
        : '';
}

function audioLibraryFilename(reference) {
    let value = String(reference || '').trim().replace(/\\/g, '/');
    while (value.startsWith('./')) value = value.substring(2);
    if (/^Audio\//i.test(value)) value = value.substring('Audio/'.length);
    if (/^Sounds\//i.test(value)) value = value.substring('Sounds/'.length);
    return flatAudioFilename(value);
}

function sharedAudioUrl(reference) {
    const fileName = audioLibraryFilename(reference);
    return fileName ? `Audio/${encodeURIComponent(fileName)}` : '';
}

function legacySoundUrl(reference) {
    let value = String(reference || '').trim().replace(/\\/g, '/');
    while (value.startsWith('./')) value = value.substring(2);
    if (/^Sounds\//i.test(value)) value = value.substring('Sounds/'.length);
    if (!value || value.startsWith('/') || value.split('/').includes('..') ||
        /^(?:[a-z]+:|\/\/)/i.test(value)) {
        return '';
    }
    return 'Sounds/' + value.split('/').map(segment => encodeURIComponent(segment)).join('/');
}

async function readApiError(response) {
    let body = null;
    try { body = await response.json(); } catch (error) { /* Status is enough. */ }
    return httpResponseError(response, body);
}

async function decodeAudioResponse(response, requestedNick = '') {
    const encodedAudio = await response.arrayBuffer();
    if (requestedNick) assertActiveAccount(requestedNick);
    const buffer = await listener.context.decodeAudioData(encodedAudio.slice(0));
    if (requestedNick) assertActiveAccount(requestedNick);
    return buffer;
}

async function loadSoundBufferPersonalFirst(fileName) {
    const personalName = audioLibraryFilename(fileName);
    if (!personalName) throw new Error('The audio filename is not valid.');
    recordProgramAsset('Audio', personalName);
    if (sharedGameId) {
        const response = await fetch(programAssetUrl('Audio', personalName), { credentials: 'omit' });
        if (!response.ok) throw new Error(`Shared audio could not load: ${personalName}`);
        return decodeAudioResponse(response);
    }

    const requestedNick = loggedInNick;
    // Always ask the authenticated PHP session for a private file. This also
    // works after a tab restore where the secure login cookie still exists but
    // sessionStorage has lost the displayed nickname.
    const privateUrl =
        `server_side/load_audio.php?name=${encodeURIComponent(personalName)}` +
        (requestedNick ? `&scope=${encodeURIComponent(requestedNick)}` : '');
    const response = await fetch(privateUrl, {
        credentials: 'same-origin',
        cache: 'no-store'
    });
    if (requestedNick) assertActiveAccount(requestedNick);
    if (response.ok) {
        return decodeAudioResponse(response, requestedNick);
    }
    const privateError = await readApiError(response);
    if (requestedNick) assertActiveAccount(requestedNick);
    const canUseSharedAudio = [401, 403, 404].includes(response.status) ||
        privateError.code === 'session_scope_mismatch';
    if (!canUseSharedAudio) throw privateError;

    const sharedUrl = sharedAudioUrl(personalName);
    const sharedResponse = await fetch(sharedUrl, { cache: 'no-store' });
    if (sharedResponse.ok) return decodeAudioResponse(sharedResponse);
    if (sharedResponse.status !== 404) throw httpResponseError(sharedResponse);

    // Keep old deployments with a Sounds/ directory working after Audio/
    // becomes the standard shared library.
    const legacyUrl = legacySoundUrl(personalName);
    const legacyResponse = await fetch(legacyUrl, { cache: 'no-store' });
    if (legacyResponse.ok) return decodeAudioResponse(legacyResponse);

    const error = new Error(
        `"${personalName}" was not found in your private Audio library, shared Audio/, or legacy Sounds/.`
    );
    error.status = legacyResponse.status;
    throw error;
}

function playSoundIfReady(cubeName, sound) {
    if (sounds[cubeName] !== sound || !sound.userData.threeDPLPlayRequested) {
        return;
    }
    if (sound.userData.threeDPLLoadError) {
        setDebugError(sound.userData.threeDPLLoadError);
        return;
    }
    if (!isExecuting || !sound.buffer || sound.isPlaying ||
        listener.context.state !== 'running') {
        return;
    }
    sound.play();
}

function findSoundEntry(soundReference) {
    const requestedKey = String(soundReference ?? '');
    return {
        soundKey: requestedKey,
        sound: sounds[requestedKey] || null
    };
}

function requestSoundPlayback(soundReference, loop) {
    const { soundKey, sound } = findSoundEntry(soundReference);
    if (!sound) {
        setDebugError(
            'PlaySound error: no sound is attached to that object or camera. Call AttachSound first.'
        );
        return;
    }

    sound.userData.threeDPLPlayRequested = true;
    sound.setLoop(loop);
    playSoundIfReady(soundKey, sound);
}

function playQueuedSounds() {
    Object.entries(sounds).forEach(([cubeName, sound]) => {
        playSoundIfReady(cubeName, sound);
    });
}

function disposeLoadedSound(sound) {
    if (!sound) return;
    sound.userData.threeDPLPlayRequested = false;
    if (sound.isPlaying) sound.stop();
    if (sound.source) {
        try { sound.source.disconnect(); } catch (error) { /* Already disconnected. */ }
        try { sound.source.buffer = null; } catch (error) { /* Read-only after playback. */ }
        sound.source = null;
    }
    sound.removeFromParent();
    try { sound.disconnect(); } catch (error) { /* Already disconnected. */ }
    sound.buffer = null;
    sound.userData.threeDPLReady = null;
    sound.userData.threeDPLTarget = null;
}

function removeSoundsAttachedTo(target) {
    Object.entries(sounds).forEach(([soundKey, sound]) => {
        if (sound?.userData.threeDPLTarget !== target) return;
        disposeLoadedSound(sound);
        delete sounds[soundKey];
    });
}

function resolveSoundTarget(objectName) {
    if (String(objectName).toLowerCase() === 'camera') return camera;
    const namedVariable = vars[objectName];
    if (namedVariable?.isObject3D) return namedVariable;
    return cubes.find(object => object.name === objectName) || null;
}

window.AttachSound = function(cubeName, fileName) {
    const soundKey = String(cubeName ?? '');
    if (!soundKey.trim()) {
        setDebugError('AttachSound error: the object or channel name is missing.');
        return null;
    }

    const target = resolveSoundTarget(soundKey);
    if (!target) {
        setDebugError(
            `AttachSound error: object or camera "${soundKey}" does not exist.`
        );
        return null;
    }

    const previousSound = sounds[soundKey];
    if (previousSound) disposeLoadedSound(previousSound);

    const sound = new THREE.PositionalAudio(listener);
    sound.setVolume(1.0);
    sound.setRefDistance(20);
    sound.setMaxDistance(100);
    sound.setDistanceModel('inverse');
    sound.setRolloffFactor(1);
    sound.userData.threeDPLPlayRequested = false;
    sound.userData.threeDPLLoadError = '';
    sound.userData.threeDPLFileName = String(fileName ?? '');
    sound.userData.threeDPLTarget = target;
    sound.userData.threeDPLTargetName = soundKey;
    target.add(sound);
    sounds[soundKey] = sound;
    sound.userData.threeDPLReady = loadSoundBufferPersonalFirst(fileName)
        .then(buffer => {
            if (sounds[soundKey] !== sound) return sound;
            sound.userData.threeDPLLoadError = '';
            sound.setBuffer(buffer);
            playSoundIfReady(soundKey, sound);
            return sound;
        })
        .catch(error => {
            if (sounds[soundKey] !== sound) return sound;
            sound.userData.threeDPLLoadError =
                `Audio load error: ${fileName} — ${error.message}`;
            setDebugError(sound.userData.threeDPLLoadError);
            console.error('Audio load error:', error);
            return sound;
        });
    return sound;
};

window.PlaySound = function(cubeName) {
    requestSoundPlayback(cubeName, false);
};

window.PlaySoundLoop = function(cubeName) {
    requestSoundPlayback(cubeName, true);
};

window.StopSound = function(cubeName) {
    const { sound } = findSoundEntry(cubeName);
    if (!sound) return;
    sound.userData.threeDPLPlayRequested = false;
    if (sound.isPlaying) sound.stop();
};

window.SetPitch = function(cubeName, pitch) {
    const { sound } = findSoundEntry(cubeName);
    if (sound) sound.setPlaybackRate(pitch);
};

window.SetVolume = function(cubeName, vol) {
    const { sound } = findSoundEntry(cubeName);
    if (sound) sound.setVolume(vol);
};

// --- Object and XML Loading ---
const personalFallbackStatuses = new Set([401, 403, 404]);

function isPersonalFallbackError(error) {
    return personalFallbackStatuses.has(error?.status) ||
        error?.code === 'session_scope_mismatch';
}

function httpResponseError(response, body = null) {
    const message = body?.message || body?.error ||
        `Request failed (HTTP ${response.status})`;
    const error = new Error(message);
    error.status = response.status;
    error.code = typeof body?.error === 'string' ? body.error : '';
    return error;
}

function flatPersonalJSONName(reference) {
    const value = String(reference || '').trim();
    if (!value || isDirectAssetUrl(value) || /[/?#\\]/.test(value) || value.length > 128) {
        return '';
    }
    return /^[A-Za-z0-9][A-Za-z0-9 ._-]*\.json$/i.test(value) ? value : '';
}

function personalObjectResourceUrl(reference, nick = loggedInNick) {
    const filename = flatPersonalJSONName(reference);
    if (!nick || !filename) return '';
    return `server_side/download_object.php?name=${encodeURIComponent(filename)}` +
        `&scope=${encodeURIComponent(nick)}`;
}

function personalObjectCacheKey(reference, nick = loggedInNick) {
    const filename = flatPersonalJSONName(reference);
    return nick && filename
        ? `personal-object:${nick.toLowerCase()}:${filename.toLowerCase()}`
        : '';
}

function clearPersonalObjectCaches() {
    const prefix = 'personal-object:';
    Object.keys(loadedObjectCache).forEach(key => {
        if (key.startsWith(prefix)) delete loadedObjectCache[key];
    });
    Object.keys(pendingObjectDataPromises).forEach(key => {
        if (key.startsWith(prefix)) delete pendingObjectDataPromises[key];
    });
    [...objectCollisionDataCache.keys()].forEach(key => {
        if (typeof key === 'string' && key.startsWith(prefix)) {
            objectCollisionDataCache.delete(key);
        }
    });
}

function invalidatePersonalObjectCache(reference) {
    const key = personalObjectCacheKey(reference);
    if (!key) return;
    delete loadedObjectCache[key];
    delete pendingObjectDataPromises[key];
    objectCollisionDataCache.delete(key);
}

function fetchObjectData(url, cacheKey = url) {
    if (pendingObjectDataPromises[cacheKey]) {
        return pendingObjectDataPromises[cacheKey];
    }

    const isPersonalRequest = url.startsWith('server_side/download_object.php?');
    const request = fetch(url, isPersonalRequest ? {
        credentials: 'same-origin',
        cache: 'no-store'
    } : undefined)
        .then(async response => {
            if (!response.ok) {
                let body = null;
                try { body = await response.json(); } catch (error) { /* HTTP status is enough. */ }
                throw httpResponseError(response, body);
            }
            return response.json();
        })
        .then(data => {
            loadedObjectCache[cacheKey] = data;
            return data;
        });

    pendingObjectDataPromises[cacheKey] = request;
    request.then(
        () => delete pendingObjectDataPromises[cacheKey],
        () => delete pendingObjectDataPromises[cacheKey]
    );
    return request;
}

async function fetchObjectDataPersonalFirst(
    personalUrl,
    personalCacheKey,
    sharedUrl,
    requestedNick
) {
    if (!personalUrl) {
        return { data: await fetchObjectData(sharedUrl), resolvedUrl: sharedUrl };
    }

    try {
        return {
            data: await fetchObjectData(personalUrl, personalCacheKey),
            resolvedUrl: personalCacheKey
        };
    } catch (error) {
        if (!isPersonalFallbackError(error)) throw error;
        if (loggedInNick === requestedNick &&
            (error.status === 401 || error.status === 403)) {
            setLoggedInNick('');
        }
        return { data: await fetchObjectData(sharedUrl), resolvedUrl: sharedUrl };
    }
}

window.Obj = function(filenameOrUrl, instanceName, x, y, z) {
    if (!filenameOrUrl) return null;
    const normalizedReference = normalizeObjectJSONReference(filenameOrUrl);
    recordProgramAsset('Objects', normalizedReference);
    const sharedUrl = objectJSONUrl(normalizedReference);
    const personalNick = loggedInNick;
    const personalUrl = personalObjectResourceUrl(normalizedReference);
    const personalCacheKey = personalObjectCacheKey(normalizedReference);
    x = x || 0; y = y || 0; z = z || 0;
    instanceName = instanceName || ("obj_" + Math.random().toString(36).substr(2, 5));

    const axisGroup = new THREE.Group();
    axisGroup.position.set(x, y, z);
    axisGroup.name = instanceName;
    axisGroup.userData.loaded = false;
    axisGroup.userData.sourceFile = normalizedReference;
    injectUnityCompatibility(axisGroup);
    scene.add(axisGroup);
    cubes.push(axisGroup);

    const buildVoxels = (voxelData) => {
        voxelData.forEach(cords => {
            const voxelName = cords.cubename || cords.name || "cube";
            if (voxelName === "AxisPoint") return;

            const red = finiteMapNumber(cords.r, 255);
            const green = finiteMapNumber(cords.g, 255);
            const blue = finiteMapNumber(cords.b, 255);
            const opacity = cords.alpha !== undefined
                ? finiteMapNumber(cords.alpha, 1)
                : finiteMapNumber(cords.a, 1);
            const textureName = usableTextureFilename(cords.TextureName);
            const material = new THREE.MeshStandardMaterial({
                color: new THREE.Color(red / 255, green / 255, blue / 255),
                // Unknown textures remain transparent so their PNG alpha is
                // preserved. Untextured alpha-1 voxels can use the faster
                // opaque render path with identical output.
                transparent: opacity < 1 || Boolean(textureName),
                opacity
            });

            let geometry = baseGeometry;
            if (textureName) {
                assignSharedTexture(material, textureName);

                if (cords.WrapOnSides == 1) {
                    geometry = getWrappedBaseGeometry();
                }
            }

            const mesh = new THREE.Mesh(geometry, material);
            mesh.position.set(
                finiteMapNumber(cords.x, 0),
                finiteMapNumber(cords.y, 0),
                finiteMapNumber(cords.z, 0)
            );
            mesh.name = voxelName;
            mesh.userData.textureName = textureName;
            mesh.userData.wrap = cords.WrapOnSides || 6;
            axisGroup.add(mesh);
            if (/collider/i.test(voxelName)) indexCollisionObject(mesh);
        });
    };

    const finishObjectLoad = (data, resolvedUrl) => {
        if (axisGroup.userData.cancelled) return axisGroup;

        let voxelData = null;
        if (Array.isArray(data)) {
            voxelData = data;
        } else if (Array.isArray(data.voxels)) {
            voxelData = data.voxels;
        } else if (Array.isArray(data.objects)) {
            voxelData = data.objects;
        }

        if (!voxelData) throw new Error('Unknown voxel JSON format.');
        buildVoxels(voxelData);
        axisGroup.userData.resolvedObjectUrl = resolvedUrl;
        axisGroup.userData.loaded = true;
        return axisGroup;
    };

    const synchronouslyCachedUrl = personalUrl && loadedObjectCache[personalCacheKey]
        ? personalCacheKey
        : (!personalUrl && loadedObjectCache[sharedUrl] ? sharedUrl : '');
    if (synchronouslyCachedUrl) {
        try {
            finishObjectLoad(
                loadedObjectCache[synchronouslyCachedUrl],
                synchronouslyCachedUrl
            );
        } catch (error) {
            axisGroup.userData.loadError = error.message;
            setDebugError(`Failed to load JSON object: ${sharedUrl}`);
            console.error(error);
        }
        axisGroup.userData.ready = Promise.resolve(axisGroup);
    } else {
        axisGroup.userData.ready = fetchObjectDataPersonalFirst(
            personalUrl,
            personalCacheKey,
            sharedUrl,
            personalNick
        )
            .then(result => finishObjectLoad(result.data, result.resolvedUrl))
            .catch(err => {
                axisGroup.userData.loadError = err.message;
                setDebugError(`Failed to load JSON object: ${sharedUrl}`);
                console.error(err);
                return axisGroup;
            });
    }
    return axisGroup;
};

window.XMLObj = function(filenameOrUrl, instanceName, x, y, z) {
    if (!filenameOrUrl) {
        setDebugError("XMLObj Error: Missing filename argument.");
        return null;
    }
    x = x || 0; y = y || 0; z = z || 0;
    instanceName = instanceName || ("xml_obj_" + Math.random().toString(36).substr(2, 5));

    const axisGroup = new THREE.Group();
    axisGroup.position.set(x, y, z);
    axisGroup.name = instanceName;
    axisGroup.userData.loaded = false;
    injectUnityCompatibility(axisGroup);
    scene.add(axisGroup);
    cubes.push(axisGroup);

    recordProgramAsset('Objects', filenameOrUrl);
    const url = filenameOrUrl.startsWith('http') ? filenameOrUrl : programAssetUrl('Objects', filenameOrUrl);
    axisGroup.userData.ready = fetch(url)
        .then(res => { if (!res.ok) throw new Error(`HTTP ${res.status}`); return res.text(); })
        .then(str => {
            if (axisGroup.userData.cancelled) return axisGroup;
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(str, "text/xml");
            
            if (xmlDoc.getElementsByTagName("parsererror").length > 0) {
                setDebugError(`XML Syntax Error in ${url}`);
                return axisGroup;
            }

            let nodes = xmlDoc.getElementsByTagName("Coordinates");
            if (nodes.length === 0) nodes = xmlDoc.getElementsByTagName("Object");
            const collisionVoxels = [];

            for (let i = 0; i < nodes.length; i++) {
                const n = nodes[i];
                const cubename = n.getAttribute("cubename") || "cube";
                if (cubename === "AxisPoint" || cubename.startsWith("collider")) continue;

                const bx = parseFloat(n.getAttribute("x") || 0);
                const by = parseFloat(n.getAttribute("y") || 0);
                const bz = parseFloat(n.getAttribute("z") || 0);
                const r = parseFloat(n.getAttribute("r") || 255);
                const g = parseFloat(n.getAttribute("g") || 255);
                const b = parseFloat(n.getAttribute("b") || 255);
                const alpha = parseFloat(n.getAttribute("alpha") || 1.0);
                const texName = usableTextureFilename(
                    n.getAttribute("TextureName")
                );
                
                const wrapStr = n.getAttribute("WrapOnSides");
                const wrap = wrapStr ? parseInt(wrapStr) : 6;

                const mat = new THREE.MeshStandardMaterial({ 
                    color: new THREE.Color(r/255, g/255, b/255), 
                    transparent: alpha < 1 || Boolean(texName),
                    opacity: alpha
                });

                let geom = baseGeometry;
                if (texName) {
                    assignSharedTexture(mat, texName);
                    
                    if (wrap === 1) {
                        geom = getWrappedBaseGeometry();
                    }
                }

                const mesh = new THREE.Mesh(geom, mat);
                mesh.position.set(bx, by, bz);
                mesh.name = cubename;
                mesh.userData.textureName = texName;
                mesh.userData.wrap = wrap;
                axisGroup.add(mesh);
                collisionVoxels.push({
                    cubename,
                    x: bx,
                    y: by,
                    z: bz
                });
            }

            let collisionData = objectCollisionDataCache.get(`xml:${url}`);
            if (!collisionData) {
                collisionData = buildObjectCollisionData(collisionVoxels);
                if (collisionData) {
                    objectCollisionDataCache.set(`xml:${url}`, collisionData);
                }
            }
            if (collisionData) {
                objectVoxelCollisionData.set(axisGroup, collisionData);
                objectCollisionLocalBoxes.set(
                    axisGroup,
                    collisionData.localBounds
                );
            }
            axisGroup.userData.loaded = true;
            return axisGroup;
        })
        .catch(err => {
            axisGroup.userData.loadError = err.message;
            setDebugError(`Cannot fetch ${url}. (Use HTTP Server)`);
            console.error(err);
            return axisGroup;
        });

    return axisGroup;
};

function createInlineMapCube(entry, instanceName) {
    const group = new THREE.Group();
    group.name = instanceName;
    group.userData.loaded = true;
    injectUnityCompatibility(group);

    let color = new THREE.Color(0x888888);
    if (Array.isArray(entry.color) && entry.color.length >= 3) {
        color = new THREE.Color(
            Number(entry.color[0]) / 255,
            Number(entry.color[1]) / 255,
            Number(entry.color[2]) / 255
        );
    } else if (entry.color !== undefined) {
        color = new THREE.Color(entry.color);
    }

    const opacity = entry.alpha !== undefined ? Number(entry.alpha) : 1;
    const material = new THREE.MeshStandardMaterial({
        color,
        transparent: opacity < 1,
        opacity
    });
    const mesh = new THREE.Mesh(baseGeometry, material);
    mesh.name = entry.voxelName || `${instanceName}_voxel`;
    group.add(mesh);
    const localBounds = new THREE.Box3(
        new THREE.Vector3(-0.5, -0.5, -0.5),
        new THREE.Vector3(0.5, 0.5, 0.5)
    );
    const collisionData = {
        localBounds,
        tree: { bounds: localBounds, boxes: [localBounds] }
    };
    objectVoxelCollisionData.set(group, collisionData);
    objectCollisionLocalBoxes.set(group, localBounds);

    scene.add(group);
    cubes.push(group);
    group.userData.ready = Promise.resolve(group);
    return group;
}

function opaqueMapMaterialSignature(mesh) {
    const material = mesh.material;
    if (!mesh.visible || !material || material.visible === false ||
        Array.isArray(material) || material.transparent || material.opacity < 1) {
        return '';
    }

    return [
        mesh.geometry.uuid,
        material.type,
        material.color?.getHexString() || '',
        material.map?.uuid || '',
        material.roughness ?? '',
        material.metalness ?? '',
        material.side,
        material.alphaTest,
        material.depthTest,
        material.depthWrite,
        mesh.castShadow,
        mesh.receiveShadow,
        mesh.layers.mask,
        mesh.renderOrder
    ].join('|');
}

const mapPartCompatibilityMethods = [
    'traverse',
    'traverseVisible',
    'getObjectById',
    'getObjectByName',
    'getObjectByProperty',
    'getObjectsByProperty',
    'raycast',
    'clone',
    'copy',
    'toJSON',
    'remove',
    'clear'
];

function restoreMapPartCompatibilityMethods(part, state) {
    Object.entries(state.originalMethods).forEach(([name, record]) => {
        if (record.hadOwn) {
            part[name] = record.value;
        } else {
            delete part[name];
        }
    });
}

function installMapPartCompatibilityMethods(part, state) {
    mapPartCompatibilityMethods.forEach(name => {
        const method = part[name];
        if (typeof method !== 'function') return;
        state.originalMethods[name] = {
            hadOwn: Object.prototype.hasOwnProperty.call(part, name),
            value: method
        };
        part[name] = function(...args) {
            disableMapPartRenderBatches(this);
            return method.apply(this, args);
        };
    });
}

function disableMapPartRenderBatches(part) {
    const state = mapRenderBatchStates.get(part);
    if (!state) return;

    // Restore public methods first so disposal/material functions see only
    // the original hierarchy and batch removal cannot re-enter this function.
    restoreMapPartCompatibilityMethods(part, state);
    state.originalMeshes.forEach(record => {
        record.mesh.visible = record.visible;
        record.mesh.matrixAutoUpdate = record.matrixAutoUpdate;
        record.mesh.matrixWorldAutoUpdate = record.matrixWorldAutoUpdate;
        record.mesh.updateMatrix();
        record.mesh.updateWorldMatrix(true, false);
        delete record.mesh.userData.mapRenderBatched;
    });

    state.batches.forEach(batch => {
        batch.removeFromParent();
        if (batch.material.map &&
            batch.material.map.userData.threeDPLMaterials) {
            batch.material.map.userData.threeDPLMaterials.delete(
                batch.material
            );
        }
        batch.material.dispose();
        batch.dispose();
    });

    mapRenderBatchStates.delete(part);
    part.userData.mapRenderOptimizationDisabled = true;
    // Traversing a map part exposes its voxels for editing. From this point,
    // collision tests use the live hierarchy so a moved/deleted voxel cannot
    // be masked by the immutable JSON collision tree built at load time.
    part.userData.collisionCacheDisabled = true;
    objectVoxelCollisionData.delete(part);
    objectCollisionLocalBoxes.delete(part);
}

function optimizeMapPartRendering(part) {
    if (part.userData.mapRenderOptimizationDisabled ||
        mapRenderBatchStates.has(part)) {
        return;
    }

    const groups = new Map();
    part.traverse(child => {
        if (!child.isMesh || child.isInstancedMesh) return;
        const signature = opaqueMapMaterialSignature(child);
        if (!signature) return;
        if (!groups.has(signature)) groups.set(signature, []);
        groups.get(signature).push(child);
    });

    const batchGroups = [...groups.values()].filter(meshes => meshes.length > 1);
    if (batchGroups.length === 0) return;

    part.updateWorldMatrix(true, true);
    const inversePartMatrix = new THREE.Matrix4()
        .copy(part.matrixWorld)
        .invert();
    const instanceMatrix = new THREE.Matrix4();
    const originalMeshes = [];
    const batches = [];

    batchGroups.forEach(meshes => {
        const firstMesh = meshes[0];
        const batchMaterial = firstMesh.material.clone();
        if (batchMaterial.map &&
            batchMaterial.map.userData.threeDPLHasTransparentPixels ===
                undefined) {
            if (!batchMaterial.map.userData.threeDPLMaterials) {
                batchMaterial.map.userData.threeDPLMaterials = new Set();
            }
            batchMaterial.map.userData.threeDPLMaterials.add(batchMaterial);
        }

        const batch = new THREE.InstancedMesh(
            firstMesh.geometry,
            batchMaterial,
            meshes.length
        );
        meshes.forEach((mesh, index) => {
            instanceMatrix.multiplyMatrices(
                inversePartMatrix,
                mesh.matrixWorld
            );
            batch.setMatrixAt(index, instanceMatrix);
            originalMeshes.push({
                mesh,
                visible: mesh.visible,
                matrixAutoUpdate: mesh.matrixAutoUpdate,
                matrixWorldAutoUpdate: mesh.matrixWorldAutoUpdate
            });
            mesh.updateMatrix();
            mesh.matrixAutoUpdate = false;
            mesh.matrixWorldAutoUpdate = false;
            mesh.visible = false;
            mesh.userData.mapRenderBatched = true;
        });

        batch.instanceMatrix.needsUpdate = true;
        batch.computeBoundingBox();
        batch.computeBoundingSphere();
        batch.name = '__3dpl_map_render_batch__';
        batch.userData.mapRenderBatch = true;
        batch.castShadow = firstMesh.castShadow;
        batch.receiveShadow = firstMesh.receiveShadow;
        batch.layers.mask = firstMesh.layers.mask;
        batch.renderOrder = firstMesh.renderOrder;
        part.add(batch);
        batches.push(batch);
    });

    const state = {
        originalMeshes,
        batches,
        originalMethods: {}
    };
    mapRenderBatchStates.set(part, state);
    installMapPartCompatibilityMethods(part, state);
}

function scheduleMapRenderingOptimization(mapGroup, mapParts) {
    const textureReadyPromises = mapPartTextureReadyPromises(mapParts);

    Promise.all([...textureReadyPromises]).then(() => {
        if (!cubes.includes(mapGroup) || mapGroup.userData.cancelled) return;
        mapParts.forEach(part => optimizeMapPartRendering(part));
        mapGroup.userData.renderOptimized = true;
    });
}

function mapPartTextureReadyPromises(mapParts) {
    const textureReadyPromises = new Set();
    mapParts.forEach(part => {
        part.traverse(child => {
            if (!child.isMesh || !child.material) return;
            const materials = Array.isArray(child.material)
                ? child.material
                : [child.material];
            materials.forEach(material => {
                const ready = material.map?.userData.threeDPLReady;
                if (ready) textureReadyPromises.add(ready);
            });
        });
    });
    return textureReadyPromises;
}

function scheduleMapEditorObjectOptimization(object) {
    const textureReadyPromises = mapPartTextureReadyPromises([object]);
    Promise.all([...textureReadyPromises]).then(() => {
        if (!mapEditorMode ||
            !cubes.includes(object) ||
            !object.userData.mapEditorObject ||
            object.userData.cancelled ||
            object.userData.loadError) {
            return;
        }
        optimizeMapPartRendering(object);
    });
}

/**
 * Loads a JSON map exported by the Creative Mode Map Editor.
 * The returned group is registered like any other 3DPL object, so its
 * objectName can be passed to mv(), sp(), rt(), sr(), sc(), dl(), cd(), etc.
 * Local filenames are loaded from the Maps/ subdirectory.
 */
window.LoadMap = function(mapJsonFile, objectName) {
    if (!mapJsonFile) {
        setDebugError('LoadMap Error: Missing map JSON filename.');
        return null;
    }

    // Accept an optional leading "Maps/", but never load map files from
    // outside that directory.
    let normalizedMapFile = String(mapJsonFile).trim().replace(/\\/g, '/');
    while (normalizedMapFile.startsWith('./')) {
        normalizedMapFile = normalizedMapFile.substring(2);
    }
    const relativeMapFile = /^\/Maps\//i.test(normalizedMapFile)
        ? normalizedMapFile.substring('/Maps/'.length)
        : (/^Maps\//i.test(normalizedMapFile)
            ? normalizedMapFile.substring('Maps/'.length)
            : normalizedMapFile);

    if (!relativeMapFile ||
        relativeMapFile.startsWith('/') ||
        relativeMapFile.split('/').includes('..') ||
        !relativeMapFile.toLowerCase().endsWith('.json')) {
        setDebugError('LoadMap Error: The map must be a JSON file inside Maps/.');
        return null;
    }

    recordProgramAsset('Maps', relativeMapFile);
    const mapUrl = programAssetUrl('Maps', relativeMapFile);
    const personalMapName = flatPersonalJSONName(relativeMapFile);
    const personalMapNick = loggedInNick;
    const personalMapUrl = personalMapNick && personalMapName
        ? `server_side/load_map.php?name=${encodeURIComponent(personalMapName)}` +
            `&scope=${encodeURIComponent(personalMapNick)}`
        : '';

    objectName = objectName || (`map_${Math.random().toString(36).substr(2, 5)}`);

    const mapGroup = new THREE.Group();
    mapGroup.name = objectName;
    mapGroup.userData.mapFile = relativeMapFile;
    mapGroup.userData.is3DPLMap = true;
    mapGroup.userData.loaded = false;
    injectUnityCompatibility(mapGroup);
    scene.add(mapGroup);
    cubes.push(mapGroup);

    const fetchMapJSON = async () => {
        if (personalMapUrl) {
            const personalResponse = await fetch(personalMapUrl, {
                credentials: 'same-origin',
                cache: 'no-store'
            });
            if (personalResponse.ok) {
                return {
                    data: await personalResponse.json(),
                    resolvedUrl: personalMapUrl
                };
            }
            let body = null;
            try { body = await personalResponse.json(); } catch (error) { /* Status is enough. */ }
            const personalError = httpResponseError(personalResponse, body);
            if (!isPersonalFallbackError(personalError)) throw personalError;
            if (loggedInNick === personalMapNick &&
                (personalResponse.status === 401 || personalResponse.status === 403)) {
                setLoggedInNick('');
            }
        }

        const sharedResponse = await fetch(mapUrl, { cache: 'no-store' });
        if (!sharedResponse.ok) throw httpResponseError(sharedResponse);
        return { data: await sharedResponse.json(), resolvedUrl: mapUrl };
    };

    mapGroup.userData.ready = fetchMapJSON()
        .then(({ data, resolvedUrl }) => {
            // Do not resurrect a map that was deleted while its file was loading.
            if (!cubes.includes(mapGroup)) return mapGroup;

            const entries = normalizeMapDocument(data);
            const mapParts = entries.map((entry, index) => {
                const part = instantiateMapEntry(
                    entry,
                    `${objectName}_part_${index + 1}`
                );

                // Only the parent map should be registered as a top-level 3DPL object.
                const partIndex = cubes.indexOf(part);
                if (partIndex !== -1) cubes.splice(partIndex, 1);
                mapGroup.add(part);
                part.userData.mapEntry = entry;
                return part;
            });

            mapGroup.userData.mapEntries = entries;
            mapGroup.userData.resolvedMapUrl = resolvedUrl;
            return Promise.all(mapParts.map(part => part.userData.ready))
                .then(() => {
                    if (!cubes.includes(mapGroup)) return mapGroup;

                    const failedPart = mapParts.find(part => part.userData.loadError);
                    if (failedPart) {
                        mapGroup.userData.missingObjectFile =
                            requiredMapObjectFilename(failedPart);
                        throw new Error(requiredMapObjectError(failedPart));
                    }

                    // Build one shared local collision tree per unique source
                    // file during loading, rather than pausing the first drive
                    // frame to scan every voxel in every repeated instance.
                    mapParts.forEach(part => ensureMapItemCollisionData(part));

                    // Collision checks can now safely inspect every part's voxels.
                    mapGroup.userData.loaded = true;
                    scheduleMapRenderingOptimization(mapGroup, mapParts);
                    return mapGroup;
                });
        })
        .catch(error => {
            mapGroup.userData.loadError = error.message;
            setDebugError(`LoadMap Error: ${mapUrl} - ${error.message}`);
            console.error('LoadMap Error:', error);
            return mapGroup;
        });

    return mapGroup;
};

// --- Object Editor File I/O ---
function serializeObjectEditor() {
    const exportData = [];
    cubes.forEach(c => {
        if (c.name === "AxisPoint" || c.name === "guide" || c.name === "pointer") return;
        if (c.material) {
            exportData.push({
                cubename: c.name,
                x: c.position.x, y: c.position.y, z: c.position.z,
                r: Math.round(c.material.color.r * 255), 
                g: Math.round(c.material.color.g * 255), 
                b: Math.round(c.material.color.b * 255),
                alpha: c.material.opacity,
                TextureName: c.userData.textureName || "",
                WrapOnSides: c.userData.wrap || 6
            });
        }
    });
    return exportData;
}

function validateObjectEditorData(data) {
    if (!Array.isArray(data)) throw new Error('Object JSON must contain an array of blocks.');
    if (data.length > 250000) throw new Error('This object contains too many blocks.');
    data.forEach((block, index) => {
        if (!block || typeof block !== 'object' || Array.isArray(block)) {
            throw new Error(`Block ${index + 1} is invalid.`);
        }
        for (const field of ['x', 'y', 'z', 'r', 'g', 'b']) {
            if (!Number.isFinite(Number(block[field]))) {
                throw new Error(`Block ${index + 1} has an invalid ${field} value.`);
            }
        }
    });
    return data;
}

function loadObjectEditorData(data) {
    validateObjectEditorData(data);
    window.cs();
    const axis = window.qb("AxisPoint", 0, 0, 0);
    axis.material.color.setHex(0x00ff00);
    axis.material.opacity = 0.5;

    data.forEach((cords, index) => {
        const blockName = String(cords.cubename || `cube_${index + 1}`);
        const c = window.qb(blockName, Number(cords.x), Number(cords.y), Number(cords.z));
        c.material.color.setRGB(Number(cords.r) / 255, Number(cords.g) / 255, Number(cords.b) / 255);
        c.material.opacity = cords.alpha !== undefined ? Number(cords.alpha) : 1.0;

        const wrap = cords.WrapOnSides || 6;
        if (cords.TextureName) window.tx(blockName, String(cords.TextureName), "File", wrap);
    });
}

document.getElementById('btn-save-json').onclick = () => {
    const exportData = serializeObjectEditor();
    const blob = new Blob([JSON.stringify(exportData, null, 2)], {type: "application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; 
    a.download = "my_object.json"; 
    a.click();
    URL.revokeObjectURL(url);
};

document.getElementById('btn-load-json').onclick = () => document.getElementById('file-input-json').click();
document.getElementById('file-input-json').onchange = (e) => {
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const data = JSON.parse(event.target.result);
            loadObjectEditorData(data);
            e.target.value = '';
        } catch(err) {
            setDebugError(`Object load error: ${err.message}`);
            console.error("Error loading JSON", err);
        }
    };
    reader.readAsText(file);
};

// --- Authenticated cloud object storage ---
const cloudObjectModal = document.getElementById('cloud-object-modal');
const cloudObjectList = document.getElementById('cloud-object-list');

function requireLoggedInUser(assetType = 'online files') {
    if (loggedInNick) return true;
    window.alert(`You must log in before using ${assetType}.`);
    openAuthModal('login');
    return false;
}

function closeCloudObjectModal() {
    cloudObjectModal.classList.remove('open');
    cloudObjectModal.setAttribute('aria-hidden', 'true');
}

function handleCloudError(error, assetType = 'file', expectedNick = null) {
    if (expectedNick !== null && loggedInNick !== expectedNick) {
        window.alert(activeAccountChangedError().message);
        return;
    }
    if (error.code === 'session_scope_mismatch') {
        window.alert('The active account changed while this request was running. Please try again.');
        return;
    }
    if (error.status === 401 || error.status === 403) {
        setLoggedInNick('');
        window.alert(`You must log in before using online ${assetType} storage.`);
        openAuthModal('login');
        return;
    }
    window.alert(error.message || `The ${assetType} request failed.`);
}

const handleCloudObjectError = error => handleCloudError(error, 'object');

async function sendCloudObject(objectName, overwrite = false) {
    const payload = JSON.stringify(serializeObjectEditor(), null, 2);
    const formData = new FormData();
    formData.append('object', new Blob([payload], { type: 'application/json' }), `${objectName}.json`);
    formData.append('scope', loggedInNick);
    if (overwrite) formData.append('overwrite', '1');
    const response = await fetch('server_side/upload_object.php', {
        method: 'POST',
        credentials: 'same-origin',
        body: formData
    });
    return readApiResponse(response);
}

document.getElementById('btn-upload-cloud-object').onclick = async () => {
    if (!requireLoggedInUser('online object storage')) return;
    const requestedName = window.prompt('Object name:', 'my_object');
    if (requestedName === null) return;
    const objectName = requestedName.trim().replace(/\.json$/i, '');
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(objectName)) {
        window.alert('Use 1–64 letters, numbers, underscores, or hyphens for the object name.');
        return;
    }

    try {
        const result = await sendCloudObject(objectName);
        invalidatePersonalObjectCache(result.name || `${objectName}.json`);
        window.alert(`Uploaded ${result.name || `${objectName}.json`}`);
        refreshPersonalObjectLibrary().catch(error =>
            console.warn('Object library refresh failed:', error));
    } catch (error) {
        if (error.code === 'shared_name_exists') {
            window.alert('A shared object already uses that filename. Give your object a novel name.');
        } else if (error.code === 'object_exists' &&
            window.confirm('That object already exists in your account. Replace it?')) {
            try {
                const result = await sendCloudObject(objectName, true);
                invalidatePersonalObjectCache(result.name || `${objectName}.json`);
                window.alert(`Uploaded ${result.name || `${objectName}.json`}`);
                refreshPersonalObjectLibrary().catch(error =>
                    console.warn('Object library refresh failed:', error));
            } catch (overwriteError) {
                handleCloudObjectError(overwriteError);
            }
        } else if (error.code !== 'object_exists') {
            handleCloudObjectError(error);
        }
    }
};

async function refreshCloudObjectList() {
    cloudObjectList.replaceChildren();
    const loadingOption = document.createElement('option');
    loadingOption.value = '';
    loadingOption.textContent = 'Loading...';
    loadingOption.disabled = true;
    cloudObjectList.appendChild(loadingOption);

    const response = await fetch(
        `server_side/download_object.php?scope=${encodeURIComponent(loggedInNick)}`,
        {
        credentials: 'same-origin',
        cache: 'no-store'
        }
    );
    const result = await readApiResponse(response);
    cloudObjectList.replaceChildren();
    const objects = Array.isArray(result.objects) ? result.objects : [];
    objects.forEach(entry => {
        const filename = typeof entry === 'string' ? entry : entry.name;
        if (!filename) return;
        const option = document.createElement('option');
        option.value = filename;
        option.textContent = filename;
        cloudObjectList.appendChild(option);
    });
    if (cloudObjectList.options.length > 0) {
        cloudObjectList.selectedIndex = 0;
    } else {
        const emptyOption = document.createElement('option');
        emptyOption.value = '';
        emptyOption.textContent = 'No uploaded objects';
        emptyOption.disabled = true;
        cloudObjectList.appendChild(emptyOption);
    }
}

document.getElementById('btn-download-cloud-object').onclick = async () => {
    if (!requireLoggedInUser('online object storage')) return;
    if (document.pointerLockElement) document.exitPointerLock();
    cloudObjectModal.classList.add('open');
    cloudObjectModal.setAttribute('aria-hidden', 'false');
    try {
        await refreshCloudObjectList();
    } catch (error) {
        closeCloudObjectModal();
        handleCloudObjectError(error);
    }
};

document.getElementById('btn-refresh-cloud-objects').onclick = async () => {
    try {
        await refreshCloudObjectList();
    } catch (error) {
        closeCloudObjectModal();
        handleCloudObjectError(error);
    }
};

document.getElementById('btn-load-cloud-object').onclick = async () => {
    const filename = cloudObjectList.value;
    if (!filename) return;
    try {
        const response = await fetch(personalObjectResourceUrl(filename), {
            credentials: 'same-origin',
            cache: 'no-store'
        });
        if (!response.ok) await readApiResponse(response);
        const data = await response.json();
        loadObjectEditorData(data.object || data);
        invalidatePersonalObjectCache(filename);
        closeCloudObjectModal();
        window.alert(`Loaded ${filename}`);
    } catch (error) {
        handleCloudObjectError(error);
    }
};

document.getElementById('btn-close-cloud-objects').onclick = closeCloudObjectModal;
cloudObjectModal.addEventListener('pointerdown', event => {
    if (event.target === cloudObjectModal) closeCloudObjectModal();
});

// --- Authenticated program, map, audio, and texture storage ---
const cloudFileModal = document.getElementById('cloud-file-modal');
const cloudFileTitle = document.getElementById('cloud-file-title');
const cloudFileMessage = document.getElementById('cloud-file-message');
const cloudFileList = document.getElementById('cloud-file-list');
const cloudFileLoadButton = document.getElementById('btn-load-cloud-file');
let cloudFileDialog = null;

function closeCloudFileModal() {
    cloudFileModal.classList.remove('open');
    cloudFileModal.setAttribute('aria-hidden', 'true');
    cloudFileList.replaceChildren();
    cloudFileMessage.textContent = '';
    cloudFileDialog = null;
}

function scopedPersonalEndpoint(endpoint, params = {}, nick = loggedInNick) {
    const query = new URLSearchParams(params);
    query.set('scope', nick);
    return `${endpoint}?${query}`;
}

function handleCloudFileError(dialog, error) {
    handleCloudError(error, dialog.assetType, dialog.accountNick ?? null);
}

async function refreshCloudFileList() {
    if (!cloudFileDialog) return;
    const dialog = cloudFileDialog;
    cloudFileMessage.textContent = 'Loading...';
    cloudFileList.replaceChildren();
    const response = await fetch(dialog.listUrl(), {
        credentials: 'same-origin',
        cache: 'no-store'
    });
    const result = await readApiResponse(response);
    if (dialog !== cloudFileDialog) return;
    if (dialog.accountNick !== undefined) {
        assertActiveAccount(dialog.accountNick);
    }

    const records = Array.isArray(result[dialog.listKey])
        ? result[dialog.listKey]
        : [];
    records.forEach(record => {
        const name = typeof record === 'string' ? record : record?.name;
        if (!name) return;
        const option = document.createElement('option');
        option.value = name;
        option.textContent = dialog.describe
            ? dialog.describe(record, name)
            : name;
        cloudFileList.appendChild(option);
    });
    if (cloudFileList.options.length > 0) {
        cloudFileList.selectedIndex = 0;
        cloudFileMessage.textContent = `${cloudFileList.options.length} file(s)`;
        cloudFileLoadButton.disabled = false;
    } else {
        const emptyOption = document.createElement('option');
        emptyOption.value = '';
        emptyOption.textContent = dialog.emptyText;
        emptyOption.disabled = true;
        cloudFileList.appendChild(emptyOption);
        cloudFileMessage.textContent = dialog.emptyText;
        cloudFileLoadButton.disabled = true;
    }
}

async function openCloudFileModal(config) {
    if (!requireLoggedInUser(config.storageLabel)) return;
    if (document.pointerLockElement) document.exitPointerLock();
    cloudFileDialog = config;
    cloudFileTitle.textContent = config.title;
    cloudFileLoadButton.textContent = config.actionLabel;
    cloudFileLoadButton.disabled = true;
    cloudFileModal.classList.add('open');
    cloudFileModal.setAttribute('aria-hidden', 'false');
    try {
        await refreshCloudFileList();
    } catch (error) {
        if (cloudFileDialog !== config) return;
        closeCloudFileModal();
        handleCloudFileError(config, error);
    }
}

document.getElementById('btn-close-cloud-files').onclick = closeCloudFileModal;
cloudFileModal.addEventListener('pointerdown', event => {
    if (event.target === cloudFileModal) closeCloudFileModal();
});
document.getElementById('btn-refresh-cloud-files').onclick = async () => {
    if (!cloudFileDialog) return;
    const dialog = cloudFileDialog;
    try {
        await refreshCloudFileList();
    } catch (error) {
        if (cloudFileDialog !== dialog) return;
        closeCloudFileModal();
        handleCloudFileError(dialog, error);
    }
};
cloudFileLoadButton.onclick = async () => {
    if (!cloudFileDialog || !cloudFileList.value) return;
    const dialog = cloudFileDialog;
    cloudFileLoadButton.disabled = true;
    cloudFileMessage.textContent = `${dialog.actionLabel}...`;
    try {
        await dialog.load(cloudFileList.value);
        if (dialog.accountNick !== undefined) {
            assertActiveAccount(dialog.accountNick);
        }
        closeCloudFileModal();
    } catch (error) {
        if (cloudFileDialog !== dialog) return;
        cloudFileMessage.textContent = error.message;
        handleCloudFileError(dialog, error);
    } finally {
        if (cloudFileDialog === dialog) cloudFileLoadButton.disabled = false;
    }
};
cloudFileList.ondblclick = () => cloudFileLoadButton.click();

async function downloadCloudResponse(response, filename, expectedNick = null) {
    if (!response.ok) await readApiResponse(response);
    if (expectedNick !== null) assertActiveAccount(expectedNick);
    const blob = await response.blob();
    if (expectedNick !== null) assertActiveAccount(expectedNick);
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
}

function validCloudProgramName(name) {
    return name.length <= 128 &&
        /^[A-Za-z0-9](?:[A-Za-z0-9 ._-]*[A-Za-z0-9_-])?$/.test(name);
}

async function sendCloudProgram(programName, overwrite = false) {
    const formData = new FormData();
    formData.append('declarations', new Blob(
        [editorDeclarations.getValue()],
        { type: 'text/plain;charset=utf-8' }
    ), `${programName}.declarations`);
    formData.append('update', new Blob(
        [editorUpdate.getValue()],
        { type: 'text/plain;charset=utf-8' }
    ), `${programName}.update`);
    formData.append('program_name', programName);
    formData.append('scope', loggedInNick);
    if (overwrite) formData.append('overwrite', '1');
    const response = await fetch('server_side/upload_program.php', {
        method: 'POST',
        credentials: 'same-origin',
        body: formData
    });
    return readApiResponse(response);
}

document.getElementById('btn-upload-cloud-program').onclick = async () => {
    if (!requireLoggedInUser('online program storage')) return;
    const requestedName = window.prompt('Program name:', currentProgramName);
    if (requestedName === null) return;
    const programName = requestedName.trim()
        .replace(/\.(?:declarations|update)$/i, '')
        .trim();
    if (!validCloudProgramName(programName)) {
        window.alert('Use a name up to 128 characters containing letters, numbers, spaces, dots, underscores, or hyphens.');
        return;
    }

    try {
        const result = await sendCloudProgram(programName);
        setCurrentProgramName(result.name || programName);
        window.alert(`Uploaded program ${result.name || programName}`);
    } catch (error) {
        if (error.code === 'program_exists' &&
            window.confirm('That program already exists in your account. Replace it?')) {
            try {
                const result = await sendCloudProgram(programName, true);
                setCurrentProgramName(result.name || programName);
                window.alert(`Uploaded program ${result.name || programName}`);
            } catch (overwriteError) {
                handleCloudError(overwriteError, 'program');
            }
        } else if (error.code !== 'program_exists') {
            handleCloudError(error, 'program');
        }
    }
};

document.getElementById('btn-load-cloud-program').onclick = () =>
    openCloudFileModal({
        title: 'My Programs',
        storageLabel: 'online program storage',
        assetType: 'program',
        listUrl: () => scopedPersonalEndpoint('server_side/load_program.php'),
        listKey: 'programs',
        emptyText: 'No uploaded programs',
        actionLabel: 'Load program',
        load: async name => {
            const response = await fetch(scopedPersonalEndpoint(
                'server_side/load_program.php',
                { name }
            ), { credentials: 'same-origin', cache: 'no-store' });
            const result = await readApiResponse(response);
            applyProgramCode(result.declarations, result.update, result.name || name);
            window.alert(`Loaded program ${result.name || name}`);
        }
    });

function normalizeCloudJSONName(value) {
    let name = String(value || '').trim();
    if (name && !/\.json$/i.test(name)) name += '.json';
    return name.length <= 128 &&
        /^[A-Za-z0-9][A-Za-z0-9 ._-]*\.json$/i.test(name)
        ? name
        : '';
}

async function sendCloudMap(mapName, overwrite = false) {
    const payload = JSON.stringify(serializeMapEditor(), null, 2);
    const formData = new FormData();
    formData.append('map', new Blob([payload], { type: 'application/json' }), mapName);
    formData.append('map_name', mapName);
    formData.append('scope', loggedInNick);
    if (overwrite) formData.append('overwrite', '1');
    const response = await fetch('server_side/upload_map.php', {
        method: 'POST',
        credentials: 'same-origin',
        body: formData
    });
    return readApiResponse(response);
}

document.getElementById('btn-upload-cloud-map').onclick = async () => {
    if (!requireLoggedInUser('online map storage')) return;
    const requestedName = window.prompt('Map filename:', currentMapName);
    if (requestedName === null) return;
    const mapName = normalizeCloudJSONName(requestedName);
    if (!mapName) {
        window.alert('Use a JSON filename containing letters, numbers, spaces, dots, underscores, or hyphens.');
        return;
    }

    try {
        const result = await sendCloudMap(mapName);
        currentMapName = result.name || mapName;
        window.alert(`Uploaded ${currentMapName}`);
    } catch (error) {
        if (error.code === 'shared_name_exists') {
            window.alert('A shared map already uses that filename. Give your map a novel name.');
        } else if (error.code === 'map_exists' &&
            window.confirm('That map already exists in your account. Replace it?')) {
            try {
                const result = await sendCloudMap(mapName, true);
                currentMapName = result.name || mapName;
                window.alert(`Uploaded ${currentMapName}`);
            } catch (overwriteError) {
                handleCloudError(overwriteError, 'map');
            }
        } else if (error.code !== 'map_exists') {
            handleCloudError(error, 'map');
        }
    }
};

document.getElementById('btn-load-cloud-map').onclick = () =>
    openCloudFileModal({
        title: 'My Maps',
        storageLabel: 'online map storage',
        assetType: 'map',
        listUrl: () => scopedPersonalEndpoint('server_side/load_map.php'),
        listKey: 'maps',
        emptyText: 'No uploaded maps',
        actionLabel: 'Load map',
        load: async name => {
            const response = await fetch(scopedPersonalEndpoint(
                'server_side/load_map.php',
                { name }
            ), { credentials: 'same-origin', cache: 'no-store' });
            if (!response.ok) await readApiResponse(response);
            await loadMapEditorData(await response.json(), name);
            window.alert(`Loaded ${name}`);
        }
    });

function chooseUploadFile(input, storageLabel) {
    if (!requireLoggedInUser(storageLabel)) return;
    input.value = '';
    input.click();
}

const audioFileInput = document.getElementById('file-input-audio');
document.getElementById('btn-upload-cloud-audio').onclick = () =>
    chooseUploadFile(audioFileInput, 'your private audio storage');
audioFileInput.onchange = async () => {
    const file = audioFileInput.files[0];
    if (!file) return;
    if (!requireLoggedInUser('your private audio storage')) {
        audioFileInput.value = '';
        return;
    }
    const requestedNick = loggedInNick;
    const requestedName = window.prompt('Audio filename:', file.name);
    audioFileInput.value = '';
    if (requestedName === null) return;
    const audioName = flatAudioFilename(requestedName);
    if (!audioName) {
        window.alert('Use a supported audio filename without folders.');
        return;
    }
    const formData = new FormData();
    formData.append('audio', file, audioName);
    formData.append('audio_name', audioName);
    formData.append('scope', requestedNick);
    try {
        const response = await fetch('server_side/upload_audio.php', {
            method: 'POST',
            credentials: 'same-origin',
            body: formData
        });
        const result = await readApiResponse(response);
        assertActiveAccount(requestedNick);
        window.alert(`Uploaded ${result.name || audioName}`);
    } catch (error) {
        if (loggedInNick !== requestedNick) {
            handleCloudError(error, 'audio', requestedNick);
        } else if (error.code === 'audio_exists') {
            window.alert('An audio file with that name already exists. Give it a novel name.');
        } else {
            handleCloudError(error, 'audio', requestedNick);
        }
    }
};

document.getElementById('btn-load-cloud-audio').onclick = () => {
    const requestedNick = loggedInNick;
    return openCloudFileModal({
        title: 'My Audio',
        storageLabel: 'your private audio storage',
        assetType: 'audio',
        accountNick: requestedNick,
        listUrl: () => scopedPersonalEndpoint(
            'server_side/load_audio.php',
            {},
            requestedNick
        ),
        listKey: 'audio',
        emptyText: 'No audio uploaded to your account',
        actionLabel: 'Download audio',
        load: async name => {
            assertActiveAccount(requestedNick);
            const response = await fetch(scopedPersonalEndpoint(
                'server_side/load_audio.php',
                { name },
                requestedNick
            ), { credentials: 'same-origin', cache: 'no-store' });
            await downloadCloudResponse(response, name, requestedNick);
        }
    });
};

async function sendCloudTexture(file, textureName, overwrite = false) {
    const formData = new FormData();
    formData.append('texture', file, textureName);
    formData.append('texture_name', textureName);
    formData.append('scope', loggedInNick);
    if (overwrite) formData.append('overwrite', '1');
    const response = await fetch('server_side/upload_texture.php', {
        method: 'POST',
        credentials: 'same-origin',
        body: formData
    });
    return readApiResponse(response);
}

async function finishTextureUpload(result, fallbackName) {
    clearPersonalTextureCache();
    window.alert(`Uploaded ${result.name || fallbackName}`);
    try {
        await refreshPersonalTextureLibrary();
    } catch (error) {
        console.warn('Texture library refresh failed:', error);
    }
}

const textureFileInput = document.getElementById('file-input-texture');
document.getElementById('btn-upload-cloud-texture').onclick = () =>
    chooseUploadFile(textureFileInput, 'online texture storage');
textureFileInput.onchange = async () => {
    const file = textureFileInput.files[0];
    if (!file) return;
    const requestedName = window.prompt('Texture filename:', file.name);
    textureFileInput.value = '';
    if (requestedName === null) return;
    const textureName = flatTextureFilename(requestedName);
    if (!textureName) {
        window.alert('Use a PNG, JPEG, WebP, or GIF filename without folders.');
        return;
    }
    try {
        await finishTextureUpload(await sendCloudTexture(file, textureName), textureName);
    } catch (error) {
        if (error.code === 'shared_name_exists') {
            window.alert('A shared texture already uses that filename. Give your texture a novel name.');
        } else if (error.code === 'texture_exists' &&
            window.confirm('That texture already exists in your account. Replace it?')) {
            try {
                await finishTextureUpload(
                    await sendCloudTexture(file, textureName, true),
                    textureName
                );
            } catch (overwriteError) {
                handleCloudError(overwriteError, 'texture');
            }
        } else if (error.code !== 'texture_exists') {
            handleCloudError(error, 'texture');
        }
    }
};

document.getElementById('btn-load-cloud-texture').onclick = () =>
    openCloudFileModal({
        title: 'My Textures',
        storageLabel: 'online texture storage',
        assetType: 'texture',
        listUrl: () => scopedPersonalEndpoint('server_side/load_texture.php'),
        listKey: 'textures',
        emptyText: 'No uploaded textures',
        actionLabel: 'Download texture',
        load: async name => {
            const response = await fetch(scopedPersonalEndpoint(
                'server_side/load_texture.php',
                { name }
            ), { credentials: 'same-origin', cache: 'no-store' });
            await downloadCloudResponse(response, name);
        }
    });

document.getElementById('btn-import-xml').onclick = () => document.getElementById('file-input-xml').click();
document.getElementById('file-input-xml').onchange = (e) => {
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(event.target.result, "text/xml");
            let nodes = xmlDoc.getElementsByTagName("Coordinates");
            if(nodes.length === 0) nodes = xmlDoc.getElementsByTagName("Object");
            
            window.cs(); 
            const axis = window.qb("AxisPoint", 0, 0, 0);
            axis.material.color.setHex(0x00ff00);
            axis.material.opacity = 0.5;

            for(let i=0; i<nodes.length; i++) {
                const n = nodes[i];
                const cubename = n.getAttribute("cubename") || generateId();
                if (cubename === "AxisPoint" || cubename.startsWith("collider")) continue;

                const x = parseFloat(n.getAttribute("x") || 0);
                const y = parseFloat(n.getAttribute("y") || 0);
                const z = parseFloat(n.getAttribute("z") || 0);
                const r = parseFloat(n.getAttribute("r") || 255);
                const g = parseFloat(n.getAttribute("g") || 255);
                const b = parseFloat(n.getAttribute("b") || 255);
                const alpha = parseFloat(n.getAttribute("alpha") || 1.0);
                const texName = n.getAttribute("TextureName") || "";
                
                const wrapStr = n.getAttribute("WrapOnSides");
                const wrap = wrapStr ? parseInt(wrapStr) : 6;
                
                const c = window.qb(cubename, x, y, z);
                c.material.color.setRGB(r/255, g/255, b/255);
                c.material.opacity = alpha;
                if(texName) {
                    window.tx(cubename, texName, "File", wrap);
                }
            }
            e.target.value = '';
        } catch(err) { console.error("Error loading XML", err); }
    };
    reader.readAsText(file);
};

function PreProcessor(code) {
    let processed = code;
    processed = processed.replace(/\bMap\s*\(/g, "XMLObj(");

    processed = processed.replace(/([a-zA-Z0-9_\[\]"']+)(?:\.transform)?\.parent\s*=\s*([a-zA-Z0-9_\[\]"']+)(?:\.transform)?;/g, "$2.attach($1);");
    processed = processed.replace(/\.transform\b/g, "");

    processed = processed.replace(/(for\s*\([^)]+\)\s*)([^{\s][^;]+;?)/g, "$1 { $2 }");
    processed = processed.replace(/(while\s*\([^)]+\)\s*)([^{\s][^;]+;?)/g, "$1 { $2 }");

    const loopCheck = `if (performance.now() - window._evalStartTime > 500) { throw new Error("Loop timeout! Infinite loop prevented."); } `;
    processed = processed.replace(/(for\s*\(.*?\)\s*\{)/g, "$1 " + loopCheck);
    processed = processed.replace(/(while\s*\(.*?\)\s*\{)/g, "$1 " + loopCheck);

    return processed;
}

// The update editor usually stays unchanged for thousands of frames. Cache
// its preprocessed form and refresh it only when CodeMirror reports an edit.
// Direct eval is retained so update programs keep the exact same scope and
// behavior they had before this optimization.
let cachedUpdateCode = PreProcessor(editorUpdate.getValue());
let declarationsValid = true;

function refreshCachedUpdateCode() {
    cachedUpdateCode = PreProcessor(editorUpdate.getValue());
}

function evalDeclarations() {
    programAssets.clear();
    window.cs();
    window._evalStartTime = performance.now();
    clearDebug();
    resetCamera();
    legacySkyMode = 'default';
    setSkyboxVisible(!mapEditorMode);
    
    try {
        const rawDecl = editorDeclarations.getValue();
        const safeCode = PreProcessor(rawDecl);
        eval(safeCode);
        declarationsValid = true;
        return true;
    } catch (e) {
        declarationsValid = false;
        if (e instanceof SyntaxError) {
            setDebugError("Syntax Error: " + e.message);
        } else {
            setDebugError("Declaration Error: " + e.message); 
            console.error(e);
        }
        return false;
    }
}

// --- ORIGINAL TUTORIALS + CAR SIMULATOR LESSONS ---
const tutorials = {
    1: { decl: `//How to make a cube\nqb("mycube",0,0,0);`, upd: `` },
    2: { decl: `//Now change the coordinates of mycube so you can see it moves aroud\nqb("mycube",2,0,1);`, upd: `` },
    3: { decl: `//Let's make 3 cubes\nqb("a",0,0,0);\nqb("b",2,1,1);\nqb("c",-2,-1,-1);`, upd: `` },
    4: { decl: `//Let's color the cubes\nqb("a",0,0,0);\nqb("b",2,1,1);\nqb("c",-2,-1,-1);\ncl("a", Color.red);\ncl("b", Color.green);\ncl("c", Color.blue);`, upd: `` },
    5: { decl: `qb("a",0,0,0);\nqb("b",2,1,1);\nqb("c",-2,-1,-1);\ncl("a", Color.red);\ncl("b", Color.green);\ncl("c", Color.blue);`, upd: `//Let's rotate the cubes (scaled slightly for modern 60fps)\nrt("a",2,2,2);\nrt("b",-2,-2,-2);\nrt("c",2,2,2);\n//click on start!` },
    6: { decl: `qb("a",0,0,0);\nqb("b",2,1,1);\nqb("c",-2,-1,-1);\ncl("a", Color.red);\ncl("b", Color.green);\ncl("c", Color.blue);`, upd: `//Let's move the cubes\nmv("a",0.05,0,0);\nmv("b",0,0.05,0);\nmv("c",0,0,0.05);\n//click on start!` },
    7: { decl: `qb("a",0,0,0);\nqb("b",2,1,1);\nqb("c",-2,-1,-1);\ncl("a", Color.red);\ncl("b", Color.green);\ncl("c", Color.blue);`, upd: `//Move and rotate\nmv("a",0.05,0,0);\nrt("b",2,2,2);\nmv("c",0,0,0.05);\n//click on start!` },
    8: { decl: `qb("a",0,0,0);\nqb("b",2,1,1);\nqb("c",-2,-1,-1);\ncl("a", Color.red);\ncl("b", Color.green);\ncl("c", Color.blue);`, upd: `//Rotate\nrt("a",2,2,2);\nrt("b",-2,-2,-2);\nrt("c",2,2,2);\n//Move\nmv("a",0.05,0,0);\nmv("b",0,0.05,0);\nmv("c",0,0,0.05);\n//click on start!` },
    9: { decl: `//for loops\nfor(var x=0;x<4;x++) {\n    qb("a",x,x,x);\n}`, upd: `` },
    10: { decl: `//Functions\nfunction f(y) {//makes a bar\n    for(var x=0;x<6;x++) { qb("a",x,y,0); }\n}\nf(1);f(3);f(5);`, upd: `` },
    11: { decl: `//Collision Detection\nqb("a",3,0,0);\nqb("b",0,0,0);\ncl("a", Color.blue);\ncl("b", Color.red);`, upd: `//Move until crash\nif(!cd("a","b")) {\n    mv("b",0.05,0,0);\n}` },
    12: { decl: `//Moving camera\nfor(var x=0;x<4;x++) {\n    qb("a",x,x,x);\n}`, upd: `mv("camera",0.05,0.05,0.05);` },
    13: { decl: `//Rotating camera\nfor(var x=0;x<4;x++) {\n    qb("a",x,x,x);\n}`, upd: `rt("camera",1,1,1);` },
    14: { decl: `//Deleting an object\nqb("a",3,0,0);\nqb("b",0,0,0);\ncl("a", Color.blue);\ncl("b", Color.red);`, upd: `//Move until crash\nif(!cd("a","b")) {\n    mv("b",0.05,0,0);\n} else { \n    dl("a");\n}` },
    15: {
        decl: `//Input Detection\nqb("a",3,0,0);`,
        upd: `//Use arrow keys and [A] and [Z]\nif (Input.GetKey (KeyCode.RightArrow))\n    mv("a",0.2,0,0);\nif (Input.GetKey (KeyCode.LeftArrow))\n    mv("a",-0.2,0,0);\nif (Input.GetKey (KeyCode.UpArrow))\n    mv("a",0,0.2,0);\nif (Input.GetKey (KeyCode.DownArrow))\n    mv("a",0,-0.2,0);\nif (Input.GetKey (KeyCode.A))\n    mv("a",0,0,0.2);\nif (Input.GetKey (KeyCode.Z))\n    mv("a",0,0,-0.2);`
    },
    16: {
        decl: `//Blockout\nvar depth=0;\nfor(var x=-15;x<20;x++) {\n    qb("topwall",x,10,depth);\n}\nfor(var y=10;y>-10;y--) {\n    qb("sidewall",-15,y,depth);\n}\nfor(var y=10;y>-10;y--) {\n    qb("sidewall",20,y,depth);\n}\nfor(var x=-15;x<21;x++) {\n    qb("bottomwall",x,-10,depth);\n}\nfunction block(name,x_start,y,color) {\n   var b_depth=0;\n   for(var bx=x_start;bx<x_start+5;bx++) {\n       qb(name,bx,y,b_depth);\n    }\n    cl(name, color);\n}\n\nqb("ball",-3,-6,depth);\nblock("paddle",-3,-8, Color.white);\n\nvar xoffset=-14;\nblock("block0",xoffset,7, Color.red);\nxoffset=xoffset+5;\nblock("block1",xoffset,7, Color.blue);\nxoffset=xoffset+5;\nblock("block2",xoffset,7, Color.green);\nxoffset=5;\nblock("block3",xoffset,4, Color.red);\nxoffset=xoffset+5;\nblock("block4",xoffset,4, Color.blue);\nxoffset=xoffset+5;\nblock("block5",xoffset,4, Color.green);\n\nvars["xspeed"]=0.1;\nvars["yspeed"]=0.1;\n\n// Reposition camera so we can see the board in Three.js\nsp("camera", 2.5, 0, 30);\nan("camera", 0, 0, 0);`,
        upd: `if (Input.GetKey (KeyCode.RightArrow))\n    mv("paddle",0.3,0,0);\nif (Input.GetKey (KeyCode.LeftArrow))\n    mv("paddle",-0.3,0,0);\nif(cd("ball","topwall")) {\n    vars["yspeed"]=-Math.abs(vars["yspeed"]); // Force bounce down\n}\nif(cd("ball","bottomwall")) {\n    vars["yspeed"]=Math.abs(vars["yspeed"]); // Force bounce up\n}\nif(cd("ball","sidewall")) {\n    vars["xspeed"]=-vars["xspeed"];\n}\nif(cd("ball","paddle")) {\n    vars["yspeed"]=Math.abs(vars["yspeed"]);\n}\nmv("ball",vars["xspeed"],vars["yspeed"],0);\nif(cd("ball","block0")) {\n    vars["yspeed"]=-vars["yspeed"];\n    dl("block0");\n}\nif(cd("ball","block1")) {\n    vars["yspeed"]=-vars["yspeed"];\n    dl("block1");\n}\nif(cd("ball","block2")) {\n    vars["yspeed"]=-vars["yspeed"];\n    dl("block2");\n}\nif(cd("ball","block3")) {\n    vars["yspeed"]=-vars["yspeed"];\n    dl("block3");\n}\nif(cd("ball","block4")) {\n    vars["yspeed"]=-vars["yspeed"];\n    dl("block4");\n}\nif(cd("ball","block5")) {\n    vars["yspeed"]=-vars["yspeed"];\n    dl("block5");\n}`
    },
    17: {
        decl: `//Space travel\nfunction big_asteroid(name,x,y,z,color) {\n    qb(name,x,y,z);\n    qb(name,x-1,y,z);\n    qb(name,x,y-1,z);\n    qb(name,x,y,z-1);\n    qb(name,x+1,y,z);\n    qb(name,x,y+1,z);\n    qb(name,x,y,z+1);\n    cl(name, color);\n}\n//Asteroids\nbig_asteroid("Asteroid0",7,7,7, Color.red);\nbig_asteroid("Asteroid1",-7,-7,-7, Color.blue);\nbig_asteroid("Asteroid2",14,14,14, Color.green);\nbig_asteroid("Asteroid3",-14,-14,-14, Color.yellow);\nsp("camera", 0, 0, 0); // Start in center`,
        upd: `//Use arrow keys and [A] and [Z] and Left Control\nif (Input.GetKey (KeyCode.RightArrow))\n    rt("camera",0,2,0);\nif (Input.GetKey (KeyCode.LeftArrow))\n    rt("camera",0,-2,0);\nif (Input.GetKey (KeyCode.UpArrow))\n    rt("camera",2,0,0);\nif (Input.GetKey (KeyCode.DownArrow))\n    rt("camera",-2,0,0);\nif (Input.GetKey (KeyCode.A))\n    mv("camera",0,0,0.5);\nif (Input.GetKey (KeyCode.Z))\n    mv("camera",0,0,-0.5);\nif (Input.GetKey (KeyCode.LeftControl)) {\n    qb("bullet",0,0,0);\n    eq("bullet","camera"); // Takes rotation so local mv works\n}\nif (ex("bullet")) {\n   mv("bullet",0,0,0.5);\n}\nif(cd("bullet","Asteroid0")) \n    dl("Asteroid0");\nif(cd("bullet","Asteroid1")) \n    dl("Asteroid1");\nif(cd("bullet","Asteroid2")) \n    dl("Asteroid2");\nif(cd("bullet","Asteroid3")) \n    dl("Asteroid3");`
    },
    18: {
        decl: `//First person 3D platformer\n// Optimized floor to avoid lagging web browsers with 400 cubes\nqb("floor", 0, -5, 0);\nsc("floor", 40, 1, 40);\ncl("floor", Color.green);\n\n//trees\nfunction drawtree(x,y,z) {\n    var Brown = 0x8b45be; //Translated from Color(139,69,190)\n    qb("trunk",x,y,z);\n    qb("trunk",x,y+1,z);\n    qb("trunk",x,y+2,z);\n    qb("trunk",x,y+3,z);\n    cl("trunk", Brown);\n    qb("bush",x,y+4,z);\n    qb("bush",x+1,y+4,z);\n    qb("bush",x-1,y+4,z);\n    cl("bush", Color.green);\n}\n//trees in front\ndrawtree(0,-4,0);\ndrawtree(5,-4,5);\ndrawtree( -5,-4,15);\n//trees behind\ndrawtree(-3,-4,-10);\ndrawtree(-10,-4,-10);\ndrawtree(5,-4,-15);\n\nvars["gforce"]=-0.1;\nvars["isJumping"]=false;`,
        upd: `//Use arrow keys to move, Left Control to jump\n//Implement gravity\nif(!cd("camera","floor") && !cd("camera","bush") && !vars["isJumping"]) {\n    mv("camera",0,vars["gforce"],0);\n}\nvars["isJumping"] = false;\n\n//Get user input\nif (Input.GetKey (KeyCode.RightArrow))\n    rt("camera",0,2,0);\nif (Input.GetKey (KeyCode.LeftArrow))\n    rt("camera",0,-2,0);\nif (Input.GetKey (KeyCode.LeftControl)) {\n    mv("camera",0,0.3,0);\n    vars["isJumping"] = true;\n}\nif (Input.GetKey (KeyCode.UpArrow) && !cd("camera","trunk"))\n    mv("camera",0,0,0.2);\nif (Input.GetKey (KeyCode.DownArrow))\n    mv("camera",0,0,-0.2);`
    },
    19: {
        title: "tx: textures",
        decl: `// tx(name, textureFile, source, wrap) adds a texture.\n// name: object name, textureFile: a file in Textures/.\n// source is kept for old 3DPL code; the web engine loads local files.\n// wrap 6 repeats one image on every face.\n// wrap 1 uses a 3-by-2 six-sided texture layout.\nqb("texturedCube", 0, 0, 0);\ntx("texturedCube", "stone1.png", "File", 6);`,
        upd: ``
    },
    20: {
        title: "alpha: transparency",
        decl: `// alpha(name, value) changes opacity.\n// 1 is solid, 0 is invisible, and values between are transparent.\nqb("solid", -2, 0, 0);\nqb("glass", 0, 0, 0);\nqb("faint", 2, 0, 0);\ncl("solid", Color.blue);\ncl("glass", Color.blue);\ncl("faint", Color.blue);\nalpha("solid", 1);\nalpha("glass", 0.5);\nalpha("faint", 0.15);`,
        upd: ``
    },
    21: {
        title: "sp, mv, rt, and sr",
        decl: `// The Car Simulator uses four transform functions.\nqb("car", 0, 0, 0);\nsc("car", 3, 1, 5); // sc sets x, y, z size multipliers.\ncl("car", Color.red);\n\n// sp sets an exact world position. cp is another name for sp.\nsp("car", 0, 0, 0);\n\n// sr sets an exact rotation in degrees. an is another name for sr.\nsr("car", 0, 25, 0);`,
        upd: `// mv moves relative to the object's current local direction.\n// rt adds this many degrees to the current rotation.\nrt("car", 0, 0.5, 0);\nmv("car", 0, 0, 0.02);`
    },
    22: {
        title: "Obj and XMLObj",
        decl: `// Obj(jsonFile, instanceName, x, y, z) loads JSON voxel art.\nvars["car"] = Obj("sports-car.json", "car", -3, 0, 0);\nsc("car", 0.19, 0.19, 0.19);\n\n// XMLObj(xmlFile, instanceName, x, y, z) loads legacy XML art.\n// Map(...) in old programs is automatically translated to XMLObj(...).\nvars["tree"] = XMLObj("1tree.xml", "tree", 3, -2, 0);\n\n// Both loaders return a group immediately; its voxels load in the background.`,
        upd: `rt("car", 0, 0.5, 0);\nrt("tree", 0, -0.25, 0);`
    },
    23: {
        title: "vars and transform",
        decl: `// vars keeps values and object references available every frame.\nvars["car"] = Obj("sports-car.json", "car", 0, 0, 0);\nsc("car", 0.19, 0.19, 0.19);\nvars["speed"] = 0.05;\n\n// Loaded objects have Unity-style transform and position properties.\n// Read coordinates with vars["car"].transform.position.x, .y, and .z.`,
        upd: `mv("car", vars["speed"], 0, 0);\n\n// Turn around when the car reaches either side.\nif (Math.abs(vars["car"].transform.position.x) > 4) {\n    vars["speed"] = -vars["speed"];\n}`
    },
    24: {
        title: "parenting objects",
        decl: `// Parenting makes one object follow another.\nvars["car"] = Obj("sports-car.json", "car", 0, 0, 0);\nsc("car", 0.19, 0.19, 0.19);\nvars["tire"] = Obj("sports-car-tires.json", "tire", 0, 0, 0);\nsc("tire", 0.10, 0.10, 0.10);\n\n// The preprocessor converts this legacy .transform.parent syntax\n// into Three.js parenting while keeping the tire's world position.\nvars["tire"].transform.parent = vars["car"].transform;`,
        upd: `// Both the car and its child tire now move together.\nrt("car", 0, 0.5, 0);`
    },
    25: {
        title: "traverse loaded voxels",
        decl: `// traverse(function(obj) {...}) visits a group and all its children.\nvars["car"] = Obj("sports-car.json", "car", 0, 0, 0);\nsc("car", 0.19, 0.19, 0.19);\nvars["painted"] = false;`,
        upd: `// Obj loads asynchronously, so keep checking until meshes exist.\nif (!vars["painted"]) {\n    vars["car"].traverse(function(obj) {\n        if (obj.isMesh) {\n            obj.material.color.setHex(Color.yellow);\n            if (!vars["painted"])\n                console.log("First loaded voxel:", obj.name, obj.position);\n            vars["painted"] = true;\n        }\n    });\n}`
    },
    26: {
        title: "car audio",
        decl: `// AttachSound(objectName, fileName) creates positional 3D audio.\n// It checks your private Audio library first, then shared Audio/, then Sounds/.\n// The object must exist before AttachSound is called; "camera" is also valid.\n// AttachSound("camera", "dunce alarm.mp3");\n// PlaySound("camera");\n//\n// Use PlaySoundLoop(objectName) to repeat, StopSound(objectName) to stop,\n// SetPitch(objectName, value) for pitch, and SetVolume(objectName, 0..1).\n// Object audio becomes quieter after 20 units and is inaudible after 100.\n// Audio begins after the user presses START / STOP. These calls are\n// commented so the tutorial works without an uploaded or shared file.\nqb("car0", 0, 0, 0);\nsc("car0", 3, 1, 5);\ncl("car0", Color.red);`,
        upd: ``
    },
    27: {
        title: "Input.GetKey driving",
        decl: `// Input.GetKey(KeyCode...) is true while a key is held.\nqb("car", 0, 0, 0);\nsc("car", 2, 1, 4);\ncl("car", Color.red);`,
        upd: `// Hold Up/Down to drive and Left/Right to steer.\nif (Input.GetKey(KeyCode.UpArrow))\n    mv("car", 0, 0, 0.1);\nif (Input.GetKey(KeyCode.DownArrow))\n    mv("car", 0, 0, -0.1);\nif (Input.GetKey(KeyCode.LeftArrow))\n    rt("car", 0, -2, 0);\nif (Input.GetKey(KeyCode.RightArrow))\n    rt("car", 0, 2, 0);`
    },
    28: {
        title: "is_touching_voxel",
        decl: `// is_touching_voxel(land, colliders, colliderName) checks one\n// named collider mesh against every voxel mesh in a map or obstacle.\nvars["wall"] = qb("wall", 0, 2, 0);\nsc("wall", 6, 6, 1);\ncl("wall", Color.green);\n\n// collider_front is 10 units in front of this moving collider group.\nvars["colliders"] = Obj("car_colliders.json", "colliders", 0, 0, -12);\nvars["colliderSpeed"] = 0.08;\nsp("camera", 10, 8, 24);\nan("camera", -15, 25, 0);`,
        upd: `// The collider moves automatically after START is clicked.\nmv("colliders", 0, 0, -vars["colliderSpeed"]);\n\nvar touching = is_touching_voxel(\n    vars["wall"], vars["colliders"], "collider_front");\n\n// The wall turns red whenever collider_front touches it.\ncl("wall", touching ? Color.red : Color.green);\n\n// Reverse so the demonstration repeats.\nif (vars["colliders"].transform.position.z > 2)\n    vars["colliderSpeed"] = -0.08;\nif (vars["colliders"].transform.position.z < -12)\n    vars["colliderSpeed"] = 0.08;`
    },
    29: {
        title: "reusable simulator functions",
        decl: `// JavaScript functions group repeated simulator instructions.\nvars["car"] = qb("car", 0, 0, 0);\nsc("car", 2, 1, 4);\ncl("car", Color.red);\nvars["tire"] = qb("tire", 1.2, -0.6, 1);\nsc("tire", 0.5, 0.5, 0.5);\ncl("tire", Color.black);\nvars["tire"].transform.parent = vars["car"].transform;\n\n// Store functions in vars when the update editor must call them.\nvars["move_camera"] = function() {\n    sp("camera",\n        vars["car"].transform.position.x,\n        vars["car"].transform.position.y + 3,\n        vars["car"].transform.position.z + 10);\n};\n\nvars["rotate_tires"] = function() {\n    rt("tire", 10, 0, 0);\n};\n\nvars["drive"] = function(distance) {\n    mv("car", 0, 0, distance);\n    vars["rotate_tires"]();\n};`,
        upd: `if (Input.GetKey(KeyCode.UpArrow))\n    vars["drive"](0.1);\nif (Input.GetKey(KeyCode.DownArrow))\n    vars["drive"](-0.1);\n\n// Run camera follow every frame, as Car Simulator 6 does.\nvars["move_camera"]();`
    },
    30: {
        title: "Full Car Simulator 6",
        decl: `// FULL CAR SIMULATOR 6\n// Arrow keys drive and steer. Space launches the car upward.\nvars["land"] = XMLObj("3DLP_MAP_ISLAND_extended.xml", "land", 0, 0, 0);\nvars["car"] = Obj("sports-car.json", "car0", -2, 0, -10);\nvars["car_colliders"] = Obj("car_colliders.json", "car_colliders", 0, 0, 0);\nvars["car_colliders"].transform.parent = vars["car"].transform;\n\nvars["car_colliders"].traverse(function(obj) {\n    if (obj.isMesh)\n        console.log("CAR COLLIDER:", obj.name, obj.position);\n});\n\nsr("land", 0, 180, 0);\nmv("land", 0, 0, -20);\nsc("car0", 0.19, 0.19, 0.19);\n\nvars["tire1"] = Obj("sports-car-tires.json", "tire1", 0, 0, 0);\nvars["tire2"] = Obj("sports-car-tires.json", "tire2", 0, 0, 0);\nvars["tire3"] = Obj("sports-car-tires.json", "tire3", 0, 0, 0);\nvars["tire4"] = Obj("sports-car-tires.json", "tire4", 0, 0, 0);\nsc("tire1", 0.10, 0.10, 0.10);\nsc("tire2", 0.10, 0.10, 0.10);\nsc("tire3", 0.10, 0.10, 0.10);\nsc("tire4", 0.10, 0.10, 0.10);\n\nsp("tire1", vars["car"].transform.position.x-0.7, vars["car"].transform.position.y, vars["car"].transform.position.z-1);\nsp("tire2", vars["car"].transform.position.x+0.7, vars["car"].transform.position.y, vars["car"].transform.position.z-1);\nsp("tire3", vars["car"].transform.position.x-0.7, vars["car"].transform.position.y, vars["car"].transform.position.z+1);\nsp("tire4", vars["car"].transform.position.x+0.7, vars["car"].transform.position.y, vars["car"].transform.position.z+1);\n\nvars["tire1"].transform.parent = vars["car"].transform;\nvars["tire2"].transform.parent = vars["car"].transform;\nvars["tire3"].transform.parent = vars["car"].transform;\nvars["tire4"].transform.parent = vars["car"].transform;\n\n// AttachSound checks your private Audio library first, then legacy Sounds/.\n// Uncomment these after uploading car.wav and NOW7.wav to your account.\n// AttachSound("car0", "car.wav");\n// PlaySoundLoop("car0");\n// AttachSound("camera", "NOW7.wav");\n// PlaySoundLoop("camera");\n// SetVolume("camera", 0.1);\n\n// Functions are stored in vars so declarations and update share them.\nvars["move_camera"] = function() {\n    sp("camera", vars["car"].transform.position.x,\n        vars["car"].transform.position.y,\n        vars["car"].transform.position.z);\n    mv("camera", 3, 3, -30);\n};\n\nvars["rotate_tires"] = function() {\n    sr("tire1", vars["tire1"].transform.eulerAngles.x+45, vars["tire1"].transform.eulerAngles.y, vars["tire1"].transform.eulerAngles.z);\n    sr("tire2", vars["tire2"].transform.eulerAngles.x+45, vars["tire2"].transform.eulerAngles.y, vars["tire2"].transform.eulerAngles.z);\n    sr("tire3", vars["tire3"].transform.eulerAngles.x+45, vars["tire3"].transform.eulerAngles.y, vars["tire3"].transform.eulerAngles.z);\n    sr("tire4", vars["tire4"].transform.eulerAngles.x+45, vars["tire4"].transform.eulerAngles.y, vars["tire4"].transform.eulerAngles.z);\n};`,
        upd: `// Get user input.\nif (Input.GetKey(KeyCode.RightArrow)) {\n    rt("car0", 0, 3, 0);\n    rt("camcol", 0, 3, 0);\n}\nif (Input.GetKey(KeyCode.LeftArrow)) {\n    rt("car0", 0, -3, 0);\n    rt("camcol", 0, -3, 0);\n}\nif (Input.GetKey(KeyCode.Space)) {\n    mv("car0", 0, 100, 0);\n    mv("camcol", 0, 100, 0);\n}\n\nif (Input.GetKey(KeyCode.DownArrow) &&\n    !is_touching_voxel(vars["land"], vars["car_colliders"], "collider_back")) {\n    mv("car0", 0, 0, 1);\n    mv("camcol", 0, 0, 1);\n    vars["rotate_tires"]();\n}\n\nif (Input.GetKey(KeyCode.UpArrow) &&\n    !is_touching_voxel(vars["land"], vars["car_colliders"], "collider_front")) {\n    mv("car0", 0, 0, -1);\n    mv("camcol", 0, 0, -1);\n    vars["rotate_tires"]();\n}\n\n// Follow the car every frame.\nvars["move_camera"]();`
    },
    31: {
        title: "Helicopet Flight Simulator 3",
        decl: "// HELICOPET FLIGHT SIMULATOR 3 - converted for 3DPL Web\n// W/S: up/down, A/D: turn, arrow keys: forward/back/sideways.\n\n// Use the same island as Car Simulator 6.\nvars[\"land\"] = XMLObj(\"3DLP_MAP_ISLAND_extended.xml\", \"land\", 0, 0, 0);\nsr(\"land\", 0, 180, 0);\nmv(\"land\", 0, 0, -20);\n\n// Load the complete helicopter and its separate rotor at the same origin.\nvars[\"helicopter\"] = Obj(\n    \"heli_no_proeller.json\", \"helicopter\", 0, 0, -10);\nvars[\"propeller\"] = Obj(\n    \"propeller.json\", \"propeller\", 0, 0, -10);\nsc(\"helicopter\", 0.25, 0.25, 0.25);\nsc(\"propeller\", 0.25, 0.25, 0.25);\nvars[\"propeller\"].transform.parent = vars[\"helicopter\"].transform;\n\n// Load four invisible collision probes, just like the car simulator.\nvars[\"helicopter_colliders\"] = Obj(\n    \"helicpter_colliders.json\", \"helicopter_colliders\", -2, 0, -10);\nsc(\"helicopter_colliders\", 0.25, 0.25, 0.25);\nvars[\"helicopter_colliders\"].transform.parent =\n    vars[\"helicopter\"].transform;\n\nvars[\"flightSpeed\"] = 1;\nvars[\"turnSpeed\"] = 5;\nvars[\"idleRotorSpeed\"] = 15\nvars[\"fastRotorSpeed\"] = 30\n\n// Follow from behind using the helicopter's current turning angle.\nvars[\"move_camera\"] = function() {\n    sp(\"camera\",\n        vars[\"helicopter\"].transform.position.x,\n        vars[\"helicopter\"].transform.position.y + 8,\n        vars[\"helicopter\"].transform.position.z);\n    sr(\"camera\", 18, vars[\"helicopter\"].transform.eulerAngles.y, 0);\n    mv(\"camera\", 3, 3, -30);\n};\n\n// Positive rt input becomes clockwise rotation in this web engine.\nvars[\"rotate_propeller\"] = function(amount) {\n    rt(\"propeller\", 0, amount, 0);\n};\n\n// AttachSound checks your private Audio library first, then legacy Sounds/.\n// Uncomment after uploading these files to your account.\n// AttachSound(\"helicopter\", \"helicopter.wav\");\n// PlaySoundLoop(\"helicopter\");\n// AttachSound(\"camera\", \"NOW1.wav\");\n// PlaySoundLoop(\"camera\");\n// SetVolume(\"camera\", 0.05);\n\nvars[\"move_camera\"]();",
        upd: "var speed = vars[\"flightSpeed\"];\nvar colliders = vars[\"helicopter_colliders\"];\nvar land = vars[\"land\"];\nvar goingUp = Input.GetKey(KeyCode.W);\nvar goingDown = Input.GetKey(KeyCode.S);\n\n// W goes up; the top probe prevents entering terrain from below.\nif (goingUp &&\n    !is_touching_voxel(land, colliders, \"collider_top\"))\n    mv(\"helicopter\", 0, speed, 0);\n\n// S goes down; the bottom probe prevents entering the ground.\nif (goingDown &&\n    !is_touching_voxel(land, colliders, \"collider_bottom\"))\n    mv(\"helicopter\", 0, -speed, 0);\n\n// A turns counterclockwise; D turns clockwise.\nif (Input.GetKey(KeyCode.A))\n    rt(\"helicopter\", 0, -vars[\"turnSpeed\"], 0);\nif (Input.GetKey(KeyCode.D))\n    rt(\"helicopter\", 0, vars[\"turnSpeed\"], 0);\n\n// Arrow keys move in the helicopter's local directions.\nif (Input.GetKey(KeyCode.UpArrow) &&\n    !is_touching_voxel(land, colliders, \"collider_front\"))\n    mv(\"helicopter\", 0, 0, speed);\nif (Input.GetKey(KeyCode.DownArrow) &&\n    !is_touching_voxel(land, colliders, \"collider_back\"))\n    mv(\"helicopter\", 0, 0, -speed);\nif (Input.GetKey(KeyCode.LeftArrow))\n    mv(\"helicopter\", -speed, 0, 0);\nif (Input.GetKey(KeyCode.RightArrow))\n    mv(\"helicopter\", speed, 0, 0);\n\n// The rotor always spins clockwise and speeds up during ascent/descent.\nvar rotorSpeed = (goingUp || goingDown)\n    ? vars[\"fastRotorSpeed\"]\n    : vars[\"idleRotorSpeed\"];\nvars[\"rotate_propeller\"](rotorSpeed);\nvars[\"move_camera\"]();"
    },
    32: {
        title: "Helicopter and LoadMap collisions",
        decl: `// TUTORIAL 32: HELICOPTER COLLISION WITH A JSON MAP
// W/S: up/down, A/D: turn, arrows: forward/back/sideways.
// The green floor and orange walls are loaded from Maps/.
vars["flight_map"] = LoadMap(
    "tutorial32_helicopter_map.json", "flight_map");

// Load the helicopter, rotor, and six invisible collision probes.
vars["helicopter"] = Obj(
    "heli_no_proeller.json", "helicopter", 0, 2, -8);
vars["propeller"] = Obj(
    "propeller.json", "propeller", 0, 2, -8);
vars["helicopter_colliders"] = Obj(
    "helicpter_colliders.json", "helicopter_colliders", 0, 2, -8);

sc("helicopter", 0.25, 0.25, 0.25);
sc("propeller", 0.25, 0.25, 0.25);
sc("helicopter_colliders", 0.25, 0.25, 0.25);
vars["propeller"].transform.parent = vars["helicopter"].transform;
vars["helicopter_colliders"].transform.parent =
    vars["helicopter"].transform;

vars["flightSpeed"] = 1;
vars["turnSpeed"] = 5;
vars["idleRotorSpeed"] = 15;
vars["fastRotorSpeed"] = 30;

vars["move_camera"] = function() {
    sp("camera",
        vars["helicopter"].transform.position.x,
        vars["helicopter"].transform.position.y + 8,
        vars["helicopter"].transform.position.z);
    sr("camera", 18, vars["helicopter"].transform.eulerAngles.y, 0);
    mv("camera", 3, 3, -30);
};

vars["rotate_propeller"] = function(amount) {
    rt("propeller", 0, amount, 0);
};

vars["move_camera"]();`,
        upd: `var speed = vars["flightSpeed"];
var goingUp = Input.GetKey(KeyCode.W);
var goingDown = Input.GetKey(KeyCode.S);

// Wait for both JSON files. This prevents movement through empty loading
// placeholders before their voxel meshes are available for collision.
var collisionReady =
    vars["flight_map"].userData.loaded &&
    vars["helicopter_colliders"].userData.loaded;

if (collisionReady) {
    // move_object_with_map_collision moves in 0.2-unit substeps and rolls
    // back the first substep that touches a voxel. This prevents tunneling.
    if (goingUp)
        move_object_with_map_collision(
            vars["flight_map"], vars["helicopter"],
            "collider_top", 0, speed, 0);
    if (goingDown)
        move_object_with_map_collision(
            vars["flight_map"], vars["helicopter"],
            "collider_bottom", 0, -speed, 0);

    if (Input.GetKey(KeyCode.UpArrow))
        move_object_with_map_collision(
            vars["flight_map"], vars["helicopter"],
            "collider_front", 0, 0, speed);
    if (Input.GetKey(KeyCode.DownArrow))
        move_object_with_map_collision(
            vars["flight_map"], vars["helicopter"],
            "collider_back", 0, 0, -speed);
    if (Input.GetKey(KeyCode.LeftArrow))
        move_object_with_map_collision(
            vars["flight_map"], vars["helicopter"],
            "collider_left", -speed, 0, 0);
    if (Input.GetKey(KeyCode.RightArrow))
        move_object_with_map_collision(
            vars["flight_map"], vars["helicopter"],
            "collider_right", speed, 0, 0);

    if (Input.GetKey(KeyCode.A))
        rt("helicopter", 0, -vars["turnSpeed"], 0);
    if (Input.GetKey(KeyCode.D))
        rt("helicopter", 0, vars["turnSpeed"], 0);
}

var rotorSpeed = (goingUp || goingDown)
    ? vars["fastRotorSpeed"]
    : vars["idleRotorSpeed"];
vars["rotate_propeller"](rotorSpeed);
vars["move_camera"]();`
    },
    33: {
        title: "Car Simulator 6 with LoadMap collisions",
        decl: `// TUTORIAL 33: CAR SIMULATOR 6 WITH A JSON MAP
// Arrow keys drive and steer. Space launches the car upward.
// THEMAP.json and every JSON object it references must be on the server.
vars["land"] = LoadMap("THEMAP.json", "land");
vars["car"] = Obj("sports-car.json", "car0", 2, 1, -10);
vars["car_colliders"] = Obj(
    "car_colliders.json", "car_colliders", 2, 1, -10);
vars["car_colliders"].transform.parent = vars["car"].transform;

sr("land", 0, 180, 0);
mv("land", 0, 0, -20);
sc("car0", 0.19, 0.19, 0.19);

vars["tire1"] = Obj("sports-car-tires.json", "tire1", 0, 0, 0);
vars["tire2"] = Obj("sports-car-tires.json", "tire2", 0, 0, 0);
vars["tire3"] = Obj("sports-car-tires.json", "tire3", 0, 0, 0);
vars["tire4"] = Obj("sports-car-tires.json", "tire4", 0, 0, 0);
sc("tire1", 0.10, 0.10, 0.10);
sc("tire2", 0.10, 0.10, 0.10);
sc("tire3", 0.10, 0.10, 0.10);
sc("tire4", 0.10, 0.10, 0.10);

sp("tire1", vars["car"].transform.position.x - 0.7,
    vars["car"].transform.position.y,
    vars["car"].transform.position.z - 1);
sp("tire2", vars["car"].transform.position.x + 0.7,
    vars["car"].transform.position.y,
    vars["car"].transform.position.z - 1);
sp("tire3", vars["car"].transform.position.x - 0.7,
    vars["car"].transform.position.y,
    vars["car"].transform.position.z + 1);
sp("tire4", vars["car"].transform.position.x + 0.7,
    vars["car"].transform.position.y,
    vars["car"].transform.position.z + 1);

vars["tire1"].transform.parent = vars["car"].transform;
vars["tire2"].transform.parent = vars["car"].transform;
vars["tire3"].transform.parent = vars["car"].transform;
vars["tire4"].transform.parent = vars["car"].transform;

// Six degrees per frame is twice the old steering speed of three.
vars["turnSpeed"] = 6;

vars["move_camera"] = function() {
    sp("camera",
        vars["car"].transform.position.x,
        vars["car"].transform.position.y,
        vars["car"].transform.position.z);
    mv("camera", 3, 3, -30);
};

vars["rotate_tires"] = function() {
    sr("tire1", vars["tire1"].transform.eulerAngles.x + 45,
        vars["tire1"].transform.eulerAngles.y,
        vars["tire1"].transform.eulerAngles.z);
    sr("tire2", vars["tire2"].transform.eulerAngles.x + 45,
        vars["tire2"].transform.eulerAngles.y,
        vars["tire2"].transform.eulerAngles.z);
    sr("tire3", vars["tire3"].transform.eulerAngles.x + 45,
        vars["tire3"].transform.eulerAngles.y,
        vars["tire3"].transform.eulerAngles.z);
    sr("tire4", vars["tire4"].transform.eulerAngles.x + 45,
        vars["tire4"].transform.eulerAngles.y,
        vars["tire4"].transform.eulerAngles.z);
};

// This safely advances in small steps and rolls back on a map collision.
vars["drive"] = function(distance, colliderName) {
    return move_object_with_map_collision(
        vars["land"], vars["car"], colliderName,
        0, 0, distance, 0.2);
};

vars["move_camera"]();`,
        upd: `// Steering remains responsive while the large map is loading.
if (Input.GetKey(KeyCode.RightArrow))
    rt("car0", 0, vars["turnSpeed"], 0);
if (Input.GetKey(KeyCode.LeftArrow))
    rt("car0", 0, -vars["turnSpeed"], 0);

// car_colliders is parented to the car, so it follows automatically.
// There is no camcol object in this program.
if (Input.GetKey(KeyCode.Space))
    mv("car0", 0, 1, 0);

// Wait until both asynchronous JSON loads have collision meshes.
var collisionReady =
    vars["land"].userData.loaded &&
    vars["car_colliders"].userData.loaded;

if (collisionReady) {
    if (Input.GetKey(KeyCode.DownArrow) &&
        vars["drive"](1, "collider_back"))
        vars["rotate_tires"]();

    if (Input.GetKey(KeyCode.UpArrow) &&
        vars["drive"](-1, "collider_front"))
        vars["rotate_tires"]();
}

// Follow the car every frame.
vars["move_camera"]();`
    },
    34: {
        title: "Supersmash Tokyo",
        // Source: Programs/finalx3.declarations and .update.
        decl: `// Load this together with finalx3.update: the update uses the state below.
// Every building has its own health, hit shake, and voxel explosion.
vars["fire_targets"] = [];
vars["building"] = function(filename, name, x, y, z, healthKey) {
    var object = Obj(filename, name, x, y, z);
    var health = healthKey || name + "_SDC";
    vars[health] = 30;
    vars["fire_targets"].push({
        name: name, object: object, health: health,
        restPosition: object.position.clone(), restRotation: object.rotation.clone(),
        shakeTime: 0, explosionTime: null, debris: [], destroyed: false
    });
    return object;
};

//TOKYO-TOWER-GRASS
vars["TT_SDC"]=30;
vars["TokyoTower"]=vars["building"]("TokyoTower.json","TT",0,0,0);
//vars["TT"]=Obj("sst_TokyoTower4.json","TT",0,0,0);

//SENSOUJI
vars["SS_SDC"]=30;
vars["Sen"]=vars["building"]("Senouzi.json","SS",22,11,95);

Obj("sstmixbiggrass1.json","biggrass1",0,0,0);
Obj("sstmixbiggrass1.json","biggrass1",12,0,0);
Obj("sstmixbiggrass1.json","biggrass1",12,0,12);
Obj("sstmixbiggrass1.json","biggrass1",12,0,-12);
Obj("sstmixbiggrass1.json","biggrass1",-12,0,0);
Obj("sstmixbiggrass1.json","biggrass1",-12,0,-12);
Obj("sstmixbiggrass1.json","biggrass1",0,0,12);
Obj("sstmixbiggrass1.json","biggrass1",0,0,-12);
Obj("sstmixbiggrass1.json","biggrass1",-12,0,12);

//ROADS-TOKYO-TOWER
Obj("sstroad1.json","road1",-24,0,0);
Obj("sstroad1.json","road1",-24,0,12);
Obj("sstroad1.json","road1",-24,0,-12);

Obj("sstcrossroad1.json","cross1",-24,0,24);

Obj("sstroad1.json","road1",23,0,0);
Obj("sstroad1.json","road1",23,0,12);
Obj("sstroad1.json","road1",23,0,-12);

Obj("sstcrossroad1.json","cross1",23,0,-24);

Obj("sstroad1.json","road2",0,0,24);
Obj("sstroad1.json","road2",12,0,24);
Obj("sstroad1.json","road2",-12,0,24);

Obj("sstcrossroad1.json","cross1",23,0,24);

Obj("sstroad1.json","road2",0,0,-24);
Obj("sstroad1.json","road2",12,0,-24);
Obj("sstroad1.json","road2",-12,0,-24);

Obj("sstcrossroad1.json","cross1",-24,0,-24);

Obj("sstroad1.json","road1",-24,0,36);
Obj("sstcrossroad1.json","cross1",-24,0,48);

//HOUSE-RED-RIVER
vars["H1_SDC"]=30;
vars["Hou"]=vars["building"]("new_House_red1.json","H1",-4,0,40);
Obj("sstmixbiggrass1.json","biggrass1",-12,0,36);
Obj("sstmixbiggrass1.json","biggrass1",-12,0,48);
Obj("sstmixbiggrass1.json","biggrass1",0,0,36);
Obj("sstmixbiggrass1.json","biggrass1",0,0,48);
Obj("sstbgrass1.json","grass1",6,0,53);
Obj("sstdgrass1.json","grass1",6,0,52);
Obj("sstdgrass1.json","grass1",6,0,51);
Obj("sstbgrass1.json","grass1",6,0,50);
Obj("sstdgrass1.json","grass1",6,0,49);
Obj("sstdgrass1.json","grass1",6,0,48);
Obj("sstbgrass1.json","grass1",6,0,47);
Obj("sstbgrass1.json","grass1",6,0,46);
Obj("sstdgrass1.json","grass1",6,0,45);
Obj("sstbgrass1.json","grass1",6,0,44);
Obj("sstdgrass1.json","grass1",6,0,43);
Obj("sstdgrass1.json","grass1",6,0,42);
Obj("sstbgrass1.json","grass1",6,0,41);
Obj("sstdgrass1.json","grass1",6,0,40);
Obj("sstdgrass1.json","grass1",6,0,39);
Obj("sstbgrass1.json","grass1",6,0,38);
Obj("sstdgrass1.json","grass1",6,0,37);
Obj("sstbgrass1.json","grass1",6,0,36);
Obj("sstbgrass1.json","grass1",6,0,35);
Obj("sstdgrass1.json","grass1",6,0,34);
Obj("sstbgrass1.json","grass1",6,0,33);
Obj("sstdgrass1.json","grass1",6,0,32);
Obj("sstdgrass1.json","grass1",6,0,31);
Obj("sstbgrass1.json","grass1",6,0,30);



//HIGHTOWER
vars["HT_SDC"]=30;
vars["Hig"]=vars["building"]("Hightower_A.json","Hig",-37,0,0,"HT_SDC");
Obj("tree1.json","tree1",-37,0,12);
Obj("sstmixbiggrass1.json","biggrass1",-35,0,12);
Obj("tree1.json","tree2",-37,0,-12);
Obj("sstmixbiggrass1.json","biggrass1",-35,0,-12);
Obj("tree1.json","tree3",-37,0,-24);
Obj("sstmixbiggrass1.json","biggrass1",-35,0,-24);
Obj("tree1.json","tree4",-37,0,24);
Obj("sstmixbiggrass1.json","biggrass1",-35,0,24);
Obj("tree1.json","tree5",-37,0,36);
Obj("sstmixbiggrass1.json","biggrass1",-35,0,36);

//BRIDGE

//Obj("stonebridge.json","bridge1",-24,0,59);
//Obj("stonebridge.json","bridge2",25,0,35);

//RIVER

Obj("sstcrossroad1.json","cross1",-36,0,48);

Obj("sstriver1.json","river1",-36,0,59);
Obj("sstriver1.json","river1",-24,0,59);
Obj("sstriver1.json","river1",-12,0,59);
Obj("sstriver1.json","river1",0,0,59);
Obj("sstriver1.json","river1",12,0,59);
Obj("sstriver1.json","river1",12,0,47);
Obj("sstriver1.json","river1",12,0,35);
Obj("sstriver1.json","river1",24,0,35);
Obj("sstriver1.json","river1",36,0,35);
Obj("sstriver1.json","river1",48,0,35);
Obj("sstriver1.json","river1",60,0,35);

//ALONG-THE-RIVER

Obj("sstcrossroad1.json","cross1",-36,0,72);
Obj("sstcrossroad1.json","cross1",-24,0,72);
Obj("sstcrossroad1.json","cross1",-12,0,72);
Obj("sstcrossroad1.json","cross1",0,0,72);
Obj("sstcrossroad1.json","cross1",12,0,72);
Obj("sstcrossroad1.json","cross1",24,0,72);
Obj("sstcrossroad1.json","cross1",32,0,72);
Obj("sstcrossroad1.json","cross1",44,0,72);
Obj("sstcrossroad1.json","cross1",56,0,72);

Obj("sstmixbiggrass1.json","biggrass1",-35,0,84);
Obj("sstmixbiggrass1.json","biggrass1",-23,0,84);
Obj("sstmixbiggrass1.json","biggrass1",-11,0,84);
Obj("sstmixbiggrass1.json","biggrass1",1,0,84);
Obj("sstmixbiggrass1.json","biggrass1",13,0,84);
Obj("sstmixbiggrass1.json","biggrass1",25,0,84);
Obj("sstmixbiggrass1.json","biggrass1",37,0,84);
Obj("sstmixbiggrass1.json","biggrass1",49,0,84);
Obj("sstmixbiggrass1.json","biggrass1",61,0,84);

Obj("sstmixbiggrass1.json","biggrass1",-35,0,96);
Obj("sstmixbiggrass1.json","biggrass1",-23,0,96);
Obj("sstmixbiggrass1.json","biggrass1",-11,0,96);
Obj("sstmixbiggrass1.json","biggrass1",1,0,96);
Obj("sstmixbiggrass1.json","biggrass1",13,0,96);
Obj("sstmixbiggrass1.json","biggrass1",25,0,96);
Obj("sstmixbiggrass1.json","biggrass1",37,0,96);
Obj("sstmixbiggrass1.json","biggrass1",49,0,96);
Obj("sstmixbiggrass1.json","biggrass1",61,0,96);


//TREES-SENSOUJI
Obj("sstcrossroad1.json","cross1",24,0,48);
Obj("sstcrossroad1.json","cross1",24,0,60);
Obj("tree1.json","tree6",36,0,59);
Obj("tree1.json","tree7",36,0,47);
Obj("sstmixbiggrass1.json","biggrass1",36,0,60);
Obj("sstmixbiggrass1.json","biggrass1",36,0,48);
Obj("sstmixbiggrass1.json","biggrass1",48,0,60);
Obj("sstmixbiggrass1.json","biggrass1",48,0,48);
Obj("sstmixbiggrass1.json","biggrass1",60,0,60);
Obj("sstmixbiggrass1.json","biggrass1",60,0,48);



//NEW-HOUSE-RED-BLUE-LEFT
vars["building"]("new_House_red1.json","housered1",-34,0,95);
vars["building"]("new_House_blue1.json","houseblue1",-12,0,95);

//SENSOUJI
//vars["SS_SDC"]=30;
//vars["SS"]=Obj("Senouzi.json","sensouji1",22,11,95);

//NEW-HOUSE-RED-BLUE-RIGHT
vars["building"]("new_House_red1.json","housered2",60,0,95);
vars["building"]("new_House_blue1.json","houseblue2",60,0,70);

//SKYTREE
vars["building"]("skytree3.json","skytree1",60,0,50);

//HIGHTOWER-A-B
vars["building"]("Hightower_A.json","hightower3",60,0,20);
vars["building"]("Hightower_B.json","hightower4",60,0,0);
vars["building"]("Hightower_A.json","hightower5",60,0,-20);
vars["building"]("Hightower_B.json","hightower6",40,0,20);
vars["building"]("Hightower_A.json","hightower7",40,0,0);
vars["building"]("Hightower_B.json","hightower8",40,0,-20);

Obj("sstmixbiggrass1.json","biggrass1",60,0,24);
Obj("sstmixbiggrass1.json","biggrass1",48,0,24);
Obj("sstmixbiggrass1.json","biggrass1",36,0,24);

Obj("sstmixbiggrass1.json","biggrass1",60,0,12);
Obj("sstmixbiggrass1.json","biggrass1",48,0,12);
Obj("sstmixbiggrass1.json","biggrass1",36,0,12);

Obj("sstmixbiggrass1.json","biggrass1",60,0,0);
Obj("sstmixbiggrass1.json","biggrass1",48,0,0);
Obj("sstmixbiggrass1.json","biggrass1",36,0,0);

Obj("sstmixbiggrass1.json","biggrass1",60,0,-12);
Obj("sstmixbiggrass1.json","biggrass1",48,0,-12);
Obj("sstmixbiggrass1.json","biggrass1",36,0,-12);

Obj("sstmixbiggrass1.json","biggrass1",60,0,-24);
Obj("sstmixbiggrass1.json","biggrass1",48,0,-24);
Obj("sstmixbiggrass1.json","biggrass1",36,0,-24);

an("road2",0,90,0);

//Space travel
function big_asteroid(name,x,y,z,color) {
    qb(name,x,y,z);
    qb(name,x-1,y,z);
    qb(name,x,y-1,z);
    qb(name,x,y,z-1);
    qb(name,x+1,y,z);
    qb(name,x,y+1,z);
    qb(name,x,y,z+1);
    cl(name, color);
}
//Asteroids
//big_asteroid("Asteroid0",7,7,7, Color.red);
//big_asteroid("Asteroid1",-7,-7,-7, Color.blue);
//big_asteroid("Asteroid2",14,14,14, Color.green);
//big_asteroid("Asteroid3",-14,-14,-14, Color.yellow);



//Time Lord diversifyer
if(new Date().getHours() > 18) {
  SetSkyStarryNight();
}else{
  SetSkyNone();
}

vars["TT_SDC"]=30;
vars["dragon_head"]=Obj("DragonHead5.json","dragon_head",0,0,0);
((object, x, y, z) => { object.rotateX(-x * Math.PI / 180); object.rotateY(-y * Math.PI / 180); object.rotateZ(-z * Math.PI / 180); })(vars["dragon_head"], 0,180,0);
for(var i=0;i<6;i++){
  vars["dragon_body"+i]=Obj("DragonTrunk2.json","dragon_body"+i,0,-5,-13*(i+1));
  ((object, x, y, z) => { object.rotateX(-x * Math.PI / 180); object.rotateY(-y * Math.PI / 180); object.rotateZ(-z * Math.PI / 180); })(vars["dragon_body"+i], 0,180,0);
  //adding parent child relationship to be able to scale based on just one scale to retain same ratio
  if(i==0){
    vars["dragon_head"].attach(vars["dragon_body0"]);
  }
else{
    vars["dragon_head"].attach(vars["dragon_body"+i]);
  }
}
//vars["TokyoTower"]=Obj("TokyoTower3.json","TT",0,0,20);
vars["dragon_tail"]=Obj("DragonTail.json","dragon_tail",0,0,-13*8);
((object, x, y, z) => { object.rotateX(-x * Math.PI / 180); object.rotateY(-y * Math.PI / 180); object.rotateZ(-z * Math.PI / 180); })(vars["dragon_tail"], 0,180,0);
vars["dragon_head"].attach(vars["dragon_tail"]);
function sc_(name, x, y, z) {
    sc(name, x, y, z);
}
vars["dragon_y_max"]=vars["dragon_head"].position.y+1;
vars["dragon_y_min"]=vars["dragon_head"].position.y-1;
vars["rad"]=0;

//===========================================
sc_("dragon_head",0.1,0.1,0.1);
// Keep the body and its downward wave above the map's ground surface.
sp("dragon_head", 0, 3, 0);
vars["dragon_y_max"] = 4;
vars["dragon_y_min"] = 2;
// Controls: arrows drive/turn, W/S climb/descend, Space breathes fire.
// Right Ctrl also fires for compatibility with the onscreen controller.
vars["dragon_wave_parts"] = [];
for (var segment = 0; segment < 6; segment++) {
    vars["dragon_wave_parts"].push(vars["dragon_body" + segment]);
}
vars["dragon_wave_parts"].push(vars["dragon_tail"]);
vars["dragon_wave_rest_y"] = vars["dragon_wave_parts"].map(function(part) {
    return part.position.y;
});
vars["dragon_wave_amplitude"] = 5; // 0.5 world units after the head's 0.1 scale.
vars["dragon_wave_speed"] = 4; // Radians per second.
vars["fire_particles"] = [];
vars["fire_serial"] = 0;
vars["fire_cooldown"] = 0;
vars["BreathOrigine"] = qb("BreathOrigine", 0, 0, 0);
// add() keeps the following coordinates local to the scaled, rotating head.
// DragonHead5's snout ends at local Z=-24; emit just beyond it.
vars["dragon_head"].add(vars["BreathOrigine"]);
vars["BreathOrigine"].position.set(0, 0, -25);
cl("BreathOrigine", Color.black);
alpha("BreathOrigine", 0);
vars["TTHP"]=10;
vars["TTBreak"]=false;

// Attach and request music once during setup, never on every update frame.
// music.mp3 is included in the shared Audio library for this tutorial.
AttachSound("camera", "music.mp3");
PlaySound("camera");
`,
        upd: `// Requires the matching finalx3.declarations (dragon waves, fire, and buildings).
// Music is attached once in declarations so updates never restart its loading.
// Controls: arrows drive/turn, W/S climb/descend, Space or Right Ctrl fires.
var dragonDt = Math.min(Math.max(Time.deltaTime, 0), 0.05);
var drive = Number(Input.GetKey(KeyCode.UpArrow)) - Number(Input.GetKey(KeyCode.DownArrow));
var turn = Number(Input.GetKey(KeyCode.RightArrow)) - Number(Input.GetKey(KeyCode.LeftArrow));
var climb = Number(Input.GetKey(KeyCode.W)) - Number(Input.GetKey(KeyCode.S));
rt("dragon_head", 0, turn * 40 * dragonDt, 0);
mv("dragon_head", 0, climb * 3 * dragonDt, drive * 10 * dragonDt);

// Set each segment relative to its resting height, avoiding cumulative drift.
vars["rad"] = (vars["rad"] + vars["dragon_wave_speed"] * dragonDt) % (Math.PI * 2);
for (var i = 0; i < vars["dragon_wave_parts"].length; i++) {
    vars["dragon_wave_parts"][i].position.y = vars["dragon_wave_rest_y"][i] +
        Math.sin(vars["rad"] - i * Math.PI / 7) * vars["dragon_wave_amplitude"];
}

// Unity's original camera offset, facing the dragon in Three.js.
sp("camera", vars["dragon_head"].position.x - 1,
    vars["dragon_head"].position.y + 12, vars["dragon_head"].position.z - 30);
an("camera", 22, 180, 0);

// Keep existing flames moving along their launch direction, even after a turn
// or releasing the fire key. Expire them so the scene cannot grow indefinitely.
for (var flameIndex = vars["fire_particles"].length - 1; flameIndex >= 0; flameIndex--) {
    var flame = vars["fire_particles"][flameIndex];
    flame.object.position.addScaledVector(flame.direction, 25 * dragonDt);
    flame.life -= dragonDt;
    for (var targetIndex = 0; targetIndex < vars["fire_targets"].length; targetIndex++) {
        var target = vars["fire_targets"][targetIndex];
        if (!target.destroyed && vars[target.health] > 0 && cd(flame.object.name, target.name)) {
            vars[target.health] -= 1;
            target.shakeTime = 0.3;
            flame.life = 0;
            break;
        }
    }
    if (flame.life <= 0) {
        dl(flame.object.name);
        vars["fire_particles"].splice(flameIndex, 1);
    }
}

var breathingFire = Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.RightControl);
vars["fire_cooldown"] = Math.max(0, vars["fire_cooldown"] - dragonDt);
if (breathingFire && vars["fire_cooldown"] <= 0.000001) {
    // Refresh parent transforms before converting the mouth to world space.
    var mouthPosition = vars["BreathOrigine"].getWorldPosition(
        vars["dragon_head"].position.clone());
    var fireDirection = vars["dragon_head"].localToWorld(
        vars["dragon_head"].position.clone().set(0, 0, -26));
    fireDirection.sub(mouthPosition).normalize();
    var fireName = "fire" + vars["fire_serial"]++;
    var fireObject = qb(fireName, mouthPosition.x, mouthPosition.y, mouthPosition.z);
    sc(fireName, 0.35, 0.35, 0.35);
    cl(fireName, Math.random() < 0.5 ? 0xf6f337 : 0xad4e1a);
    vars["fire_particles"].push({ object: fireObject, direction: fireDirection, life: 2 });
    vars["fire_cooldown"] = 0.1;
} else if (!breathingFire) {
    vars["fire_cooldown"] = 0;
}


// Apply the same hit shake and explosion to every registered building.
for (var buildingIndex = 0; buildingIndex < vars["fire_targets"].length; buildingIndex++) {
    var building = vars["fire_targets"][buildingIndex];
    if (building.destroyed) continue;

    // Restore the original transform so repeated hits never make buildings drift.
    building.object.position.copy(building.restPosition);
    building.object.rotation.copy(building.restRotation);

    if (vars[building.health] <= 0) {
        if (building.explosionTime === null) {
            building.explosionTime = 0;
            // Snapshot voxels once; their velocities remain stable during flight.
            building.object.children.forEach(function(voxel) {
                if (!voxel.isMesh) return;
                building.debris.push({
                    object: voxel,
                    velocity: voxel.position.clone().set(
                        (Math.random() - 0.5) * 24,
                        5 + Math.random() * 15,
                        (Math.random() - 0.5) * 24)
                });
            });
        }
        building.explosionTime += dragonDt;
        for (var debrisIndex = 0; debrisIndex < building.debris.length; debrisIndex++) {
            var fragment = building.debris[debrisIndex];
            fragment.velocity.y -= 20 * dragonDt;
            fragment.object.position.addScaledVector(fragment.velocity, dragonDt);
            fragment.object.rotateX(dragonDt * 2);
            fragment.object.rotateZ(dragonDt);
        }
        if (building.explosionTime >= 1.25) {
            // Delete once, after the explosion, including empty loaded groups.
            dl(building.name);
            building.debris.length = 0;
            building.destroyed = true;
        }
    } else if (building.shakeTime > 0) {
        building.shakeTime = Math.max(0, building.shakeTime - dragonDt);
        var shakeStrength = building.shakeTime / 0.3;
        building.object.position.x += Math.sin(building.shakeTime * 80) * 0.3 * shakeStrength;
        building.object.rotation.z += Math.sin(building.shakeTime * 65) * 0.05 * shakeStrength;
        building.object.rotation.x += Math.cos(building.shakeTime * 75) * 0.03 * shakeStrength;
    }
}
`
    },
    35: {
        title: "DUNGEON 6",
        // Source: Programs/DUNGEON 6.declarations and .update.
        decl: `// DUNGEON 6 — 3DPL v3. Load together with DUNGEON 6.update.
// W/S: forward/back; A/D: turn; Space: shoot.
// Shoot a button once to move its door, the pillar, or the helicopter bridge.
// Collect the key to lift door2, then shoot the exit lock to reach the bridge.
// Large yellow targets are shootable switches; green means activated.
vars["required_objects"] = [];
vars["load_object"] = function(file, name, x, y, z) {
    var object = Obj(file, name, x, y, z);
    vars["required_objects"].push(object);
    return object;
};

// Unlit targets stay bright in dark corridors and are readable from any side.
vars["locks"] = {};
vars["make_lock"] = function(name, x, y, z) {
    var lock = qb(name, x, y, z);
    lock.material.dispose();
    lock.material = new THREE.MeshBasicMaterial({ color: 0xffcc00 });
    sc(name, 1.15, 1.15, 1.15);
    var ringGeometry = new THREE.RingGeometry(0.22, 0.34, 24);
    var ringMaterial = new THREE.MeshBasicMaterial({ color: 0x151515, side: THREE.DoubleSide });
    [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]].forEach(function(axis) {
        var normal = new THREE.Vector3(axis[0], axis[1], axis[2]);
        var ring = new THREE.Mesh(ringGeometry, ringMaterial);
        ring.position.copy(normal).multiplyScalar(0.502);
        ring.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1), normal);
        lock.add(ring);
    });
    vars["locks"][name] = lock;
    return lock;
};

vars["dungeon"] = LoadMap("Dungeon2.json", "dungeon0");
vars["Camera_Colliders"]=vars["load_object"]("Camera_Coliders.json","Camera_Coliders0",0,1,-10);
//
vars["helicopter"]=vars["load_object"]("Futuristic_Helycopter.json","helly",-51,-6,12);
vars["make_lock"]("btn5",-27,1,10.2);
//
vars["bridge"]=vars["load_object"]("ladder_to_helly.json","ladder",-30,-1,14);
//
vars["key"]=vars["load_object"]("dungeonkeys.json","keys",29,1,17);
//
vars["pillar"]=vars["load_object"]("pillars.json","pillar",27,-1,16);
// Keep both pillar controls inside the room, in front of the X=32 wall.
vars["make_lock"]("btn3",31,1,12);
//
vars["make_lock"]("btn4",31,1,22);
//
vars["load_object"]("key_stone.json","stone",29,0,17);
//
// Center the rotating blade between the corridor walls (X=-3 and X=4).
// At this pivot height the downward blade sweeps through a standing player.
vars["trap1"]=vars["load_object"]("trap2.json","traps",0.5,6.4,25);
sc("traps",-0.4,-0.4,-0.4);
//
// Positive scale keeps the backs above the feet. Place the feet on floor Y=-0.5.
vars["spider1"]=vars["load_object"]("spider.json","spider1",0,0.85,7);
sc("spider1",0.3,0.3,0.3);
//
vars["load_object"]("spider.json","spider2",0,0.85,32);
sc("spider2",0.3,0.3,0.3);
//
vars["load_object"]("spider.json","spider3",-1,0.85,36);
sc("spider3",0.3,0.3,0.3);
//
vars["load_object"]("spider.json","spider4",2,0.85,36);
sc("spider4",0.3,0.3,0.3);
//
vars["load_object"]("spider.json","spider5",10,0.55,16);
sc("spider5",0.7 / 3,0.7 / 3,0.7 / 3);
//
vars["load_object"]("spider.json","spider6",24,0.55,17);
sc("spider6",0.7 / 3,0.7 / 3,0.7 / 3);
//
vars["load_object"]("spider.json","spider7",2,0.85,7);
sc("spider7",0.3,0.3,0.3);
//
vars["load_object"]("spider.json","spider8",-2,0.85,7);
sc("spider8",0.3,0.3,0.3);
//
vars["door0"]=(vars["load_object"]("door1.json","door0",0,2,11));
// Facing +Z in v3, +X is the player's left.
vars["make_lock"]("btn0",2,1,10);
//
vars["door1"]=vars["load_object"]("door2.json","door1",3,0,20);
vars["make_lock"]("btn1",3,1,21.5);
//
vars["door2"]=vars["load_object"]("door3.json","door2",15,-1,15);
vars["make_lock"]("btn2",13.8,1,15.2);
//
vars["door4"] = vars["load_object"]("door3.json","door4",-13,1,14);
// Exit to the helicopter bridge: put its lock on the accessible hallway side
// of the X=-13 wall, beside the doorway rather than behind the closed gate.
vars["make_lock"]("btn6",-12,1,20);

// The Unity map contained one Dungeon2 object at the origin. LoadMap supplies
// voxel collisions; these moving obstacles also belong to the collision map.
vars["hardObjectsArray"] = [
    vars["door0"], vars["door1"], vars["door2"], vars["pillar"], vars["door4"]
];
vars["hardObjectsArray"].forEach(function(object) {
    vars["dungeon"].attach(object);
});
// These surfaces support the player's feet as well as the dungeon floor.
vars["dungeon"].attach(vars["bridge"]);
vars["dungeon"].attach(vars["helicopter"]);

// The legacy front probe points +Z, while v3 forward is -Z. Mirror the probes,
// reduce their size to clear the floor, and hide them from the first-person view.
sc("Camera_Coliders0", 0.5, 0.5, -0.5);
vars["Camera_Colliders"].visible = false;
// This parent is scaled by 0.5: the foot probe is 0.4 x 0.2 x 0.4 in world
// units, with its bottom 1.5 units below the camera (the starting eye height).
vars["feet"] = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.4, 0.8),
    new THREE.MeshBasicMaterial());
vars["feet"].name = "dungeon_feet";
vars["feet"].position.set(0, -2.8, 0);
vars["Camera_Colliders"].add(vars["feet"]);
sr("Camera_Coliders0", 0, 180, 0);
// A program-owned reticle also works in the shared player and is cleared by cs().
vars["aim"] = qb("dungeon_aim", 0, 0, 0);
vars["aim"].geometry = new THREE.RingGeometry(0.003, 0.005, 24);
vars["aim"].material.dispose();
vars["aim"].material = new THREE.MeshBasicMaterial({
    color: 0xffffff, depthTest: false, depthWrite: false
});
vars["aim"].renderOrder = 10000;
vars["aim_direction"] = new THREE.Vector3();
vars["sync_camera"] = function() {
    var player = vars["Camera_Colliders"];
    sp("camera", player.position.x, player.position.y, player.position.z);
    sr("camera", 0, -player.rotation.y * 180 / Math.PI, 0);
    camera.getWorldDirection(vars["aim_direction"]);
    vars["aim"].position.copy(player.position).addScaledVector(vars["aim_direction"], 0.3);
    vars["aim"].quaternion.copy(camera.quaternion);
};
vars["respawn"] = function() {
    vars["grounded"] = false;
    sp("Camera_Coliders0", 0, 1, -10);
    sr("Camera_Coliders0", 0, 180, 0);
    vars["sync_camera"]();
};
vars["walk"] = function(distance) {
    return move_object_with_map_collision(
        vars["dungeon"], vars["Camera_Colliders"],
        distance >= 0 ? "collider_front" : "collider_back",
        0, 0, distance, 0.1);
};

// Tutorial 18's simple gravity: -0.1 per frame at 60 FPS, scaled by time.
// Small collision steps stop the feet on actual voxels, including the bridge,
// rather than on the large bounding box enclosing the whole dungeon.
vars["gforce"] = -0.1;
vars["grounded"] = false;
vars["apply_gravity"] = function(dt) {
    if (dt <= 0) return;
    vars["grounded"] = !move_object_with_map_collision(
        vars["dungeon"], vars["Camera_Colliders"], "dungeon_feet",
        0, vars["gforce"] * 60 * dt, 0, 0.05);
    if (vars["Camera_Colliders"].position.y < -20) vars["respawn"]();
};

// Boarding means standing inside the cabin, not near the rotor or beneath it.
// Coordinates here are local to the unscaled helicopter model.
vars["boarding_zone"] = new THREE.Box3(
    new THREE.Vector3(2, 5.5, 1), new THREE.Vector3(5, 8, 5));
vars["boarding_position"] = new THREE.Vector3();
vars["hasWon"] = false;
vars["check_win"] = function() {
    if (vars["hasWon"] || !vars["grounded"]) return;
    vars["boarding_position"].copy(vars["Camera_Colliders"].position);
    vars["helicopter"].worldToLocal(vars["boarding_position"]);
    if (vars["boarding_zone"].containsPoint(vars["boarding_position"])) {
        vars["hasWon"] = true;
        alert("game over");
    }
};

// Every mechanism takes two seconds to reach its endpoint after one hit.
// Door travel equals its model height, so the complete opening is cleared.
vars["motions"] = {};
vars["add_motion"] = function(name, object, axis, travel) {
    var start = object.position[axis];
    vars["motions"][name] = {
        object: object, axis: axis, start: start, end: start + travel,
        target: start, speed: Math.abs(travel) / 2
    };
};
vars["add_motion"]("door0", vars["door0"], "y", 3);
vars["add_motion"]("door1", vars["door1"], "y", 4);
vars["add_motion"]("door2", vars["door2"], "y", 9);
vars["add_motion"]("door4", vars["door4"], "y", -9);
vars["add_motion"]("pillar", vars["pillar"], "y", 9);
// The 15-voxel bridge extends left to meet the helicopter, then stays there.
vars["add_motion"]("bridge", vars["bridge"], "x", -12);
vars["trigger_motion"] = function(name, reverse) {
    // Every route to the helicopter-room door requires actual key pickup.
    if (name === "door4" && !vars["keyCollected"]) return;
    var motion = vars["motions"][name];
    motion.target = reverse ? motion.start : motion.end;
};
vars["advance_motions"] = function(dt) {
    Object.keys(vars["motions"]).forEach(function(name) {
        var motion = vars["motions"][name];
        var current = motion.object.position[motion.axis];
        var remaining = motion.target - current;
        var distance = motion.speed * dt;
        motion.object.position[motion.axis] = Math.abs(remaining) <= distance
            ? motion.target : current + Math.sign(remaining) * distance;
    });
};

// Use the visible blade instead of the misplaced legacy marker or a large box
// around its entire rotation. Cache meshes only after the JSON has loaded.
vars["trap_blade"] = null;
vars["trap_player_box"] = new THREE.Box3();
vars["trap_voxel_box"] = new THREE.Box3();
vars["trap_body_size"] = new THREE.Vector3(0.6, 1.4, 0.6);
vars["trap_body_center"] = new THREE.Vector3();
vars["trap_hits_player"] = function() {
    if (!vars["trap_blade"]) {
        vars["trap_blade"] = [];
        vars["trap1"].traverse(function(part) {
            if (part.name === "collider_trap") {
                part.visible = false;
            } else if (part.isMesh && part.position.y >= 8) {
                vars["trap_blade"].push(part);
            }
        });
    }
    vars["trap_body_center"].copy(vars["Camera_Colliders"].position);
    vars["trap_body_center"].y -= 0.35;
    vars["trap_player_box"].setFromCenterAndSize(
        vars["trap_body_center"], vars["trap_body_size"]);
    vars["trap1"].updateWorldMatrix(true, true);
    return vars["trap_blade"].some(function(part) {
        if (!part.geometry.boundingBox) part.geometry.computeBoundingBox();
        vars["trap_voxel_box"].copy(part.geometry.boundingBox).applyMatrix4(part.matrixWorld);
        return vars["trap_player_box"].intersectsBox(vars["trap_voxel_box"]);
    });
};
vars["advance_trap"] = function(dt) {
    // Small angular steps catch blade contacts even on a slow frame.
    var steps = Math.max(1, Math.ceil(dt * 120));
    for (var trapStep = 0; trapStep < steps; trapStep++) {
        rt("traps", 0, 0, 100 * dt / steps);
        if (vars["trap_hits_player"]()) {
            vars["respawn"]();
        }
    }
};

vars["moveSpeed"] = 10;
vars["turnSpeed"] = 100;
vars["bullets"] = [];
vars["bulletSerial"] = 0;
vars["shotCooldown"] = 0;
vars["shotInterval"] = 0.1;
vars["bulletSpeed"] = 10;
vars["keyCollected"] = false;
vars["buttons"] = [
    { button: "btn0", motion: "door0" },
    { button: "btn1", motion: "door1" },
    { button: "btn2", motion: "door2" },
    { button: "btn3", motion: "pillar" },
    { button: "btn4", motion: "pillar", reverse: true },
    { button: "btn5", motion: "bridge" },
    { button: "btn6", motion: "door4" }
];
vars["spiders"] = [
    "spider1", "spider2", "spider3", "spider4",
    "spider5", "spider6", "spider7", "spider8"
];
vars["shoot"] = function() {
    var player = vars["Camera_Colliders"];
    var name = "dungeon_bullet_" + vars["bulletSerial"]++;
    var bullet = qb(name, player.position.x, player.position.y, player.position.z);
    bullet.quaternion.copy(player.quaternion);
    vars["bullets"].push({
        object: bullet,
        direction: bullet.position.clone().set(0, 0, -1).applyQuaternion(player.quaternion),
        life: 8
    });
};
vars["respawn"]();
`,
        upd: `// DUNGEON 6: wait for all surfaces before movement, gravity, or shooting.
var dungeonDt = Math.min(Math.max(Time.deltaTime, 0), 0.05);
var dungeonReady = vars["dungeon"].userData.loaded &&
    vars["required_objects"].every(function(object) { return object.userData.loaded; });

if (dungeonReady) {
    if (Input.GetKey(KeyCode.D)) {
        rt("Camera_Coliders0", 0, vars["turnSpeed"] * dungeonDt, 0);
    }
    if (Input.GetKey(KeyCode.A)) {
        rt("Camera_Coliders0", 0, -vars["turnSpeed"] * dungeonDt, 0);
    }
    if (Input.GetKey(KeyCode.W)) {
        vars["walk"](vars["moveSpeed"] * dungeonDt);
    }
    if (Input.GetKey(KeyCode.S)) {
        vars["walk"](-vars["moveSpeed"] * dungeonDt);
    }
    vars["apply_gravity"](dungeonDt);
    vars["sync_camera"]();

    vars["advance_trap"](dungeonDt);
    rt("keys", 0, 150 * dungeonDt, 0);
    rt("spider1", 0, 50 * dungeonDt, 0);
    rt("spider5", 0, 20 * dungeonDt, 0);
    rt("spider6", 0, 190 * dungeonDt, 0);

    if (ex("spider1") && cd("camera", "spider1")) {
        vars["respawn"]();
    }
    if (!vars["keyCollected"] && ex("keys") && cd("camera", "keys")) {
        dl("keys");
        vars["keyCollected"] = true;
        vars["trigger_motion"]("door2");
    }

    vars["shotCooldown"] = Math.max(0, vars["shotCooldown"] - dungeonDt);
    if (Input.GetKey(KeyCode.Space) && vars["shotCooldown"] <= 0.000001) {
        vars["shoot"]();
        vars["shotCooldown"] = vars["shotInterval"];
    }

    // Each projectile keeps its launch direction even while its cube spins.
    // Expire old bullets so holding Space cannot grow the scene indefinitely.
    var buttonHits = {};
    for (var bulletIndex = vars["bullets"].length - 1; bulletIndex >= 0; bulletIndex--) {
        var shot = vars["bullets"][bulletIndex];
        shot.object.position.addScaledVector(shot.direction, vars["bulletSpeed"] * dungeonDt);
        rt(shot.object.name, 72 * dungeonDt, -2 * dungeonDt, 500 * dungeonDt);
        shot.life -= dungeonDt;
        for (var buttonIndex = 0; buttonIndex < vars["buttons"].length; buttonIndex++) {
            var button = vars["buttons"][buttonIndex];
            if (cd(shot.object.name, button.button)) {
                buttonHits[button.button] = true;
            }
        }
        for (var spiderIndex = 0; spiderIndex < vars["spiders"].length; spiderIndex++) {
            var spider = vars["spiders"][spiderIndex];
            if (ex(spider) && cd(shot.object.name, spider)) {
                dl(spider);
            }
        }
        if (shot.life <= 0) {
            dl(shot.object.name);
            vars["bullets"].splice(bulletIndex, 1);
        }
    }
    // One hit starts the complete movement; repeated hits never shift endpoints.
    for (var actionIndex = 0; actionIndex < vars["buttons"].length; actionIndex++) {
        var action = vars["buttons"][actionIndex];
        if (buttonHits[action.button]) {
            vars["trigger_motion"](action.motion, action.reverse);
        }
    }
    vars["advance_motions"](dungeonDt);
    vars["check_win"]();
    vars["buttons"].forEach(function(action) {
        var motion = vars["motions"][action.motion];
        var activeTarget = action.reverse ? motion.start : motion.end;
        vars["locks"][action.button].material.color.setHex(
            motion.target === activeTarget ? 0x55ff88 : 0xffcc00);
    });
}
`
    },
    36: {
        title: "Helicopter Flight Simulator 4",
        decl: `// HELICOPET FLIGHT SIMULATOR 4 — based on tutorial 32.
// W/S: climb/descend; A/D: turn; arrows: forward/back/sideways.
// Space: fast lift; Z/X: roll the follow camera.
// Load this together with the matching .update file.
vars["flight_map"] = LoadMap("THEMAP.json", "flight_map");

// Use tutorial 32's helicopter, rotor, scale, and six invisible probes.
// Start four units above the old spawn so the smaller model clears the map.
vars["helicopter"] = Obj(
    "heli_no_proeller.json", "helicopter", -39.62049, 45.35633, 107.3032);
vars["propeller"] = Obj(
    "propeller.json", "propeller", -39.62049, 45.35633, 107.3032);
vars["helicopter_colliders"] = Obj(
    "helicpter_colliders.json", "helicopter_colliders", -39.62049, 45.35633, 107.3032);
sc("helicopter", 0.25, 0.25, 0.25);
sc("propeller", 0.25, 0.25, 0.25);
sc("helicopter_colliders", 0.25, 0.25, 0.25);
vars["propeller"].transform.parent = vars["helicopter"].transform;
vars["helicopter_colliders"].transform.parent = vars["helicopter"].transform;

// Tutorial 32's rates at 60 FPS; update scales them for elapsed time.
vars["flightSpeed"] = 1;
vars["turnSpeed"] = 5;
vars["idleRotorSpeed"] = 15;
vars["fastRotorSpeed"] = 30;
vars["liftBoost"] = 100; // World units per second.
vars["cameraRoll"] = 0;
vars["enginePitch"] = 1;

vars["move_camera"] = function() {
    // Tutorial 32's camera follows the helicopter's heading.
    var heading = -vars["helicopter"].rotation.y * 180 / Math.PI;
    sp("camera", vars["helicopter"].position.x,
        vars["helicopter"].position.y + 8, vars["helicopter"].position.z);
    sr("camera", 18, heading, 0);
    mv("camera", 3, 3, -30);
    sr("camera", 18, heading, vars["cameraRoll"]);
};

vars["fly"] = function(probe, x, y, z) {
    return move_object_with_map_collision(
        vars["flight_map"], vars["helicopter"], probe, x, y, z, 0.2);
};

vars["rotate_propeller"] = function(amount) {
    rt("propeller", 0, amount, 0);
};

// Preserve Simulator 4's engine and background music, attached once.
AttachSound("helicopter", "helicopter.wav");
PlaySoundLoop("helicopter");
AttachSound("camera", "NOW1.wav");
PlaySoundLoop("camera");
SetVolume("camera", 0.05);
vars["move_camera"]();
`,
        upd: `// Tutorial 32 controls and collision probes, with Simulator 4's audio and boost.
var flightDt = Math.min(Math.max(Time.deltaTime, 0), 0.05);
var frameScale = flightDt * 60;
var speed = vars["flightSpeed"] * frameScale;
var goingUp = Input.GetKey(KeyCode.W);
var goingDown = Input.GetKey(KeyCode.S);
var goingForward = Input.GetKey(KeyCode.UpArrow);
var goingBack = Input.GetKey(KeyCode.DownArrow);
var boosting = Input.GetKey(KeyCode.Space);

// Do not move through placeholders while the map or collision probes load.
var collisionReady = vars["flight_map"].userData.loaded &&
    vars["helicopter"].userData.loaded && vars["propeller"].userData.loaded &&
    vars["helicopter_colliders"].userData.loaded;
var enginePitch = 1;
if (collisionReady) {
    if (goingUp) {
        vars["fly"]("collider_top", 0, speed, 0);
        enginePitch = 1.7;
    }
    if (goingDown) {
        vars["fly"]("collider_bottom", 0, -speed, 0);
        enginePitch = 0.5;
    }
    if (goingForward) {
        vars["fly"]("collider_front", 0, 0, speed);
        enginePitch = 1.2;
    }
    if (goingBack) {
        vars["fly"]("collider_back", 0, 0, -speed);
        enginePitch = 1.2;
    }
    if (Input.GetKey(KeyCode.LeftArrow)) {
        vars["fly"]("collider_left", -speed, 0, 0);
    }
    if (Input.GetKey(KeyCode.RightArrow)) {
        vars["fly"]("collider_right", speed, 0, 0);
    }
    if (Input.GetKey(KeyCode.A)) {
        rt("helicopter", 0, -vars["turnSpeed"] * frameScale, 0);
    }
    if (Input.GetKey(KeyCode.D)) {
        rt("helicopter", 0, vars["turnSpeed"] * frameScale, 0);
    }
    if (boosting) {
        vars["fly"]("collider_top", 0, vars["liftBoost"] * flightDt, 0);
        enginePitch = 1.7;
    }
}

// Releasing the flight controls restores idle pitch without Unity GetKeyUp.
if (enginePitch !== vars["enginePitch"]) {
    SetPitch("helicopter", enginePitch);
    vars["enginePitch"] = enginePitch;
}

// The onscreen S button also emits legacy Z; descent must not roll the camera.
if (Input.GetKey(KeyCode.Z) && !goingDown) {
    vars["cameraRoll"] += 120 * flightDt;
}
if (Input.GetKey(KeyCode.X)) {
    vars["cameraRoll"] -= 120 * flightDt;
}
var rotorSpeed = (goingUp || goingDown || boosting)
    ? vars["fastRotorSpeed"] : vars["idleRotorSpeed"];
vars["rotate_propeller"](rotorSpeed * frameScale);
vars["move_camera"]();
`
    }
};

const tutContainer = document.querySelector('.tutorial-row');
tutContainer.innerHTML = ''; 
let suppressDeclarationEvaluation = false;

for (let i = 1; i <= Object.keys(tutorials).length; i++) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.id = `tut-${i}`;
    btn.innerText = `${i}`;
    btn.title = tutorials[i].title || `Tutorial ${i}`;
    btn.setAttribute('aria-label', `Tutorial ${i}: ${btn.title}`);
    btn.onclick = () => loadTutorial(i);
    tutContainer.appendChild(btn);
}

const loadTutorial = (num) => {
    if (document.activeElement) document.activeElement.blur(); 
    isExecuting = false;
    document.getElementById('debug-console').innerHTML = `<span style="color: #aaaaaa;">Stopped.</span>`;
    suppressDeclarationEvaluation = true;
    editorDeclarations.setValue(tutorials[num].decl);
    const tutorialUpdate = tutorials[num].upd;
    setCurrentProgramName(tutorials[num].title || `Tutorial ${num}`);
    const mobileInputHelp = tutorialUpdate.includes('Input.GetKey')
        ? '// Mobile: tap the controller icon. Use the arrow pad, WASD, R CTRL, and SPACE.\n'
        : '';
    editorUpdate.setValue(mobileInputHelp + tutorialUpdate);
    suppressDeclarationEvaluation = false;
    evalDeclarations();
};

function generateId() {
    return 'cube_' + Math.random().toString(36).substr(2, 9);
}

function animate() {
    requestAnimationFrame(animate);
    const dt = clock.getDelta();
    window.Time.deltaTime = dt;
    actionCooldown -= dt;

    if (isExecuting && !sharedPlayerAlertOpen) {
        window._evalStartTime = performance.now();
        try { 
            eval(cachedUpdateCode);
        } catch (e) { 
            isExecuting = false; 
            setDebugError("Update Error: " + e.message + "<br><em>Execution stopped.</em>");
            console.error("Update Error:", e); 
        }
    }

    if (objectEditorMode) {
        editorPointer.visible = true;
        updateObjectMouseLook(dt);
        const moveSpeed = 10 * dt;
        const rotSpeed = 2 * dt;
        
        if (window.Input.GetKey(window.KeyCode.W)) camera.translateZ(-moveSpeed);
        if (window.Input.GetKey(window.KeyCode.S)) camera.translateZ(moveSpeed);
        if (window.Input.GetKey(window.KeyCode.A)) camera.translateX(-moveSpeed);
        if (window.Input.GetKey(window.KeyCode.D)) camera.translateX(moveSpeed);
        if (window.Input.GetKey(window.KeyCode.R)) camera.translateY(moveSpeed);
        if (window.Input.GetKey(window.KeyCode.F)) camera.translateY(-moveSpeed);
        
        const yawDelta = (Number(window.Input.GetKey(window.KeyCode.LeftArrow)) -
            Number(window.Input.GetKey(window.KeyCode.RightArrow))) * rotSpeed;
        const pitchDelta = (Number(window.Input.GetKey(window.KeyCode.UpArrow)) -
            Number(window.Input.GetKey(window.KeyCode.DownArrow))) * rotSpeed;
        if (yawDelta || pitchDelta) rotateObjectEditorCamera(yawDelta, pitchDelta);

        editorForwardPosition.set(0, 0, -4).applyMatrix4(camera.matrixWorld);
        editorPointer.position.set(
            Math.round(editorForwardPosition.x),
            Math.round(editorForwardPosition.y),
            Math.round(editorForwardPosition.z)
        );

        if (actionCooldown <= 0) {
            if (window.Input.GetKey(window.KeyCode.LeftControl)) {
                const id = selectedObjectColliderName || generateId();
                const c = window.qb(id, editorPointer.position.x, editorPointer.position.y, editorPointer.position.z);
                const r = document.getElementById('obj-r').value / 255;
                const g = document.getElementById('obj-g').value / 255;
                const b = document.getElementById('obj-b').value / 255;
                const a = document.getElementById('obj-a').value;
                c.material.color.setRGB(r, g, b);
                c.material.opacity = parseFloat(a);
                if (selectedObjectTexture) {
                    window.tx(id, selectedObjectTexture, "File", 6);
                }
                actionCooldown = 0.25; 
            }
            if (window.Input.GetKey(window.KeyCode.E)) {
                for (let i = cubes.length - 1; i >= 0; i--) {
                    if (cubes[i].position.distanceTo(editorPointer.position) < 0.5) {
                        window.dl(cubes[i].name);
                        break;
                    }
                }
                actionCooldown = 0.25;
            }
        }

    }

    if (mapEditorMode) {
        editorPointer.visible = true;
        const placementY = Number(mapObjectYInput.value) || 0;
        editorPointer.position.y = placementY;
        const panSpeed = 20 * dt;
        if (window.Input.GetKey(window.KeyCode.W)) camera.position.z -= panSpeed;
        if (window.Input.GetKey(window.KeyCode.S)) camera.position.z += panSpeed;
        if (window.Input.GetKey(window.KeyCode.A)) camera.position.x -= panSpeed;
        if (window.Input.GetKey(window.KeyCode.D)) camera.position.x += panSpeed;

        if (actionCooldown <= 0) {
            // Arrow keys pan the camera and placement cursor together. The
            // cursor stays fixed on screen while reaching new map coordinates.
            if (window.Input.GetKey(window.KeyCode.UpArrow)) {
                camera.position.z -= 1;
                editorPointer.position.z -= 1;
                actionCooldown = 0.15;
            }
            if (window.Input.GetKey(window.KeyCode.DownArrow)) {
                camera.position.z += 1;
                editorPointer.position.z += 1;
                actionCooldown = 0.15;
            }
            if (window.Input.GetKey(window.KeyCode.LeftArrow)) {
                camera.position.x -= 1;
                editorPointer.position.x -= 1;
                actionCooldown = 0.15;
            }
            if (window.Input.GetKey(window.KeyCode.RightArrow)) {
                camera.position.x += 1;
                editorPointer.position.x += 1;
                actionCooldown = 0.15;
            }

            if (window.Input.GetKey(window.KeyCode.C)) {
                centerMapPointerOnView();
                actionCooldown = 0.2;
            }

            if (window.Input.GetKey(window.KeyCode.Z)) {
                mapObjectRotationInput.value = (Number(mapObjectRotationInput.value) || 0) - 15;
                actionCooldown = 0.15;
            }
            if (window.Input.GetKey(window.KeyCode.X)) {
                mapObjectRotationInput.value = (Number(mapObjectRotationInput.value) || 0) + 15;
                actionCooldown = 0.15;
            }

            if (window.Input.GetKey(window.KeyCode.LeftControl)) {
                if (selectedMapObject) {
                    placeMapEditorObject({
                        file: selectedMapObject,
                        x: editorPointer.position.x,
                        y: placementY,
                        z: editorPointer.position.z,
                        rotationY: Number(mapObjectRotationInput.value) || 0,
                        scale: Math.max(0.01, Number(mapObjectScaleInput.value) || 1)
                    });
                } else {
                    selectedMapObjectLabel.textContent = 'Select a JSON object first.';
                }
                actionCooldown = 0.25;
            }
            if (window.Input.GetKey(window.KeyCode.E)) {
                for (let i = cubes.length - 1; i >= 0; i--) {
                    if (cubes[i].userData.mapEditorObject &&
                        cubes[i].position.distanceTo(editorPointer.position) < 0.75) {
                        window.dl(cubes[i].name);
                        updateMapObjectCount();
                        break;
                    }
                }
                actionCooldown = 0.25;
            }
        }

        syncMapObjectPreview();
    }

    renderer.render(scene, camera);
}

const hideAllMenus = () => {
    if (document.activeElement) document.activeElement.blur();
    closeMapObjectPicker();
    mapEditorLoadToken++;
    discardPendingMapEditorObjects();
    document.querySelectorAll('.menu-panel').forEach(el => el.style.display = 'none');
    document.getElementById('btn-restore-ide').style.display = 'none';
    objectEditorMode = false;
    mapEditorMode = false;
    setSkyboxVisible(true);
    removeMapObjectPreview();
    editorPointer.visible = false;
    isExecuting = false;
    document.getElementById('crosshair').style.display = 'none';
    if (document.pointerLockElement) document.exitPointerLock();
};

document.getElementById('btn-creative').onclick = () => {
    hideAllMenus();
    document.getElementById('creative-menu').style.display = 'block';
};

document.getElementById('btn-3dpl').onclick = () => {
    hideAllMenus();
    document.getElementById('ide-panel').style.display = 'flex';
    setTimeout(() => { editorDeclarations.refresh(); editorUpdate.refresh(); }, 10);
    resetCamera();
};

const idePanel = document.getElementById('ide-panel');
const restoreIdeButton = document.getElementById('btn-restore-ide');
const maximizeIdeButton = document.getElementById('btn-maximize-ide');
const programNameLabel = document.getElementById('ide-program-name');
const programFileInput = document.getElementById('file-input-program');
let currentProgramName = 'untitled';
const refreshCodeEditors = () => setTimeout(() => {
    editorDeclarations.refresh();
    editorUpdate.refresh();
}, 10);

document.getElementById('btn-minimize-ide').onclick = () => {
    if (document.activeElement) document.activeElement.blur();
    idePanel.style.display = 'none';
    restoreIdeButton.style.display = 'block';
};

restoreIdeButton.onclick = () => {
    restoreIdeButton.style.display = 'none';
    idePanel.style.display = 'flex';
    refreshCodeEditors();
};

maximizeIdeButton.onclick = () => {
    const isMaximized = idePanel.classList.toggle('ide-maximized');
    maximizeIdeButton.setAttribute('aria-pressed', String(isMaximized));
    maximizeIdeButton.setAttribute('aria-label', `${isMaximized ? 'Restore' : 'Maximize'} code window`);
    maximizeIdeButton.title = isMaximized ? 'Restore window size' : 'Maximize';
    maximizeIdeButton.textContent = isMaximized ? '❐' : '□';
    refreshCodeEditors();
};

function setCurrentProgramName(name) {
    currentProgramName = name || 'untitled';
    programNameLabel.textContent = currentProgramName;
    programNameLabel.title = `Current program: ${currentProgramName}`;
}

document.getElementById('btn-load-program').onclick = () => {
    programFileInput.value = '';
    programFileInput.click();
};

function applyProgramCode(declarationsCode, updateCode, programName) {
    isExecuting = false;
    suppressDeclarationEvaluation = true;
    try {
        editorDeclarations.setValue(String(declarationsCode ?? ''));
        editorUpdate.setValue(String(updateCode ?? ''));
    } finally {
        suppressDeclarationEvaluation = false;
    }
    setCurrentProgramName(programName);
    evalDeclarations();
    refreshCodeEditors();
}

programFileInput.onchange = async () => {
    const files = [...programFileInput.files];
    const declarationsFile = files.find(file => file.name.toLowerCase().endsWith('.declarations'));
    const updateFile = files.find(file => file.name.toLowerCase().endsWith('.update'));

    if (!declarationsFile || !updateFile) {
        setDebugError('Load Program: select one .declarations file and its matching .update file.');
        return;
    }

    const declarationsName = declarationsFile.name.slice(0, -'.declarations'.length);
    const updateName = updateFile.name.slice(0, -'.update'.length);
    if (declarationsName !== updateName) {
        setDebugError('Load Program: both files must have the same program name.');
        return;
    }

    try {
        const [declarationsCode, updateCode] = await Promise.all([
            declarationsFile.text(),
            updateFile.text()
        ]);
        applyProgramCode(declarationsCode, updateCode, declarationsName);
    } catch (error) {
        setDebugError(`Load Program: ${error.message}`);
    }
};

function downloadProgramFile(filename, contents) {
    const blobUrl = URL.createObjectURL(new Blob([contents], { type: 'text/plain;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
}

document.getElementById('btn-save-program').onclick = () => {
    const requestedName = window.prompt('Program name:', currentProgramName);
    if (requestedName === null) return;
    const safeName = requestedName.trim().replace(/[\\/:*?"<>|]+/g, '_');
    if (!safeName) {
        setDebugError('Save Program: enter a program name.');
        return;
    }

    setCurrentProgramName(safeName);
    downloadProgramFile(`${safeName}.declarations`, editorDeclarations.getValue());
    downloadProgramFile(`${safeName}.update`, editorUpdate.getValue());
};

document.getElementById('btn-obj-editor').onclick = () => {
    hideAllMenus();
    document.getElementById('obj-editor-ui').style.display = 'flex';
    window.cs();
    resetCamera();
    const axis = window.qb("AxisPoint", 0, 0, 0);
    axis.material.color.setHex(0x00ff00);
    axis.material.opacity = 0.5;
    objectEditorMode = true;
};

document.getElementById('btn-audio').onclick = () => {
    hideAllMenus();
    document.getElementById('audio-ui').style.display = 'flex';
};

document.getElementById('btn-map-editor').onclick = () => {
    hideAllMenus();
    document.getElementById('map-editor-ui').style.display = 'flex';
    window.cs();
    camera.position.set(0, 50, 0);
    camera.rotation.set(-Math.PI / 2, 0, 0, 'YXZ');
    editorPointer.position.set(0, 0, 0);
    actionCooldown = 0;
    updateMapObjectCount();
    mapEditorMode = true;
    setSkyboxVisible(false);
    createMapObjectPreview();
};

const backToMain = () => {
    hideAllMenus();
    window.cs();
    document.getElementById('main-menu').style.display = 'block';
};
document.getElementById('btn-back-main').onclick = backToMain;
document.getElementById('btn-exit-obj').onclick = backToMain;
document.getElementById('btn-exit-map').onclick = backToMain;
document.getElementById('btn-exit-audio').onclick = backToMain;
document.getElementById('btn-exit-ide').onclick = backToMain;

document.getElementById('btn-run').onclick = (e) => {
    if (sharedGameId) return;
    if (e.target) e.target.blur();

    if (isExecuting) {
        isExecuting = false;
        document.getElementById('debug-console').innerHTML = `<span style="color: #aaaaaa;">Stopped.</span>`;
        evalDeclarations();
        return;
    }

    // A failed declaration leaves only part of the scene and vars initialized.
    // Keep its useful error visible instead of producing a secondary update error.
    if (!declarationsValid && !evalDeclarations()) return;

    isExecuting = true;
    renderer.domElement.focus({ preventScroll: true });
    clearDebug();
    if (listener.context.state !== 'running') {
        Promise.resolve(listener.context.resume())
            .then(playQueuedSounds)
            .catch(error => {
                setDebugError(`Audio could not start: ${error.message}`);
                console.error('Audio resume error:', error);
            });
    } else {
        playQueuedSounds();
    }
};

editorDeclarations.on('change', () => {
    if (!isExecuting && !suppressDeclarationEvaluation) evalDeclarations();
});
editorUpdate.on('change', refreshCachedUpdateCode);

// --- Share a playable snapshot ---
const shareDialog = document.getElementById('share-dialog');
const shareLinkInput = document.getElementById('share-link');
const shareStatus = document.getElementById('share-status');
const shareButton = document.getElementById('btn-share-program');
const copyShareButton = document.getElementById('btn-copy-share');

function closeShareDialog() {
    shareDialog.classList.remove('open');
    shareDialog.setAttribute('aria-hidden', 'true');
    shareButton.focus();
}
document.getElementById('btn-close-share').onclick = closeShareDialog;
shareDialog.addEventListener('keydown', event => {
    if (event.code === 'Escape') closeShareDialog();
});

async function copySharedGameLink() {
    if (!shareLinkInput.value) return;
    try {
        await navigator.clipboard.writeText(shareLinkInput.value);
        shareStatus.textContent = 'Link copied. Send it to anyone to play.';
    } catch (error) {
        // HTTP sites and browsers requiring another gesture can still copy.
        shareLinkInput.focus();
        shareLinkInput.select();
        let copied = false;
        try { copied = document.execCommand('copy'); } catch (copyError) { /* Keep the link available for manual copying. */ }
        shareStatus.textContent = copied
            ? 'Link copied. Send it to anyone to play.'
            : 'Select and copy the link above, or press Copy link.';
    }
}
copyShareButton.onclick = copySharedGameLink;

shareButton.onclick = async () => {
    if (sharedGameId || !requireLoggedInUser('sharing a game')) return;
    if (!declarationsValid) {
        setDebugError('Fix the declaration error before sharing this game.');
        return;
    }
    const name = currentProgramName || 'untitled';
    if (!validCloudProgramName(name)) {
        setDebugError('Save this program with a name containing letters, numbers, spaces, dots, underscores, or hyphens before sharing.');
        return;
    }
    const payload = {
        name, declarations: editorDeclarations.getValue(), update: editorUpdate.getValue(),
        assets: [...programAssets.values()], scope: loggedInNick
    };
    shareDialog.classList.add('open');
    shareDialog.setAttribute('aria-hidden', 'false');
    shareLinkInput.value = '';
    shareStatus.textContent = 'Creating a playable copy with the game assets…';
    copyShareButton.disabled = true;
    shareButton.disabled = true;
    document.getElementById('btn-close-share').focus();
    try {
        const response = await fetch('server_side/share_program.php', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'X-3DPL-Share': '1' },
            body: JSON.stringify(payload)
        });
        const result = await readApiResponse(response);
        const url = new URL('play.php', document.baseURI);
        url.searchParams.set('share', result.id);
        shareLinkInput.value = url.href;
        copyShareButton.disabled = false;
        await copySharedGameLink();
    } catch (error) {
        shareStatus.textContent = `Could not share: ${error.message}`;
    } finally {
        shareButton.disabled = false;
    }
};

// --- Isolated shared-game player ---
function installSharedPlayerAlerts() {
    // Native alerts are blocked in the opaque-origin sandbox. A modal HTML
    // dialog keeps existing alert(...) calls visible without weakening isolation.
    const dialog = document.getElementById('shared-game-alert');
    const message = document.getElementById('shared-game-alert-message');
    const ok = document.getElementById('shared-game-alert-ok');
    const pending = [];
    const releaseKeys = () => {
        releaseMobileControls();
        Object.keys(window.Input._keys).forEach(key => window.Input._keys[key] = false);
    };
    const showNext = () => {
        sharedPlayerAlertOpen = true;
        releaseKeys();
        if (document.pointerLockElement) document.exitPointerLock();
        message.textContent = pending[0];
        dialog.showModal();
        ok.focus();
    };
    ok.addEventListener('click', () => dialog.close());
    dialog.addEventListener('close', () => {
        pending.shift();
        if (pending.length) {
            showNext();
        } else {
            sharedPlayerAlertOpen = false;
            releaseKeys();
            clock.getDelta();
            renderer.domElement.focus({ preventScroll: true });
        }
    });
    window.alert = (text = '') => {
        pending.push(String(text));
        if (!sharedPlayerAlertOpen) showNext();
    };
}

function showSharedPlayerStatus(message, isError = false) {
    const status = document.getElementById('shared-player-status');
    status.textContent = message;
    status.style.display = message ? 'block' : 'none';
    status.setAttribute('role', isError ? 'alert' : 'status');
}

function unlockSharedPlayerAudio() {
    if (!sharedGameId || !sharedPlayerReady) return;
    if (listener.context.state === 'suspended') {
        listener.context.resume().then(playQueuedSounds).catch(() => {});
    } else if (listener.context.state === 'running') {
        playQueuedSounds();
    }
}
document.addEventListener('pointerdown', unlockSharedPlayerAudio, true);

async function startSharedGame() {
    installSharedPlayerAlerts();
    editorDeclarations.setOption('readOnly', 'nocursor');
    editorUpdate.setOption('readOnly', 'nocursor');
    document.querySelectorAll('.menu-panel, .app-modal, #account-controls, #btn-restore-ide')
        .forEach(element => {
            element.setAttribute('inert', '');
            element.setAttribute('aria-hidden', 'true');
        });
    document.querySelectorAll('.menu-panel button, .menu-panel input, .menu-panel select, .app-modal button, .app-modal input')
        .forEach(element => element.disabled = true);
    const pauseButton = document.getElementById('mobile-controller-start');
    pauseButton.textContent = 'PAUSE';
    pauseButton.setAttribute('aria-label', 'Pause or resume game');
    pauseButton.disabled = true;
    showSharedPlayerStatus('Loading game…');
    try {
        const response = await fetch('server_side/load_shared_program.php?' +
            new URLSearchParams({ share: sharedGameId }), { credentials: 'omit' });
        const game = await readApiResponse(response);
        document.title = game.name + ' — 3DPL';
        applyProgramCode(game.declarations, game.update, game.name);
        if (!declarationsValid) throw new Error(sharedPlayerError || 'The game could not start.');
        const pending = [];
        cubes.forEach(object => object.traverse(child => {
            if (child.userData.ready) pending.push(child.userData.ready);
        }));
        await Promise.all(pending);
        await Promise.all([...sharedTextureCache.values()].map(texture => texture.userData.threeDPLReady));
        if (sharedPlayerError) throw new Error(sharedPlayerError);
        // Start simulation automatically; browsers unlock audio on the first input.
        sharedPlayerReady = true;
        isExecuting = true;
        pauseButton.disabled = false;
        clock.getDelta();
        showSharedPlayerStatus('');
        renderer.domElement.focus({ preventScroll: true });
    } catch (error) {
        isExecuting = false;
        showSharedPlayerStatus(`Unable to start game: ${error.message}`, true);
    }
}

window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});

animate();
if (sharedGameId) startSharedGame();
